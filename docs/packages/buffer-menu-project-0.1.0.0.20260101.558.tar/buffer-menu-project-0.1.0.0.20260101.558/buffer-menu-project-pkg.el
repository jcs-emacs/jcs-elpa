;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-menu-project" "0.1.0.0.20260101.558"
  "List buffers relative to project."
  '((emacs   "25.1")
    (project "0.8.1")
    (f       "0.20.0"))
  :url "https://github.com/jcs-elpa/buffer-menu-project"
  :commit "b4862db8b7170b7af431b010e5bf6647dac65c11"
  :revdesc "b4862db8b717"
  :keywords '("convenience" "buffer" "menu" "project")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
