;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260218.10"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/emacs-dashboard"
  :commit "64897400191ffabb8acedbee4ec24eb90eba2c47"
  :revdesc "64897400191f"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
