;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.5.0.0.20260616.11"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "dae5ddeef43bd25ce502ee347ea5226586ed9bb1"
  :revdesc "dae5ddeef43b"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
