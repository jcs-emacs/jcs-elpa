;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-color" "0.1.0.0.20260101.541"
  "Show color information with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0"))
  :url "https://github.com/emacs-sideline/sideline-color"
  :commit "c8e7282f5068c296df2a80e3fb1d6dd2b8ab08b8"
  :revdesc "c8e7282f5068"
  :keywords '("convenience" "color")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
