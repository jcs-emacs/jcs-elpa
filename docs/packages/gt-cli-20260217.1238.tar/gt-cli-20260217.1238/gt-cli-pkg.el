;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gt-cli" "20260217.1238"
  "A command-line interface for gt."
  '((emacs     "28.1")
    (gt        "3.2.1")
    (commander "0.7.0")
    (msgu      "0.1.0"))
  :url "https://github.com/emacs-eine/gt-cli"
  :commit "9a8194e7e4f290001f87d8d59d1a54dce0b86438"
  :revdesc "9a8194e7e4f2"
  :keywords '("convenience")
  :authors '(("Jen-Chieh Shen" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
