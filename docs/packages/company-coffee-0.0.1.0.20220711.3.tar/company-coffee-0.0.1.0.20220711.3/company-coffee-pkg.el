;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-coffee" "0.0.1.0.20220711.3"
  "Emacs coffee completion."
  '((emacs   "26.1")
    (company "0.8.12"))
  :url "https://github.com/elp-revive/company-coffee"
  :commit "cab6ebe0c1048881e565de98c3d159a05652db75"
  :revdesc "cab6ebe0c104"
  :keywords '("convenience")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
