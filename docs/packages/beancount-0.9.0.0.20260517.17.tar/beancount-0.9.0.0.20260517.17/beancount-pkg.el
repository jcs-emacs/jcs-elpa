;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beancount" "0.9.0.0.20260517.17"
  "A major mode to edit Beancount input files."
  ()
  :url "https://github.com/beancount/beancount-mode"
  :commit "534c273fa8c549e79ccaa0e55227a14b14aa177e"
  :revdesc "534c273fa8c5"
  :authors '(("Martin Blais" . "blais@furius.ca"))
  :maintainers '(("Martin Blais" . "blais@furius.ca")))
