;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260321.2128"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/dashboard"
  :commit "263b9f6b78fa7229492fe06ae9f6132ad42f5290"
  :revdesc "263b9f6b78fa"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
