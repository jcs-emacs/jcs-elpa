;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambda-line" "0.1.0.20260528.144"
  "A custom status line."
  '((emacs "27.1"))
  :url "https://github.com/Lambda-Emacs/lambda-line"
  :commit "b276afa194b692b36a50592985131211b371dfd7"
  :revdesc "b276afa194b6"
  :keywords '("mode-line" "faces"))
