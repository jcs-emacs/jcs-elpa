;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260530.4"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "5cd780f41ff11681ebc9634b1aad2e1596dcd66d"
  :revdesc "5cd780f41ff1"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
