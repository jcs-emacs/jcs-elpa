;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.5.0.0.20260617.13"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "c72f9b28ac94320bed28d9887fe3c8322f034d4d"
  :revdesc "c72f9b28ac94"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
