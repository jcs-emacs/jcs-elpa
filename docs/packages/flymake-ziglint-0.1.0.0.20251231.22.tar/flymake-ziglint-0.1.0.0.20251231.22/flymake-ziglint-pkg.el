;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ziglint" "0.1.0.0.20251231.22"
  "Flymake for ziglint."
  '((emacs        "26.1")
    (flymake-easy "0.1"))
  :url "https://github.com/flymake/flymake-ziglint"
  :commit "052ad08d3c4ce521b824d91c039ce0a747fce5e8"
  :revdesc "052ad08d3c4c"
  :keywords '("tools")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
