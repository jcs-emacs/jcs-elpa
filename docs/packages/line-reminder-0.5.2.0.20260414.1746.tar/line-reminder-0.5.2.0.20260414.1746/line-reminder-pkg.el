;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "line-reminder" "0.5.2.0.20260414.1746"
  "Line annotation for changed and saved lines."
  '((emacs         "25.1")
    (fringe-helper "1.0.1")
    (ov            "1.0.6")
    (ht            "2.0"))
  :url "https://github.com/emacs-vs/line-reminder"
  :commit "9a20500704f5b21772d00e4d0a9ff16dac943400"
  :revdesc "9a20500704f5"
  :keywords '("convenience" "annotation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
