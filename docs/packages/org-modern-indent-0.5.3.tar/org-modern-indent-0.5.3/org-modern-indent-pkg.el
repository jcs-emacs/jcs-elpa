;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern-indent" "0.5.3"
  "Indent blocks like org-modern."
  '((emacs  "27.1")
    (org    "9.6.1")
    (compat "30.0"))
  :url "https://github.com/jdtsmith/org-modern-indent"
  :commit "86bd83ee1ad95f123810eb3b116beb543db1960a"
  :revdesc "86bd83ee1ad9"
  :keywords '("convenience"))
