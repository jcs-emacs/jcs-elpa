;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0.0.20261105.6"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "fd36370316d056804d9642cbf54e94259cd59248"
  :revdesc "fd36370316d0"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
