;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0.0.20261114.7"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "57bcdb7c04316e812e50eaa77f0df72aa6d41ecc"
  :revdesc "57bcdb7c0431"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
