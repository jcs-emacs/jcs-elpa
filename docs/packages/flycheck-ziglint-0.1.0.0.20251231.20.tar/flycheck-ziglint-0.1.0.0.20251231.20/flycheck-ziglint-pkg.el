;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ziglint" "0.1.0.0.20251231.20"
  "Flycheck for ziglint."
  '((emacs    "27.1")
    (flycheck "0.22")
    (zig-mode "0.0.8"))
  :url "https://github.com/flycheck/flycheck-ziglint"
  :commit "fb837a10ab7a1740d5bcaa1f65bf192420e398c1"
  :revdesc "fb837a10ab7a"
  :keywords '("tools")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
