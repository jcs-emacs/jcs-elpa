;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jcs-template" "0.1.0.0.20251231.26"
  "Template module for jcs-emacs."
  '((emacs       "29.1")
    (file-header "0.1.0")
    (f           "0.20.0"))
  :url "https://github.com/jcs-emacs/jcs-template"
  :commit "5c92762e4339c920e0ff04f1792fceb07030d0d9"
  :revdesc "5c92762e4339"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
