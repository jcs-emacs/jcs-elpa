;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-eros" "0.1.0.0.20260101.541"
  "Show EROS result with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0")
    (eros     "0.1.0"))
  :url "https://github.com/emacs-sideline/sideline-eros"
  :commit "39f036b8ed074c5762f7982dee2557a5845b186a"
  :revdesc "39f036b8ed07"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
