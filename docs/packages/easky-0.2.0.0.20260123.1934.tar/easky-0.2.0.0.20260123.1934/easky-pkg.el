;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easky" "0.2.0.0.20260123.1934"
  "Control the Eask command-line interface."
  '((emacs          "27.1")
    (eask-mode      "0.1.0")
    (eask           "0.1.0")
    (ansi           "0.4.1")
    (lv             "0.0")
    (marquee-header "0.1.0"))
  :url "https://github.com/emacs-eask/easky"
  :commit "2eb06188d2a134c23340421a53cc5bfa94286a4a"
  :revdesc "2eb06188d2a1"
  :keywords '("maint" "easky")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
