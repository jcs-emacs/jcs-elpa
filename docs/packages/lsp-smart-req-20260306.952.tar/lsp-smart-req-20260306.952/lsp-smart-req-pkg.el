;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-smart-req" "20260306.952"
  "Lazy load LSP packages."
  '((emacs "27.1"))
  :url "https://github.com/jcs-elpa/lsp-smart-req"
  :commit "525d69a0db09cfcd5d237407aa24c6c778a62c42"
  :revdesc "525d69a0db09"
  :keywords '("internal" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
