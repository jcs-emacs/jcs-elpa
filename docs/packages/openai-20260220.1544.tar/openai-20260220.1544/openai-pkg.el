;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "openai" "20260220.1544"
  "Elisp library for the OpenAI API."
  '((emacs   "26.1")
    (request "0.3.0")
    (tblui   "0.1.0"))
  :url "https://github.com/emacs-openai/openai"
  :commit "67d5506a713192c0039b6b2546b9cfa4e2bca081"
  :revdesc "67d5506a7131"
  :keywords '("comm" "openai")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
