;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cognitive-complexity" "1.0.0.0.20260414.26"
  "Minor mode to show the cognitive complexity of code."
  '((emacs "29.1"))
  :url "https://github.com/abougouffa/cognitive-complexity"
  :commit "b45afe9bf65943f985b645cea514212dc734349b"
  :revdesc "b45afe9bf659"
  :keywords '("convenience" "tools" "c" "languages"))
