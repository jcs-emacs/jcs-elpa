;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260222.1736"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "3719b49dbfa775959e7248d043f24c3cd564efaf"
  :revdesc "3719b49dbfa7"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
