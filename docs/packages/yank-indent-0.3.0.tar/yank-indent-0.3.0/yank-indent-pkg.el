;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yank-indent" "0.3.0"
  "Automatically indent yanked text."
  '((emacs "25.1"))
  :url "https://github.com/jimeh/yank-indent"
  :commit "15fd7271bd8b5ff085eacaf047c97530a5af236d"
  :revdesc "15fd7271bd8b"
  :keywords '("convenience" "yank" "indent")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
