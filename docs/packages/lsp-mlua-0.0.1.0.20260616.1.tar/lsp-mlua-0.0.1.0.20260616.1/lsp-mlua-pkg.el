;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mlua" "0.0.1.0.20260616.1"
  "LSP Clients for mLua."
  '((emacs    "29.1")
    (lsp-mode "6.1"))
  :url "https://github.com/MSW-cmty/lsp-mlua"
  :commit "cc0e2d84c8318163d135627c5746fffd2388f3bd"
  :revdesc "cc0e2d84c831"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
