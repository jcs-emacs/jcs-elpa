;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260310.1924"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "f5d9061263ca55032be7a0f11af14ecffc9c34e5"
  :revdesc "f5d9061263ca"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
