;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260719.8"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "b04e927abac6fcbef480c8a39881d69baa1bec98"
  :revdesc "b04e927abac6"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
