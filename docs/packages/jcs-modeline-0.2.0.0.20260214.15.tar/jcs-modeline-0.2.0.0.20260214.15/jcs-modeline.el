;;; jcs-modeline.el --- A modeline for jcs-emacs  -*- lexical-binding: t; -*-

;; Copyright (C) 2022-2026  Shen, Jen-Chieh

;; Author: Shen, Jen-Chieh <jcs090218@gmail.com>
;; Maintainer: Shen, Jen-Chieh <jcs090218@gmail.com>
;; URL: https://github.com/jcs-emacs/jcs-modeline
;; Package-Version: 0.2.0.0.20260214.15
;; Package-Revision: a136c07fbe65
;; Package-Requires: ((emacs "29.1")
;;                    (moody "0.7.1") (minions "0.3.7") (elenv "0.1.0")
;;                    (nerd-icons "0.0.1") (reveal-in-folder "0.1.2")
;;                    (goto-line-preview "0.1.0") (goto-char-preview "0.1.0"))
;; Keywords: faces mode-line

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A modeline for jcs-emacs
;;

;;; Code:

(require 'cl-lib)
(require 'subr-x)

(require 'elenv)
(require 'moody)
(require 'minions)
(require 'nerd-icons)

(defgroup jcs-modeline nil
  "A modeline for jcs-emacs."
  :prefix "jcs-modeline-"
  :group 'faces
  :link '(url-link :tag "Github" "https://github.com/jcs-emacs/jcs-modeline"))

(defcustom jcs-modeline-left
  `((:eval (jcs-modeline--render-front-spaces))
    (:eval (jcs-modeline--render-buffer-identification))
    (:eval (jcs-modeline--render-modes))
    (:eval (moody-ribbon (jcs-modeline--render-vc-project)))
    (:eval (jcs-modeline--render-read-only))
    (:eval (jcs-modeline--render-mode-line-process)))
  "List of item to render on the left."
  :type '(list symbol)
  :group 'jcs-modeline)

(defcustom jcs-modeline-right
  `((:eval (jcs-modeline--render-nov))
    (:eval (jcs-modeline--render-csv))
    (:eval (jcs-modeline--render-text-scale))
    (:eval (jcs-modeline--render-flymake))
    (:eval (jcs-modeline--render-flycheck))
    (:eval (jcs-modeline--render-undo-tree-buffer-name))
    (:eval (jcs-modeline--render-undo-tree-status))
    (:eval (jcs-modeline--render-vc-info))
    (:eval (moody-ribbon (jcs-modeline--render-line-columns) 0 'up))
    (:eval (jcs-modeline--render-percent-position))
    (:eval (jcs-modeline--render-end-spaces)))
  "List of item to render on the right."
  :type '(list symbol)
  :group 'jcs-modeline)

(defcustom jcs-modeline-checker-colors '((error   . "#FB4933")
                                         (warning . "#FABD2F")
                                         (info    . "#83A598")
                                         (note    . "#83A598"))
  "Alist of colors for checkers."
  :type '(list symbol)
  :group 'jcs-modeline)

;;
;; (@* "Externals" )
;;

(defvar buffer-undo-tree)
(defvar undo-tree-visualizer-buffer-name)
(defvar undo-tree-visualizer-parent-buffer)
(declare-function undo-tree-current "ext:undo-tree.el")
(declare-function undo-tree-root "ext:undo-tree.el")
(declare-function undo-tree-node-next "ext:undo-tree.el")
(declare-function undo-tree-node-previous "ext:undo-tree.el")
(declare-function undo-tree-node-branch "ext:undo-tree.el")
(declare-function undo-tree-count "ext:undo-tree.el")
(declare-function undo-tree-size "ext:undo-tree.el")
(declare-function undo-tree-node-timestamp "ext:undo-tree.el")
(declare-function undo-tree-timestamp-to-string "ext:undo-tree.el")

(defvar flymake--state)
(declare-function flymake-running-backends "ext:flymake.el")
(declare-function flymake-disabled-backends "ext:flymake.el")
(declare-function flymake-reporting-backends "ext:flymake.el")
(declare-function flymake--diag-type "ext:flymake.el")
(declare-function flymake--state-diags "ext:flymake.el")
(declare-function flymake-goto-next-error "ext:flymake.el")

(defvar flycheck-current-errors)
(defvar flycheck-last-status-change)
(declare-function flycheck-has-current-errors-p "ext:flycheck.el")
(declare-function flycheck-count-errors "ext:flycheck.el")
(declare-function flycheck-next-error "ext:flycheck.el")

(declare-function magit-branch-checkout "ext:magit-branch.el")

;;
;; (@* "Entry" )
;;

;; The actual render items reflect the responsive window.
(defvar jcs-modeline--render-left nil)
(defvar jcs-modeline--render-right nil)

(defvar jcs-modeline--default-mode-line nil
  "Default modeline value to revert back.")

(defun jcs-modeline--enable ()
  "Enable function `jcs-modeline-mode'."
  (unless elenv-graphic-p
    (advice-add 'moody-wrap :override #'jcs-modeline--moody-wrap))
  (add-hook 'window-size-change-functions #'jcs-modeline--window-resize)
  (jcs-modeline--window-resize)  ; call it manually once
  (setq jcs-modeline--default-mode-line mode-line-format)
  (setq-default mode-line-format '((:eval jcs-modeline--render-left)
                                   mode-line-format-right-align
                                   (:eval jcs-modeline--render-right)))
  (minions-mode 1))

(defun jcs-modeline--disable ()
  "Disable function `jcs-modeline-mode'."
  (unless elenv-graphic-p
    (advice-remove 'moody-wrap #'jcs-modeline--moody-wrap))
  (remove-hook 'window-size-change-functions #'jcs-modeline--window-resize)
  (setq-default mode-line-format jcs-modeline--default-mode-line))

;;;###autoload
(define-minor-mode jcs-modeline-mode
  "Minor mode `jcs-modeline-mode'."
  :global t
  :require 'jcs-modeline-mode
  :group 'jcs-modeline
  :lighter nil
  (if jcs-modeline-mode (jcs-modeline--enable) (jcs-modeline--disable)))

;;
;; (@* "Util" )
;;

(defvar jcs-modeline--char-displayable-cache (make-hash-table :test 'equal)
  "Cache the displable character.")

(defun jcs-modeline--char-displayable-p (str-or-char)
  "Check if STR-OR-CHAR is displayable."
  (let* ((char (if (stringp str-or-char)
                   (string-to-char str-or-char)
                 str-or-char))
         (result (or (gethash char jcs-modeline--char-displayable-cache)
                     (char-displayable-p char))))
    (puthash char result jcs-modeline--char-displayable-cache)
    (and result str-or-char)))

(defun jcs-modeline--str-width (str)
  "Calculate STR in pixel width."
  (let ((width (frame-char-width))
        (len (string-pixel-width str)))
    (+ (/ len width)
       (if (zerop (% len width)) 0 1))))  ; add one if exceeed

(defun jcs-modeline--light-color-p (hex-code)
  "Return non-nil if HEX-CODE is in light tone."
  (when elenv-graphic-p
    (let ((gray (nth 0 (color-values "gray")))
          (color (nth 0 (color-values hex-code))))
      (< gray color))))

(defun jcs-modeline--light-theme-p ()
  "Return non-nil if current theme is light theme."
  (ignore-errors (jcs-modeline--light-color-p (face-background 'default))))

(defun jcs-modeline-format (format &optional face window buffer)
  "Wrapper for function `format-mode-line'.

Arguments FORMAT, FACE, WINDOW and BUFFER are parameters from the
`format-mode-line' function."
  (string-trim (format-mode-line format face window buffer)))

(defun jcs-modeline--moody-wrap (arg0 &rest _)
  "Override the function `moody-wrap' when inside the terminal.

Position argument ARG0."
  (concat " " arg0 " "))

(defun jcs-modeline--keymap-mouse-1 (def)
  "Return the mode-line keymap with bindings DEF key."
  (let ((map (make-sparse-keymap)))
    (define-key map (vector 'mode-line 'mouse-1) def)
    map))

(defmacro jcs-modeline--with-mouse-1 (&rest body)
  "Execute BODY with in the mouse click event."
  (declare (indent 0))
  `(jcs-modeline--keymap-mouse-1 (lambda (&rest _)
                                   (interactive)
                                   (call-interactively #'mouse-select-window)
                                   ,@body)))

;;
;; (@* "Core" )
;;

(defun jcs-modeline--window-resize (&rest _)
  "Window resize hook."
  (let ((count 0) (current-width 0)
        (is-left t)
        (left-index 0) (right-index 0)
        ;; Let's iterate it from outer to inner, so we must flip the right list.
        (right-list (reverse jcs-modeline-right)))
    (setq jcs-modeline--render-left nil
          jcs-modeline--render-right nil)  ; reset
    ;; Loop through the entire `left' + `right' list
    (while (< count (length (append jcs-modeline-left jcs-modeline-right)))
      ;; Check if the index exceed it's length, then flip the left/right
      ;; toggle variable `is-left' to ensure we iterate through the whole
      ;; render list!
      (when (<= (length (if is-left jcs-modeline-left jcs-modeline-right))
                (if is-left left-index right-index))
        (setq is-left (not is-left)))
      ;; Select the item, check the length and add it to the render list!
      (let* ((item (nth (if is-left left-index right-index)
                        (if is-left jcs-modeline-left right-list)))
             (format (format-mode-line item))
             (width (jcs-modeline--str-width format))
             (new-width (+ current-width width)))
        ;; Can the new item added to the list?
        (when (<= new-width (window-width))  ; can be displayed properly!
          (setq current-width new-width)  ; update string/display width
          ;; Add the item to render list!
          (push item (if is-left jcs-modeline--render-left
                       jcs-modeline--render-right))))
      (cl-incf (if is-left left-index right-index))  ; increment index
      (cl-incf count)
      (setq is-left (not is-left))))  ; flip `left' and `right'
  (setq jcs-modeline--render-left (reverse jcs-modeline--render-left)
        ;; Since we iterate it from the edge, we don't need to reverse the right
        jcs-modeline--render-right jcs-modeline--render-right))

;;
;; (@* "Padding" )
;;

(defun jcs-modeline--render-front-spaces ()
  "Return the front spaces."
  "  ")

(defun jcs-modeline--render-end-spaces ()
  "Return the end spaces."
  (cond (elenv-graphic-p
         (if (car (window-current-scroll-bars))
             " "
           "  "))
        (t "   ")))

;;
;; (@* "Plugins" )
;;

;;
;;; Buffe Identification

(defun jcs-modeline--render-buffer-identification ()
  "Render buffer identification."
  (unless (bound-and-true-p centaur-tabs-mode)
    (concat (jcs-modeline-format mode-line-buffer-identification)
            " ")))

(defun jcs-modeline--render-mode-line-process ()
  "Render `mode-line-process'."
  (when-let* ((mode-line-process)
              (ind (jcs-modeline-format mode-line-process)))
    (concat " "
            (propertize ind
                        'mouse-face 'mode-line-highlight
                        'help-echo (elenv-2str (pp-to-string mode-line-process))))))

;;
;;; Modes

(defcustom jcs-modeline-show-mode-icons nil
  "Non-nil to display mode icons."
  :type 'boolean
  :group 'jcs-modeline)

(defcustom jcs-modeline-show-mode-name t
  "Non-nil to display mode name."
  :type 'boolean
  :group 'jcs-modeline)

(defcustom jcs-modeline-icon-scale-factor 1.0
  "The base scale factor for the `height' face property of tab icons."
  :type 'number
  :group 'jcs-modeline)

(defcustom jcs-modeline-icon-v-adjust 0.01
  "The vertical adjust for tab icons."
  :type 'number
  :group 'jcs-modeline)

;; Copied from https://github.com/emacsattic/helm-mode-manager/blob/master/helm-mode-manager.el#L84
(defun jcs-modeline--major-modes ()
  "Return list of potential major mode names.

From Tobias Zawada (http://stackoverflow.com/a/19165202)."
  (interactive)
  (let (l)
    (mapatoms #'(lambda (f) (and
                             (commandp f)
                             (string-match "-mode$" (symbol-name f))
                             ;; auto-loaded
                             (or (and (autoloadp (symbol-function f))
                                      (let ((doc (documentation f)))
                                        (when doc
                                          (and
                                           (let ((docSplit (help-split-fundoc doc f)))
                                             (and docSplit ;; car is argument list
                                                  (null (cdr (read (car docSplit)))))) ;; major mode starters have no arguments
                                           (if (string-match "[mM]inor" doc) ;; If the doc contains "minor"...
                                               (string-match "[mM]ajor" doc) ;; it should also contain "major".
                                             t) ;; else we cannot decide therefrom
                                           ))))
                                 (null (help-function-arglist f)))
                             (setq l (cons (symbol-name f) l)))))
    l))

(defun jcs-modeline--render-modes ()
  "Render line modes."
  (let* ((icon (and jcs-modeline-show-mode-icons
                    (let* ((icon (nerd-icons-icon-for-mode
                                  major-mode
                                  :height jcs-modeline-icon-scale-factor
                                  :v-adjust jcs-modeline-icon-v-adjust))
                           (icon (if (or (null icon) (symbolp icon))
                                     nil
                                   icon)))
                      (when (and icon
                                 (jcs-modeline--char-displayable-p icon))
                        icon))))
         (line-modes (and (or jcs-modeline-show-mode-name
                              (null icon))
                          (jcs-modeline-format mode-name)))
         (lst (cl-remove-if #'null (list icon line-modes)))
         (ind (mapconcat #'identity lst " ")))
    (concat (if (bound-and-true-p centaur-tabs-mode)
                ""
              " ")
            (propertize ind
                        'mouse-face 'mode-line-highlight
                        'help-echo "Major and minor modes
mouse-1: Toggle display of major mode name"
                        'local-map (jcs-modeline--with-mouse-1
                                     (let ((new-mode (completing-read "Select major mode: "
                                                                      (jcs-modeline--major-modes)
                                                                      nil t)))
                                       (funcall (intern new-mode)))))
            " ")))

;;
;;; Line and Columns

(defcustom jcs-modeline-show-point nil
  "If non-nil, also shows point information."
  :type 'boolean
  :group 'jcs-modeline)

(defun jcs-modeline--render-line-columns ()
  "Render current line number and column."
  (let* ((ind-line (propertize (jcs-modeline-format "%l")
                               'mouse-face 'mode-line-highlight
                               'help-echo "Goto Line"
                               'local-map
                               (jcs-modeline--with-mouse-1
                                 (call-interactively #'goto-line-preview))))
         (ind-column (propertize (jcs-modeline-format "%c")
                                 'mouse-face 'mode-line-highlight
                                 'help-echo "Move to Column"
                                 'local-map
                                 (jcs-modeline--with-mouse-1
                                   (call-interactively #'move-to-column))))
         (ind-point (concat
                     "("
                     (propertize (elenv-2str (point))
                                 'mouse-face 'mode-line-highlight
                                 'help-echo "Move to Character"
                                 'local-map
                                 (jcs-modeline--with-mouse-1
                                   (call-interactively #'goto-char-preview)))
                     ")"))
         (lst (if jcs-modeline-show-point
                  (list ind-line ind-column ind-point)
                (list ind-line ind-column))))
    (mapconcat #'identity lst " ")))

;;
;;; Scroll

(defun jcs-modeline--render-percent-position ()
  "Render current scroll."
  (concat " " (propertize "%p"
                          'mouse-face 'mode-line-highlight
                          'help-echo "Percent position")))

;;
;;; Project

(defcustom jcs-modeline-project-indicator "-*-"
  "String indicator when project root is not found."
  :type 'string
  :group 'jcs-modeline)

(defun jcs-modeline--project-root ()
  "Return project directory path."
  (when-let* ((current (project-current))) (project-root current)))

(defcustom jcs-modeline-show-project-name-virutal-buffer nil
  "If non-nil, display project's name in the virutal buffer."
  :type 'boolean
  :group 'jcs-modeline)

(defun jcs-modeline--render-vc-project ()
  "Return the project name."
  (if-let* (((or (buffer-file-name) jcs-modeline-show-project-name-virutal-buffer))
            (project (jcs-modeline--project-root))
            (ind (file-name-nondirectory (directory-file-name project))))
      (concat
       (propertize ind
                   'mouse-face 'mode-line-highlight
                   'help-echo (format "Project Name
path: %s
mouse-1: Reveal project in folder" project)
                   'local-map (jcs-modeline--with-mouse-1
                                (reveal-in-folder-open project))))
    (propertize jcs-modeline-project-indicator
                'mouse-face 'mode-line-highlight
                'help-echo "Project Name

mouse-1: Switch project"
                'local-map (jcs-modeline--with-mouse-1
                             (call-interactively #'project-switch-project)))))

;;
;;; Version Control

(defcustom jcs-modeline-vc-unknown-icon
  (ignore-errors
    (nerd-icons-codicon "nf-cod-workspace_unknown" :face 'jcs-modeline-vc-face))
  "The default unknown VC icon."
  :type 'string
  :group 'jcs-modeline)

(defface jcs-modeline-vc-face
  '((t :foreground "#9BBC6D"))
  "Face to use for VC."
  :group 'jcs-modeline)

(defcustom jcs-modeline-vc-backends
  `((RCS  . ,jcs-modeline-vc-unknown-icon)
    (CVS  . ,jcs-modeline-vc-unknown-icon)
    (SVN  . ,jcs-modeline-vc-unknown-icon)
    (SCCS . ,jcs-modeline-vc-unknown-icon)
    (SRC  . ,jcs-modeline-vc-unknown-icon)
    (Bzr  . ,jcs-modeline-vc-unknown-icon)
    (Git  . ,(ignore-errors
               (nerd-icons-devicon "nf-dev-git_branch" :face 'jcs-modeline-vc-face)))
    (Hg   . ,jcs-modeline-vc-unknown-icon))
  "Alist of vc backends to icon."
  :type '(list symbol)
  :group 'jcs-modeline)

(declare-function vc-git--symbolic-ref "vc-git.el")

(defun jcs-modeline--render-vc-info ()
  "Return `vc-mode' information."
  (when-let* ((bfn (buffer-file-name))
              (backend (vc-backend bfn))
              (backend-icon (alist-get backend jcs-modeline-vc-backends))
              (backend-icon (if (jcs-modeline--char-displayable-p backend-icon)
                                backend-icon
                              ""))
              (branch (or (vc-git--symbolic-ref bfn) ""))
              (separator (if (and backend-icon
                                  (not (string-empty-p backend-icon)))
                             " "
                           ""))
              (tip (elenv-2str backend)))
    (concat (propertize backend-icon
                        'mouse-face 'mode-line-highlight
                        'help-echo tip
                        'local-map (jcs-modeline--with-mouse-1
                                     (call-interactively #'#'magit-branch-checkout)))
            (propertize (concat
                         separator
                         branch)
                        'face 'jcs-modeline-vc-face
                        'mouse-face 'mode-line-highlight
                        'help-echo tip
                        'local-map (jcs-modeline--with-mouse-1
                                     (call-interactively #'magit-branch-checkout)))
            " ")))

;;
;;; Read-Only

(defun jcs-modeline--render-read-only ()
  "Render read-only indicator."
  (concat " "
          (propertize (if buffer-read-only
                          (or (jcs-modeline--char-displayable-p "🔒")
                              "&L")
                        (or (jcs-modeline--char-displayable-p "🔓")
                            "&U"))
                      'mouse-face 'mode-line-highlight
                      'help-echo (format "Buffer read-only: %s"
                                         (if buffer-read-only "ON" "OFF"))
                      'local-map (jcs-modeline--with-mouse-1
                                   (call-interactively #'read-only-mode)))))

;;
;;; Text Scale

(defvar text-scale-mode-amount)
(defvar text-scale-mode-lighter)

(defun jcs-modeline--render-text-scale ()
  "Render text-scale amount."
  (when (and (boundp 'text-scale-mode-lighter)
             (/= text-scale-mode-amount 0))
    (format "(%s) " (propertize text-scale-mode-lighter
                                'mouse-face 'mode-line-highlight
                                'help-echo (concat "Text scale " text-scale-mode-lighter)))))

;;
;;; Undo

(defun jcs-modeline--render-undo-tree-buffer-name ()
  "Render text-scale amount."
  (when-let* (((featurep 'undo-tree))
              ((equal (buffer-name) undo-tree-visualizer-buffer-name))
              (ind (buffer-name undo-tree-visualizer-parent-buffer)))
    (concat " "
            (propertize ind
                        'mouse-face 'mode-line-highlight
                        'help-echo "UndoTree Parent Buffer"))))

(defun jcs-modeline--undo-tree-branch-height (root)
  "Return the total height of the current branch from ROOT."
  (let ((count 0))
    (while (setq root (nth (undo-tree-node-branch root)
                           (undo-tree-node-next root)))
      (cl-incf count))
    count))

(defun jcs-modeline--undo-tree-height (node)
  "Return NODE's current height."
  (let ((count 0))
    (while (setq node (undo-tree-node-previous node))
      (cl-incf count))
    count))

(defun jcs-modeline--render-undo-tree-status ()
  "Render text-scale amount."
  (when-let* (((and (featurep 'undo-tree) buffer-undo-tree
                    (equal (buffer-name) undo-tree-visualizer-buffer-name)))
              (root (undo-tree-root buffer-undo-tree))
              (node (undo-tree-current buffer-undo-tree))
              (timestamp (undo-tree-node-timestamp node))
              (tree-height (jcs-modeline--undo-tree-height node))
              (tree-branch-height (jcs-modeline--undo-tree-branch-height root))
              (tree-count (undo-tree-count buffer-undo-tree))
              (tree-size (undo-tree-size buffer-undo-tree))
              (timestamp (string-trim (undo-tree-timestamp-to-string timestamp))))
    (concat " "
            (propertize (elenv-2str tree-height)
                        'mouse-face 'mode-line-highlight
                        'help-echo "UndoTree Height")
            "/"
            (propertize (elenv-2str tree-branch-height)
                        'mouse-face 'mode-line-highlight
                        'help-echo "UndoTree Branch Height")
            "/"
            (propertize (elenv-2str tree-count)
                        'mouse-face 'mode-line-highlight
                        'help-echo "UndoTree Count")
            " ("
            (propertize (elenv-2str tree-size)
                        'mouse-face 'mode-line-highlight
                        'help-echo "UndoTree Size")
            ") "
            (propertize (elenv-2str timestamp)
                        'mouse-face 'mode-line-highlight
                        'help-echo "UndoTree Timestamp"))))

;;
;;; Flymake

(defun jcs-modeline--flymake-lighter (diags-by-type state running)
  "Return flycheck lighter by given DIAGS-BY-TYPE and STATE.

If argument RUNNING is non-nil, we turn lighter into question mark."
  (let* ((c-state (cl-case state
                    (error   :error)
                    (warning :warning)
                    (note    :note)))
         (counts (length (gethash c-state diags-by-type)))
         (color (cdr (assoc state jcs-modeline-checker-colors)))
         (lighter (format "%s" (if running "?" counts))))
    (propertize lighter 'face `(:foreground ,color))))

(defun jcs-modeline--render-flymake ()
  "Render for flymake."
  (when (bound-and-true-p flymake-mode)
    (let* ((known (hash-table-keys flymake--state))
           (running (flymake-running-backends))
           (disabled (flymake-disabled-backends))
           (reported (flymake-reporting-backends))
           (diags-by-type (make-hash-table))
           (all-disabled (and disabled (null running)))
           (some-waiting (cl-set-difference running reported)))
      (maphash (lambda (_b state)
                 (mapc (lambda (diag)
                         (push diag
                               (gethash (flymake--diag-type diag)
                                        diags-by-type)))
                       (flymake--state-diags state)))
               flymake--state)
      (concat
       (let* ((states '(error warning note))
              (last (car (last states)))
              result)
         (dolist (state states)
           (when-let* ((lighter (jcs-modeline--flymake-lighter
                                 diags-by-type state
                                 (or some-waiting (null known) all-disabled))))
             (setq result (concat result lighter
                                  (unless (equal state last) "/")))))
         (propertize result
                     'mouse-face 'mode-line-highlight
                     'help-echo "flymake"
                     'local-map (jcs-modeline--with-mouse-1
                                  (flymake-goto-next-error))))
       " "))))

;;
;;; Flycheck

(defun jcs-modeline--flycheck-lighter (state running)
  "Return flycheck lighter by given STATE.

If argument RUNNING is non-nil, we turn lighter into question mark."
  (let* ((counts (flycheck-count-errors flycheck-current-errors))
         (err (or (cdr (assq state counts)) "0"))
         (color (cdr (assoc state jcs-modeline-checker-colors)))
         (lighter (format "%s" (if running "?" err))))
    (propertize lighter 'face `(:foreground ,color))))

(defun jcs-modeline--render-flycheck ()
  "Render for flycheck."
  (when (bound-and-true-p flycheck-mode)
    (concat
     (let* ((states '(error warning info))
            (last (car (last states)))
            (running (eq 'running flycheck-last-status-change))
            result)
       (dolist (state states)
         (when-let* ((lighter (jcs-modeline--flycheck-lighter state running)))
           (setq result (concat result lighter
                                (unless (equal state last) "/")))))
       (propertize result
                   'mouse-face 'mode-line-highlight
                   'help-echo "flycheck"
                   'local-map (jcs-modeline--with-mouse-1
                                (flycheck-next-error))))
     " ")))

;;
;;; CSV

(defvar csv-mode-line-format)

(defun jcs-modeline--render-csv ()
  "Render for `csv-mode'."
  (when-let* (((memq major-mode '(csv-mode tsv-mode)))
              (ind (format-mode-line csv-mode-line-format)))
    (concat (propertize ind
                        'mouse-face 'mode-line-highlight
                        'help-echo "csv")
            " ")))

;;
;;; Nov

(defvar nov-documents)
(defvar nov-documents-index)

(defun jcs-modeline--render-nov ()
  "Render for nov."
  (when-let* (((eq major-mode 'nov-mode))
              (ind (format "[%s/%s]" (1+ nov-documents-index) (length nov-documents))))
    (propertize ind
                'mouse-face 'mode-line-highlight
                'help-echo "[current page/totla page]")))

;;
;; (@* "Themes" )
;;

(defun jcs-modeline--set-color (ac-lst inac-lst)
  "Set `mode-line' theme faces with AC-LST and INAC-LST."
  (let ((state (frame-focus-state))
        (ac-0 (nth 0 ac-lst)) (ac-1 (nth 1 ac-lst))
        (ic-0 (nth 0 inac-lst)) (ic-1 (nth 1 inac-lst)))
    (set-face-foreground 'mode-line (if state ac-0 ic-0))
    (set-face-background 'mode-line (if state ac-1 ic-1))
    (set-face-foreground 'mode-line-inactive ic-0)
    (set-face-background 'mode-line-inactive ic-1)))

(defun jcs-modeline--set-border-color (color)
  "Set the border color with COLOR."
  (set-face-foreground 'vertical-border color)
  (set-face-foreground 'window-divider color))

(defun jcs-modeline--set-theme (ml-ac-lst ml-inac-lst bc)
  "Set the mode line theme.
ML-AC-LST : mode-line active list.  ML-INAC-LST : mode-line inactive list.
BC : border color."
  (jcs-modeline--set-color ml-ac-lst ml-inac-lst)
  (jcs-modeline--set-border-color bc))

(defun jcs-modeline-gray ()
  "Gray mode line."
  (interactive)
  (if (jcs-modeline--light-theme-p)
      (jcs-modeline--set-theme
       '("#1C1C1C" "#E5E5E5") '("#000000" "#D7D7D7") "#989898")
    (jcs-modeline--set-theme
     '("#D2D2D2" "#4D4D4D") '("#CCCCCC" "#333333") "#7E7E7E")))

(defun jcs-modeline-dark-green ()
  "Dark green mode line."
  (interactive)
  (if (jcs-modeline--light-theme-p)
      (jcs-modeline--set-theme
       '("#000" "#B7D3D3") '("#000" "#99C2C2") "#B7D3D3")
    (jcs-modeline--set-theme
     '("#CCCCCC" "#3C6A69") '("#CCCCCC" "#2B4D4D") "#3C6A69")))

(defun jcs-modeline-dark-blue ()
  "Dark blue mode line."
  (interactive)
  (if (jcs-modeline--light-theme-p)
      (jcs-modeline--set-theme
       '("#000" "#92B9DF") '("#000" "#7AA0C6") "#92B9DF")
    (jcs-modeline--set-theme
     '("#CCCCCC" "#205386") '("#CCCCCC" "#0C3765") "#246AAF")))

(defun jcs-modeline-dark-orange ()
  "Dark orange mode line."
  (interactive)
  (if (jcs-modeline--light-theme-p)
      (jcs-modeline--set-theme
       '("#1C1C1C" "#CC6633") '("#000000" "#682B12") "#CC6633")
    (jcs-modeline--set-theme
     '("#D2D2D2" "#CC6633") '("#CCCCCC" "#A4532A") "#CC6633")))

(defun jcs-modeline-red ()
  "Red mode line."
  (interactive)
  (if (jcs-modeline--light-theme-p)
      (jcs-modeline--set-theme
       '("#CCCCCC" "#FF0000") '("#CCCCCC" "#6A0101") "#FF0000")
    (jcs-modeline--set-theme
     '("#CCCCCC" "#FF0000") '("#CCCCCC" "#6A0101") "#FF0000")))

(defun jcs-modeline-purple ()
  "Purple mode line."
  (interactive)
  (if (jcs-modeline--light-theme-p)
      (jcs-modeline--set-theme
       '("#CCCCCC" "#B100EB") '("#CCCCCC" "#650286") "#B100EB")
    (jcs-modeline--set-theme
     '("#CCCCCC" "#B100EB") '("#CCCCCC" "#650286") "#B100EB")))

;;
;; (@* "Separator" )
;;

(defconst jcs-modeline--xpm-format "/* XPM */ static char * image[] = {
 \"%s %s 3 1\",
 \"0 c %s\",
 \"1 c %s\",
 \"2 c %s\",%s
};"
  "The XPM image format.")

(defun jcs-modeline-moody-arrow (direction c1 c2 c3 &optional height)
  "Separator, arrow."
  (unless height
    (setq height (or (if (functionp moody-mode-line-height)
                         (funcall moody-mode-line-height)
                       moody-mode-line-height)
                     (window-mode-line-height))))
  (setq height (* height moody-display-scale))
  (unless (cl-evenp height) (cl-incf height))
  (let ((key (list direction c1 c2 c3 height 'arrow-point)))
    (or (cdr (assoc key moody--cache))
        (when-let*
            ((width (/ height 3))
             (half-height (/ height 2.0))
             ((not (zerop half-height)))
             (image
              (create-image
               (format jcs-modeline--xpm-format
                       width height c1 c2 c3
                       (cl-loop
                        for i from 0 below height concat
                        (format " \"%s\",\n"
                                (let* ((x (round (- width (* width (/ (abs (- i half-height)) half-height)))))
                                       (a (make-string (max 0 x) ?0))
                                       (b (make-string 1 ?1))
                                       (c (make-string (max 0 (- width x 1)) ?2)))
                                  (if (eq direction 'down)
                                      (concat a b c)
                                    (concat (reverse c) b (reverse a)))))))
               'xpm t :scale (/ 1.0 moody-display-scale) :ascent 'center)))
          (push (cons key image) moody--cache)
          image))))

(defun jcs-modeline-moody-wave (direction c1 c2 c3 &optional height)
  "Separator, wave."
  (unless height
    (setq height (or (if (functionp moody-mode-line-height)
                         (funcall moody-mode-line-height)
                       moody-mode-line-height)
                     (window-mode-line-height))))
  (setq height (* height moody-display-scale))
  (unless (cl-evenp height) (cl-incf height))
  (let ((key (list direction c1 c2 c3 height 'sin-wave)))
    (or (cdr (assoc key moody--cache))
        (let* ((width (/ height 3))
               (image
                (create-image
                 (format
                  jcs-modeline--xpm-format
                  width height c1 c2 c3
                  (cl-loop
                   for i from 0 below height concat
                   (format " \"%s\",\n"
                           (let* ((v (/ i (float (1- height))))
                                  (f (cos (* 2.0 v)))
                                  ;;(x (round (* f (1- width))))
                                  (x (round (- (1- width) (* f (1- width)))))
                                  (a (make-string (max 0 x) ?0))
                                  (b (make-string 1 ?1))
                                  (c (make-string (max 0 (- width x 1)) ?2)))
                             (if (eq direction 'down)
                                 (concat a b c)
                               (concat (reverse c) b (reverse a)))))))
                 'xpm t
                 :scale (/ 1.0 moody-display-scale)
                 :ascent 'center)))
          (push (cons key image) moody--cache)
          image))))

(provide 'jcs-modeline)
;;; jcs-modeline.el ends here
