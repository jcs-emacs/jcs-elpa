;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "0.1.0.0.20260615.131"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "35f6b8f1330049f20766d827148a7a1e261852e7"
  :revdesc "35f6b8f13300"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
