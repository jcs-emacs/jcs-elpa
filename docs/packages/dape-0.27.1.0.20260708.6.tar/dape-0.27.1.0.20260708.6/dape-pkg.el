;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260708.6"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "29a3cbfddaf93e578e24b655516b599b23531c0e"
  :revdesc "29a3cbfddaf9"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
