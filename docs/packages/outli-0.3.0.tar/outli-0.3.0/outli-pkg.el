;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outli" "0.3.0"
  "Org-like code outliner."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/outli"
  :commit "009e74c1757143040a0427f477ae882107b14592"
  :revdesc "009e74c17571"
  :keywords '("convenience" "outlines" "org")
  :authors '(("J.D. Smith" . "jdtsmith@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith@gmail.com")))
