;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.30.3.0.20260520.5"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "26961977ac2711c096e78550559d6c18e2daebb9"
  :revdesc "26961977ac27"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
