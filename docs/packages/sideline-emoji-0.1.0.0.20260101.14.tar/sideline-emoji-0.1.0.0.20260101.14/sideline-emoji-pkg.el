;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-emoji" "0.1.0.0.20260101.14"
  "Show emoji information with sideline."
  '((emacs    "27.1")
    (sideline "0.1.0")
    (emojify  "1.2.1")
    (ht       "2.4"))
  :url "https://github.com/emacs-sideline/sideline-emoji"
  :commit "cfc8f8c4c31d00e0c619936dac0ea1a3085be7f8"
  :revdesc "cfc8f8c4c31d"
  :keywords '("convenience" "sideline" "emoji")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
