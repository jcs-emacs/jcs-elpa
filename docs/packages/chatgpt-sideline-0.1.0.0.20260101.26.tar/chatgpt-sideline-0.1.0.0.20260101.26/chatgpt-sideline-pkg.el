;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-sideline" "0.1.0.0.20260101.26"
  "Sideline support for chatgpt."
  '((emacs    "28.1")
    (chatgpt  "0.1.0")
    (sideline "0.1.0"))
  :url "https://github.com/emacs-openai/chatgpt-sideline"
  :commit "f874f71994005fb394510b3ceda399cda28c7ef4"
  :revdesc "f874f7199400"
  :keywords '("convenience" "chatgpt" "ai")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
