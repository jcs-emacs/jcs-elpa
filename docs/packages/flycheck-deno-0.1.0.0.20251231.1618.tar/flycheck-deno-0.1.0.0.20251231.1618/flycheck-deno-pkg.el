;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-deno" "0.1.0.0.20251231.1618"
  "Flycheck for deno-lint."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/flycheck/flycheck-deno"
  :commit "27c2f2a4d5edcc4ddce06a42bf49a3f6b36e8f1f"
  :revdesc "27c2f2a4d5ed"
  :keywords '("lisp" "deno")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
