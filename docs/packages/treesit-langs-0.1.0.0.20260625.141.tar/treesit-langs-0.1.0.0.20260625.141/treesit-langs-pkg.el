;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "0.1.0.0.20260625.141"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "e304bcf3c908668df45e37f0d88ec76927906106"
  :revdesc "e304bcf3c908"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
