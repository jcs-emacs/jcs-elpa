;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0.0.20261015.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "d3606d9bf1803600b86f52abaf17552da7c731c5"
  :revdesc "d3606d9bf180"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
