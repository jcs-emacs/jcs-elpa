;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-uniteai" "0.1.0.0.20260503.35"
  "LSP Clients for UniteAI."
  '((emacs    "29.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-openai/lsp-uniteai"
  :commit "7ce0a1a56fe5f0afbeba5d37bee1732443a93f43"
  :revdesc "7ce0a1a56fe5"
  :keywords '("convenience" "ai")
  :authors '(("Josh Freckleton" . "freckletonj@gmail.com")
             ("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("JenChieh" . "jcs090218@gmail.com")))
