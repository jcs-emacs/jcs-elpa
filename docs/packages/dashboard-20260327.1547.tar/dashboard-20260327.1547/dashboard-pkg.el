;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260327.1547"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/dashboard"
  :commit "f28b8e1c5f895c1dbf908a0550303a1de37fa259"
  :revdesc "f28b8e1c5f89"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
