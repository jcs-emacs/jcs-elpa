;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-buffers" "0.1.0.20240715.24"
  "Clean useless buffers."
  '((emacs "26.1"))
  :url "https://github.com/elp-revive/clean-buffers"
  :commit "fec82f624da40b85e74cc0ea75e29c28d247911d"
  :revdesc "fec82f624da4"
  :keywords '("convenience" "usability" "buffers")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
