;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-mode" "1.0.0.20260601.301086"
  "Major mode for the LLVM assembler language."
  '((emacs "24.3"))
  :url "http://llvm.org/"
  :commit "080286d051efe040c8678aef122d235785d74d5e"
  :revdesc "080286d051ef")
