;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "21e79e0de52e1f134516b7c92d38e3b18b0a4ba1"
  :revdesc "21e79e0de52e"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
