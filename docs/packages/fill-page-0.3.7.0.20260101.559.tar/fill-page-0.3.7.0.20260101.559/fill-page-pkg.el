;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fill-page" "0.3.7.0.20260101.559"
  "Fill buffer so you don't see empty lines at the end."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/fill-page"
  :commit "c9bc538f72869f572bf71c95d2b9b6dac5b4b169"
  :revdesc "c9bc538f7286"
  :keywords '("convenience" "fill" "page" "buffer")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
