;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.9.0.0.20261009.15"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "57d3c921d87d68568732b2e72810173d0aad652d"
  :revdesc "57d3c921d87d"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
