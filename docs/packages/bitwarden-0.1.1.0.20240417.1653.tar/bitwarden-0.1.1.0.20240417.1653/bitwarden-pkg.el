;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitwarden" "0.1.1.0.20240417.1653"
  "Bitwarden command wrapper."
  '((emacs "25.1"))
  :url "https://github.com/seanfarley/emacs-bitwarden"
  :commit "50c0078d356e0ac0bcaf26b40113700ba4123ec3"
  :revdesc "50c0078d356e"
  :keywords '("extensions" "processes" "bw" "bitwarden"))
