;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "resurrect" "0.0.0.0.20140829.1717"
  "[No description available]."
  ()
  :url "https://github.com/fbkante/resurrect"
  :commit "e1bf23fec27989a7a7b9d5ffc827752aea094c29"
  :revdesc "e1bf23fec279"
  :keywords '("convenience"))
