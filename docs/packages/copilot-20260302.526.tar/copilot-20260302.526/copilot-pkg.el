;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260302.526"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "08f96b753e38169d8d80459487744ba6b3ae2c4a"
  :revdesc "08f96b753e38"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
