;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "execrun" "0.1.0.0.20260101.40"
  "Run through `compilation-mode'."
  '((emacs "26.1")
    (ffpc  "0.1.0")
    (f     "0.20.0"))
  :url "https://github.com/jcs-elpa/execrun"
  :commit "aa6ef050e49548bf943e06d2b1580e31332fcc2a"
  :revdesc "aa6ef050e495"
  :keywords '("tools")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
