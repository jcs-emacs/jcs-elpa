;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "0.2.0.0.20260407.9"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion.el"
  :commit "460cdd5a73d857d6d91469e28f84f02465db8dac"
  :revdesc "460cdd5a73d8"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
