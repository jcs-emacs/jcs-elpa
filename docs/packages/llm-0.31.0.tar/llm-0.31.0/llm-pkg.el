;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.0"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "8bb1d42ab7e112a535a608c7a2538350f469e7b9"
  :revdesc "8bb1d42ab7e1"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
