;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "4.0.0.0.20260510.2151"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "fecc57e36f802fdb85e9c08acc00842c2b77a0ee"
  :revdesc "4.0.0-229-gfecc57e36f80"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
