;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260417.2107"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "a95a1f0fbcca706111f4352ad1fcd40875674ddc"
  :revdesc "a95a1f0fbcca"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
