;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-point-history" "0.0.3.0.20200726.1639"
  "Point-history with ivy interface."
  '((point-history "0.1.0")
    (ivy           "0.11.0"))
  :url "https://github.com/SuzumiyaAoba/ivy-point-history"
  :commit "5d450a91656503c98a548557a563ee99d65b46b3"
  :revdesc "5d450a916565")
