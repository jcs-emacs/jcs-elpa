;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-tailwindcss" "0.6.0.0.20230119.2346"
  "Company mode for tailwind css suggestions."
  '((emacs   "26.1")
    (company "0.8.0")
    (dash    "2.19.1"))
  :url "https://github.com/tyler-dodge/company-tailwindcss"
  :commit "d94d90df23131cc59ce9b1e1619f04110bbcfa91"
  :revdesc "d94d90df2313"
  :keywords '("convenience" "matching"))
