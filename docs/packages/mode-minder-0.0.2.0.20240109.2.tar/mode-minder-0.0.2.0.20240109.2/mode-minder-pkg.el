;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-minder" "0.0.2.0.20240109.2"
  "List all major and minor modes."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/mode-minder"
  :commit "5ada69ca537d7b06daddf6181419b9205415eb89"
  :revdesc "5ada69ca537d"
  :keywords '("modes")
  :authors '(("J.D. Smith" . "jdtsmith@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith@gmail.com")))
