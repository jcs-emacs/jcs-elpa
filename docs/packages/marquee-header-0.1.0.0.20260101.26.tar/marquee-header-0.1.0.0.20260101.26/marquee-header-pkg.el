;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marquee-header" "0.1.0.0.20260101.26"
  "Code interface for displaying marquee in header."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/marquee-header"
  :commit "c0e884eea86ef818a652dba9a1719b50489813a6"
  :revdesc "c0e884eea86e"
  :keywords '("wp" "animation" "marquee")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
