;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jayces-mode" "0.0.2.0.20260410.69"
  "Major mode for editing JayCeS file."
  '((emacs "26.1"))
  :url "https://github.com/jayces-lang/jayces-mode"
  :commit "a58b5474b933e6a91fe0a66c7d94c99648e15122"
  :revdesc "a58b5474b933"
  :keywords '("lisp" "jayces")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
