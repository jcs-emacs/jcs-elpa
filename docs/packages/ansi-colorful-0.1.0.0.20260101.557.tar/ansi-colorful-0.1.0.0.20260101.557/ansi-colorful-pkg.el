;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansi-colorful" "0.1.0.0.20260101.557"
  "Toggle render ansi-color."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/ansi-colorful"
  :commit "ec9aa6dd8dacb875ed7c5552f5e8c19db67b5b4b"
  :revdesc "ec9aa6dd8dac"
  :keywords '("faces")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
