;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260419.2155"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "f2f9fb60596196b6f8a062a5a66631bb5b37b611"
  :revdesc "f2f9fb605961"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
