;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.5.0.0.20260615.7"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "99a6cafa7e5f7fab33552f881174b672ee512b72"
  :revdesc "99a6cafa7e5f"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
