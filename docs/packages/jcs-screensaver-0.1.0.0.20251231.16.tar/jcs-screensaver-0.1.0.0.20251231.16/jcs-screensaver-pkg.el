;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jcs-screensaver" "0.1.0.0.20251231.16"
  "A screensaver for jcs-emacs."
  '((emacs       "26.3")
    (snow        "0.1")
    (zoom-window "0.06")
    (msgu        "0.1.0"))
  :url "https://github.com/jcs-emacs/jcs-screensaver"
  :commit "4e34534e1432956a711d5aa0b9c8e07948238f0c"
  :revdesc "4e34534e1432"
  :keywords '("tools")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
