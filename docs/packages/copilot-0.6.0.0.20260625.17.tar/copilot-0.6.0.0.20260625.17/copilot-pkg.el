;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.6.0.0.20260625.17"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "39aba120183b1836164c8c99eb005fa125290d9a"
  :revdesc "39aba120183b"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
