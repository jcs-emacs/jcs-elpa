;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-odin" "0.0.0.20210218.11"
  "[No description available]."
  ()
  :url "https://github.com/mattt-b/flycheck-odin"
  :commit "704c8a327bf5ef5f6c6e23df0ed560a61ba177a7"
  :revdesc "704c8a327bf5")
