;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260428.1945"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "cd09b654a6d8b8638ff64d1c472041d4e1d02521"
  :revdesc "cd09b654a6d8"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
