;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "font-lock-ext" "0.0.0.20171030.4"
  "Extensions to Emacs font-lock.el."
  ()
  :url "https://github.com/sensorflo/font-lock-ext/"
  :commit "b6c82e8ac7996d96494a54454015a98ceb883feb"
  :revdesc "b6c82e8ac799"
  :keywords '("languages" "faces")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Florian Kaufmann" . "sensorflo@gmail.com")))
