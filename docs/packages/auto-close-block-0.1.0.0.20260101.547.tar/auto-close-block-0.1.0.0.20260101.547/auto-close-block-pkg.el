;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-close-block" "0.1.0.0.20260101.547"
  "Automatically close block."
  '((emacs "26.1"))
  :url "https://github.com/emacs-vs/auto-close-block"
  :commit "f84bc6c36af797b881bf7823364a84eb5f66923b"
  :revdesc "f84bc6c36af7"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
