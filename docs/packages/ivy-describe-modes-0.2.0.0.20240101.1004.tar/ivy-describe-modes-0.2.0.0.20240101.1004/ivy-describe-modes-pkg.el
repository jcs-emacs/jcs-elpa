;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-describe-modes" "0.2.0.0.20240101.1004"
  "Ivy interface to `describe-mode`."
  '((emacs "24.4")
    (ivy   "0.13.0"))
  :url "https://github.com/jcs-elpa/ivy-describe-modes"
  :commit "31e6f8b69c4a051b01ddc17bd263cc900d2f6deb"
  :revdesc "31e6f8b69c4a"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
