;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-grammarly" "0.1.0.0.20251231.1727"
  "Eglot Clients for Grammarly."
  '((emacs "29.1")
    (eglot "1.4"))
  :url "https://github.com/emacs-grammarly/eglot-grammarly"
  :commit "92ae743c2fd29b20eb84b75c92adbe61d7586535"
  :revdesc "92ae743c2fd2"
  :keywords '("convenience" "eglot" "grammarly" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
