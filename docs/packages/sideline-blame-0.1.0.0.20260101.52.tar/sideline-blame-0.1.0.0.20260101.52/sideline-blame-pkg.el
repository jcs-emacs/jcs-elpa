;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-blame" "0.1.0.0.20260101.52"
  "Show blame messages with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0")
    (vc-msg   "1.1.1"))
  :url "https://github.com/emacs-sideline/sideline-blame"
  :commit "107479557021dbfcb27ad26a8e357c73e9b1249e"
  :revdesc "107479557021"
  :keywords '("convenience" "blame")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
