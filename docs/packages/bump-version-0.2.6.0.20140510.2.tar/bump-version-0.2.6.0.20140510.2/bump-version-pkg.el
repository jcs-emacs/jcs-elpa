;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bump-version" "0.2.6.0.20140510.2"
  "Emacs package which helps bump version."
  ()
  :url "https://github.com/atykhonov/emacs-bump-version"
  :commit "be213c9fd843f6f76560333e275f73e20181d50b"
  :revdesc "be213c9fd843"
  :keywords '("tool")
  :authors '(("Andrey Tykhonov" . "atykhonov@gmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
