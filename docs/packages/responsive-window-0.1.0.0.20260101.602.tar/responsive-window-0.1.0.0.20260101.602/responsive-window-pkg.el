;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "responsive-window" "0.1.0.0.20260101.602"
  "Adapt to different screen sizes automatically."
  '((emacs "26.1")
    (elenv "0.1.0"))
  :url "https://github.com/jcs-elpa/responsive-window"
  :commit "a5394eb2cfcede890a24a126db584e8acf3f48ea"
  :revdesc "a5394eb2cfce"
  :keywords '("frames")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
