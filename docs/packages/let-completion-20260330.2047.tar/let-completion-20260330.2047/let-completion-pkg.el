;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260330.2047"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion.el"
  :commit "e103218c0d96c14e82b11c05f91cb34a1cbd0dc2"
  :revdesc "e103218c0d96"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
