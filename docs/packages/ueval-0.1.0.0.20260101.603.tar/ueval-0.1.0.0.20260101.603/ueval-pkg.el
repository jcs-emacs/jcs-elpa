;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ueval" "0.1.0.0.20260101.603"
  "Universal Evaluation Utilities."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/ueval"
  :commit "00cbad0e5bed59c74ca183bef86dd41d987e2caf"
  :revdesc "00cbad0e5bed"
  :keywords '("convenience" "eval")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
