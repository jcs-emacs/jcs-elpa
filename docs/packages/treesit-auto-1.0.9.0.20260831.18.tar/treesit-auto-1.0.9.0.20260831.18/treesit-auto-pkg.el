;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-auto" "1.0.9.0.20260831.18"
  "Automatically use tree-sitter enhanced major modes."
  '((emacs "29.0"))
  :url "https://github.com/renzmann/treesit-auto.git"
  :commit "3106c739c2a84bec2cb671997fe074e5dd5dd967"
  :revdesc "v1.0.9-18-g3106c739c2a8"
  :keywords '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :authors '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers '(("Robb Enzmann" . "robbenzmann@gmail.com")))
