;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260406.1238"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "6c1203cf1210ba2936206098f5f00aea3792e0d0"
  :revdesc "6c1203cf1210"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
