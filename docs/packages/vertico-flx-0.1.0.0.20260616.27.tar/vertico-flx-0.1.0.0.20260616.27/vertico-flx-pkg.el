;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico-flx" "0.1.0.0.20260616.27"
  "Flx integration for vertico."
  '((emacs     "29.1")
    (vertico   "0.22")
    (flx       "0.5")
    (flx-style "0.1.0")
    (ht        "2.0")
    (f         "0.20.0")
    (mbs       "0.1.0")
    (s         "1.12.0"))
  :url "https://github.com/jcs-elpa/vertico-flx"
  :commit "eee365f0156af8953ffe9cb83bd835e482f28f87"
  :revdesc "eee365f0156a"
  :keywords '("convenience" "vertico" "flx")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
