;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.0.0.20260621.4"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "052383501f3afe5c41c338b4dd33d292c5c55621"
  :revdesc "052383501f3a"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
