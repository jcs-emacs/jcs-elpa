;;; aws.el --- AWS Toolkit  -*- lexical-binding: t; -*-

;; Copyright (C) 2023  Shen, Jen-Chieh

;; Author: Shen, Jen-Chieh <jcs090218@gmail.com>
;; Maintainer: Shen, Jen-Chieh <jcs090218@gmail.com>
;; URL: https://github.com/jcs090218/aws-toolkit-emacs
;; Package-Version: 0.0.1.0.20251231.14
;; Package-Revision: 59250e6a2d5e
;; Package-Requires: ((emacs "27.1") (lsp-mode "6.1"))
;; Keywords: aws convenience

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; AWS Toolkit
;;

;;; Code:

(require 'lsp-mode)

(defgroup aws nil
  "AWS Toolkit."
  :prefix "aws-"
  :group 'tool
  :link '(url-link :tag "Repository" "https://github.com/jcs090218/aws-toolkit-emacs"))

(defun aws--execute (cmd &rest args)
  "Return non-nil if CMD executed succesfully with ARGS."
  (save-window-excursion
    (lsp-ltex--mute-apply
      (= 0 (shell-command (concat cmd " "
                                  (mapconcat #'shell-quote-argument
                                             (cl-remove-if #'null args)
                                             " ")))))))

(provide 'aws)
;;; aws.el ends here
