;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.5.0.20260325.433"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "30.1.0.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "7d598ceeeec7d9252f88d53a914b0539fb06ef93"
  :revdesc "7d598ceeeec7"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
