;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260305.616"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "fdea2fc1ef0ebab7af337e3925d663063651ff46"
  :revdesc "fdea2fc1ef0e"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
