;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-translate-cli" "20260217.1241"
  "A command-line interface for Google Translate."
  '((emacs            "26.1")
    (google-translate "0.12.0")
    (commander        "0.7.0")
    (msgu             "0.1.0"))
  :url "https://github.com/emacs-eine/google-translate-cli"
  :commit "2abd3410ea834129f0c873e9ee150fdeddf29849"
  :revdesc "2abd3410ea83"
  :keywords '("convenience")
  :authors '(("Jen-Chieh Shen" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
