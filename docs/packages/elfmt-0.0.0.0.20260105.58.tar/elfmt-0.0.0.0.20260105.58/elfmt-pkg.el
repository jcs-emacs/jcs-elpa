;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfmt" "0.0.0.0.20260105.58"
  "Code formatter for Elisp."
  '((emacs "24.3"))
  :url "https://github.com/riscy/elfmt"
  :commit "b0c5264324742ecfa88b1f381a0ccbb30cad90f7"
  :revdesc "b0c526432474"
  :keywords '("lisp")
  :authors '((nil . "https://github.com/riscy/elfmt/graphs/contributors"))
  :maintainers '(("Chris Rayner" . "dchrisrayner@gmail.com")))
