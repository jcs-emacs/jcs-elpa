;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "2.30.4.0.20260722.33"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.82.3")
    (transient   "0.9.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "1e0e5c7af3a30de78b2e527679464b4cc6a18b21"
  :revdesc "1e0e5c7af3a3")
