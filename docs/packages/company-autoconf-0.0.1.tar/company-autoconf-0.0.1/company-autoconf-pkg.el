;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-autoconf" "0.0.1"
  "Completion for autoconf script."
  '((emacs   "26.1")
    (company "0.8.12"))
  :url "https://github.com/elp-revive/company-autoconf"
  :commit "1a1439e597bb1bd7be73f8c473ebb30b1dcc76ea"
  :revdesc "1a1439e597bb"
  :keywords '("convenience")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
