;;; e-unit-test-mode.el --- Minor mode for e-unit test development -*- lexical-binding: t -*-

;; Copyright (C) 2025
;; SPDX-License-Identifier: GPL-3.0-only

;; Author: E-Unit Contributors
;; Keywords: tools, lisp, testing
;; URL: https://codeberg.org/Trevoke/eunit.el

;;; Commentary:

;; E-Unit Test Mode provides IDE-like features for e-unit test development:
;;
;; - Quick test running via keybindings
;; - Visual pass/fail indicators (fringe + inline)
;; - Test navigation (imenu, popup list, speedbar)
;; - Syntax highlighting for test keywords
;; - Completion for assertions and test names
;; - YASnippet templates (optional)
;;
;; Usage:
;;
;; The mode activates automatically for files matching *-test.el
;; Bind the keymap to your preferred prefix:
;;
;;   (define-key emacs-lisp-mode-map (kbd "C-c ,") e-unit-test-map)
;;
;; Available commands:
;;   C-c , v - Run all tests in buffer
;;   C-c , s - Run test at point
;;   C-c , r - Re-run last test
;;   C-c , f - Run failed tests
;;   C-c , a - Run all tests in directory
;;   C-c , l - Show test list popup
;;   C-c , c - Clear test overlays

;;; Code:

(require 'e-unit)
(require 'which-func)
(require 'cl-lib)

;;; Customization

(defgroup e-unit-test nil
  "Minor mode for e-unit test development."
  :group 'tools
  :prefix "e-unit-test-")

(defcustom e-unit-test-show-inline-errors t
  "Whether to show inline error messages for failed tests."
  :type 'boolean
  :group 'e-unit-test)

(defcustom e-unit-test-show-fringe-indicators t
  "Whether to show fringe indicators for test status."
  :type 'boolean
  :group 'e-unit-test)

;;; Faces

(defface e-unit-test-pass
  '((t :foreground "green"))
  "Face for passing tests."
  :group 'e-unit-test)

(defface e-unit-test-fail
  '((t :foreground "red"))
  "Face for failing tests."
  :group 'e-unit-test)

(defface e-unit-test-error
  '((t :foreground "yellow"))
  "Face for tests with errors."
  :group 'e-unit-test)

(defface e-unit-test-skip
  '((t :foreground "gray"))
  "Face for skipped tests."
  :group 'e-unit-test)

(defface e-unit-test-inline-message
  '((t :background "#3a0000" :italic t :height 0.9))
  "Face for inline error messages."
  :group 'e-unit-test)

(defface e-unit-test-keyword
  '((t :inherit font-lock-keyword-face :weight bold))
  "Face for test keywords like deftest."
  :group 'e-unit-test)

(defface e-unit-test-assertion
  '((t :inherit font-lock-function-name-face))
  "Face for assertion functions."
  :group 'e-unit-test)

(defface e-unit-test-hook
  '((t :inherit font-lock-builtin-face))
  "Face for lifecycle hooks."
  :group 'e-unit-test)

;;; Internal Variables

(defvar-local e-unit-test--last-results nil
  "Results from last test run.")

(defvar-local e-unit-test--last-test nil
  "Last test run in this buffer.")

;;; Font-Lock

(defconst e-unit-test--font-lock-keywords
  `(;; Test definitions
    (,(rx symbol-start
          (or "deftest" "deftest-parameterized"
              "e-unit-deftest" "e-unit-deftest-parameterized")
          symbol-end)
     . 'e-unit-test-keyword)

    ;; Lifecycle hooks
    (,(rx symbol-start
          (or "setup-each" "teardown-each" "setup-file" "teardown-file"
              "setup-suite" "teardown-suite"
              "around-each" "around-file" "around-suite"
              "e-unit-setup-each" "e-unit-teardown-each"
              "e-unit-setup-file" "e-unit-teardown-file"
              "e-unit-setup-suite" "e-unit-teardown-suite"
              "e-unit-around-each" "e-unit-around-file" "e-unit-around-suite")
          symbol-end)
     . 'e-unit-test-hook)

    ;; Assertions - all unprefixed versions
    (,(rx symbol-start
          (or "assert-equal" "assert-true" "assert-nil" "assert-not-equal"
              "assert-same" "assert-not-same" "assert-false"
              "assert-in-delta" "assert-in-epsilon"
              "assert-includes" "assert-empty" "assert-length"
              "assert-instance-of" "assert-kind-of" "assert-responds-to"
              "assert-predicate" "assert-operator" "assert-match" "assert-raises"
              "refute-nil" "refute-in-delta" "refute-in-epsilon"
              "refute-includes" "refute-empty" "refute-match")
          symbol-end)
     . 'e-unit-test-assertion)

    ;; Assertions - all prefixed versions
    (,(rx symbol-start
          (or "e-unit-assert-equal" "e-unit-assert-true" "e-unit-assert-nil"
              "e-unit-assert-not-equal" "e-unit-assert-same" "e-unit-assert-not-same"
              "e-unit-assert-false" "e-unit-assert-in-delta" "e-unit-assert-in-epsilon"
              "e-unit-assert-includes" "e-unit-assert-empty" "e-unit-assert-length"
              "e-unit-assert-instance-of" "e-unit-assert-kind-of"
              "e-unit-assert-responds-to" "e-unit-assert-predicate"
              "e-unit-assert-operator" "e-unit-assert-match" "e-unit-assert-raises"
              "e-unit-refute-nil" "e-unit-refute-in-delta" "e-unit-refute-in-epsilon"
              "e-unit-refute-includes" "e-unit-refute-empty" "e-unit-refute-match")
          symbol-end)
     . 'e-unit-test-assertion))
  "Font-lock keywords for e-unit-test-mode.")

;;; Imenu Integration

(defun e-unit-test--imenu-create-index ()
  "Create imenu index for tests in buffer."
  (let ((tests (e-unit-test--find-tests-in-buffer))
        index)
    (save-excursion
      (goto-char (point-min))
      (dolist (test tests)
        (when (re-search-forward (format "^\\s-*(\\(?:deftest\\|e-unit-deftest\\)\\s-+%s\\b" test) nil t)
          (push (cons (symbol-name test) (point)) index))))
    (nreverse index)))

;;; Completion

(defconst e-unit-test--assertion-functions
  '("assert-equal" "assert-true" "assert-nil" "assert-not-equal"
    "assert-same" "assert-not-same" "refute-nil" "assert-false"
    "assert-in-delta" "assert-in-epsilon" "refute-in-delta" "refute-in-epsilon"
    "assert-includes" "refute-includes" "assert-empty" "refute-empty"
    "assert-length" "assert-instance-of" "assert-kind-of" "assert-responds-to"
    "assert-predicate" "assert-operator" "assert-match" "refute-match" "assert-raises"
    "e-unit-assert-equal" "e-unit-assert-true" "e-unit-assert-nil")
  "List of e-unit assertion function names for completion.")

(defun e-unit-test--completion-at-point ()
  "Provide completion for assertions and test names."
  (let ((bounds (bounds-of-thing-at-point 'symbol)))
    (when bounds
      (let ((start (car bounds))
            (end (cdr bounds))
            (prefix (buffer-substring-no-properties (car bounds) (cdr bounds))))
        ;; Complete assertions when typing assert- or refute-
        (when (or (string-prefix-p "assert-" prefix)
                  (string-prefix-p "refute-" prefix)
                  (string-prefix-p "e-unit-assert-" prefix)
                  (string-prefix-p "e-unit-refute-" prefix))
          (list start end e-unit-test--assertion-functions))))))

;;; Test Discovery

(defun e-unit-test--find-tests-in-buffer ()
  "Find all deftest forms in current buffer.
Returns a list of test symbols."
  (save-excursion
    (goto-char (point-min))
    (let (tests)
      (while (re-search-forward "^\\s-*(deftest\\s-+\\([[:word:]-]+\\)" nil t)
        (let ((test-name (intern (match-string 1))))
          (push test-name tests)))
      (nreverse tests))))

(defun e-unit-test--find-test-at-point ()
  "Find test name at point, or nil if not inside a test.
Uses `which-function' to determine enclosing deftest."
  (let ((func (which-function)))
    (when (and func
               (stringp func)
               (string-prefix-p "test-" func))
      (intern func))))

;;; Keymap

(defvar e-unit-test-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd ", v") #'e-unit-test-run-buffer)
    (define-key map (kbd ", s") #'e-unit-test-run-at-point)
    (define-key map (kbd ", r") #'e-unit-test-run-last)
    (define-key map (kbd ", f") #'e-unit-test-run-failed)
    (define-key map (kbd ", a") #'e-unit-test-run-all)
    (define-key map (kbd ", l") #'e-unit-test-show-list)
    (define-key map (kbd ", c") #'e-unit-test-clear-overlays)
    map)
  "Keymap for e-unit-test-mode commands.
Users typically bind this to a prefix like:
  (define-key emacs-lisp-mode-map (kbd \"C-c ,\") e-unit-test-map)")

;;; Test Running

(defvar-local e-unit-test--last-command nil
  "Last test command run, for re-running.")

(defun e-unit-test-run-buffer ()
  "Run all tests in current buffer with `compilation-mode' output."
  (interactive)
  (let ((file (buffer-file-name)))
    (unless file
      (user-error "Buffer has no file"))
    (setq e-unit-test--last-command `(buffer ,file))
    (e-unit-run-buffer-compilation)))

(defun e-unit-test-run-at-point ()
  "Run test at point."
  (interactive)
  (let* ((file (buffer-file-name))
         (test (e-unit-test--find-test-at-point)))
    (unless file
      (user-error "Buffer has no file"))
    (unless test
      (user-error "No test at point"))
    (setq e-unit-test--last-command `(test ,file ,test))
    ;; Run single test using non-compilation version
    ;; (compilation version doesn't support filtering yet)
    (e-unit-run-test test)))

(defun e-unit-test-run-last ()
  "Re-run last test command."
  (interactive)
  (unless e-unit-test--last-command
    (user-error "No previous test command"))
  (pcase e-unit-test--last-command
    (`(buffer ,file)
     (with-current-buffer (find-file-noselect file)
       (e-unit-test-run-buffer)))
    (`(test ,file ,test)
     (with-current-buffer (find-file-noselect file)
       (e-unit-run-test test)))
    (`(directory ,dir)
     (let ((default-directory dir))
       (e-unit-run-directory-compilation)))
    (`(failed ,tests)
     ;; Re-run the failed tests
     (let ((pattern (regexp-opt (mapcar #'symbol-name tests))))
       (e-unit-run-pattern pattern)))
    (_ (user-error "Unknown command type: %s" e-unit-test--last-command))))

(defun e-unit-test-run-failed ()
  "Run failed tests from last run."
  (interactive)
  (unless e-unit-test--last-results
    (user-error "No previous test results"))
  (let ((failed-tests (cl-loop for (test . result) in e-unit-test--last-results
                               when (memq (plist-get result :status) '(fail error))
                               collect test)))
    (if failed-tests
        (progn
          (setq e-unit-test--last-command `(failed ,failed-tests))
          (message "Re-running %d failed tests" (length failed-tests))
          ;; Run with pattern matching failed tests
          (let ((pattern (regexp-opt (mapcar #'symbol-name failed-tests))))
            (e-unit-run-pattern pattern)))
      (message "No failed tests to re-run"))))

(defun e-unit-test-run-all ()
  "Run all tests in directory."
  (interactive)
  (let ((dir (or (locate-dominating-file default-directory "test")
                 default-directory)))
    (setq e-unit-test--last-command `(directory ,dir))
    (let ((default-directory dir))
      (e-unit-run-directory-compilation))))

;;; Result Parsing

(defun e-unit-test--parse-compilation-output ()
  "Parse compilation buffer to extract test results.
Returns alist: ((test-name . (:status STATUS :message MSG)) ...)
where STATUS is one of: pass, fail, error, skip."
  ;; TODO: Parse *compilation* buffer output
  ;; For now, return empty list
  nil)

(defun e-unit-test--update-result-cache ()
  "Update `e-unit-test--last-results' from compilation output."
  (setq e-unit-test--last-results (e-unit-test--parse-compilation-output)))

;;; Overlay System

(defun e-unit-test--update-overlays ()
  "Update all test overlays based on cached results."
  (when e-unit-test-show-fringe-indicators
    (e-unit-test-clear-overlays)
    (save-excursion
      (dolist (result e-unit-test--last-results)
        (let* ((test-name (car result))
               (test-data (cdr result))
               (status (plist-get test-data :status))
               (message (plist-get test-data :message)))
          (goto-char (point-min))
          (when (re-search-forward (format "^\\s-*(\\(?:deftest\\|e-unit-deftest\\)\\s-+%s\\b" test-name) nil t)
            (let ((pos (line-beginning-position)))
              ;; Create fringe indicator
              (e-unit-test--create-fringe-overlay pos status)
              ;; Create inline message if failed/error
              (when (and e-unit-test-show-inline-errors
                         message
                         (memq status '(fail error)))
                (e-unit-test--create-inline-overlay pos message)))))))))

(defun e-unit-test--create-fringe-overlay (pos status)
  "Create fringe indicator overlay at POS for STATUS."
  (let ((ov (make-overlay pos pos))
        (symbol (pcase status
                  ('pass "✓")
                  ('fail "✗")
                  ('error "⚠")
                  ('skip "•")
                  (_ "?")))
        (face (pcase status
                ('pass 'e-unit-test-pass)
                ('fail 'e-unit-test-fail)
                ('error 'e-unit-test-error)
                ('skip 'e-unit-test-skip)
                (_ 'default))))
    (overlay-put ov 'e-unit-test t)
    (overlay-put ov 'before-string
                 (propertize " " 'display `((left-fringe ,symbol ,face))))))

(defun e-unit-test--create-inline-overlay (pos message)
  "Create inline error message overlay at POS with MESSAGE."
  (let ((ov (make-overlay pos (line-end-position))))
    (overlay-put ov 'e-unit-test t)
    (overlay-put ov 'after-string
                 (propertize (concat "\n  " message)
                             'face 'e-unit-test-inline-message))))

;;; Test List Buffer

(defvar e-unit-test-list-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "n") #'next-line)
    (define-key map (kbd "p") #'previous-line)
    (define-key map (kbd "RET") #'e-unit-test-list-run-test)
    (define-key map (kbd "v") #'e-unit-test-list-run-all)
    (define-key map (kbd "g") #'e-unit-test-list-refresh)
    (define-key map (kbd "q") #'quit-window)
    map)
  "Keymap for e-unit-test-list-mode.")

(define-derived-mode e-unit-test-list-mode special-mode "E-Unit Tests"
  "Major mode for displaying e-unit test list."
  (setq truncate-lines t))

(defun e-unit-test-list-run-test ()
  "Run test at point in test list."
  (interactive)
  (message "Not yet implemented"))

(defun e-unit-test-list-run-all ()
  "Run all tests in list."
  (interactive)
  (message "Not yet implemented"))

(defun e-unit-test-list-refresh ()
  "Refresh test list."
  (interactive)
  (e-unit-test-show-list))

(defun e-unit-test-show-list ()
  "Show popup test list buffer."
  (interactive)
  (let ((buf (get-buffer-create "*E-Unit Tests*"))
        (tests (e-unit-test--find-tests-in-buffer))
        (file (buffer-file-name)))
    (with-current-buffer buf
      (e-unit-test-list-mode)
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert (format "E-Unit Tests: %s\n\n" (or file "unknown")))
        (dolist (test tests)
          (let* ((result (alist-get test e-unit-test--last-results))
                 (status (when result (plist-get result :status)))
                 (symbol (pcase status
                           ('pass "✓")
                           ('fail "✗")
                           ('error "⚠")
                           ('skip "•")
                           (_ "•"))))
            (insert (format "  %s %s\n" symbol test)))))
      (goto-char (point-min))
      (forward-line 2))
    (display-buffer buf)))

(defun e-unit-test-clear-overlays ()
  "Clear all test result overlays in current buffer."
  (interactive)
  (remove-overlays (point-min) (point-max) 'e-unit-test t)
  (message "Cleared test overlays"))

;;; Mode Definition

(define-minor-mode e-unit-test-mode
  "Minor mode for e-unit test development.

Provides IDE-like testing features:
- Quick test running via keybindings
- Visual pass/fail indicators (fringe + inline)
- Test navigation (imenu, popup list, speedbar)
- Syntax highlighting for test keywords
- Completion for assertions and test names
- YASnippet templates (optional)

\\{e-unit-test-map}"
  :lighter " E-Test"
  :keymap e-unit-test-map
  (if e-unit-test-mode
      (e-unit-test--enable)
    (e-unit-test--disable)))

(defun e-unit-test--enable ()
  "Enable e-unit-test-mode features."
  ;; Font-lock
  (font-lock-add-keywords nil e-unit-test--font-lock-keywords)
  (font-lock-flush)
  ;; Imenu
  (setq-local imenu-create-index-function #'e-unit-test--imenu-create-index)
  ;; Completion
  (add-hook 'completion-at-point-functions #'e-unit-test--completion-at-point nil t)
  (message "E-Unit Test Mode enabled"))

(defun e-unit-test--disable ()
  "Disable e-unit-test-mode features."
  ;; Font-lock
  (font-lock-remove-keywords nil e-unit-test--font-lock-keywords)
  (font-lock-flush)
  ;; Imenu
  (kill-local-variable 'imenu-create-index-function)
  ;; Completion
  (remove-hook 'completion-at-point-functions #'e-unit-test--completion-at-point t)
  ;; Clear overlays
  (e-unit-test-clear-overlays)
  (message "E-Unit Test Mode disabled"))

;;; Auto-Activation

;;;###autoload
(defun e-unit-test-auto-enable ()
  "Enable e-unit-test-mode if in `emacs-lisp-mode'."
  (when (derived-mode-p 'emacs-lisp-mode)
    (e-unit-test-mode 1)))

;;;###autoload
(add-to-list 'auto-mode-alist '("-test\\.el\\'" . e-unit-test-auto-enable))

(provide 'e-unit-test-mode)
;;; e-unit-test-mode.el ends here
