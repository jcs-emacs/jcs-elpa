;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260316.441"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "98ffe4e621fbe7c12305fa2db787d3d9303d0dd5"
  :revdesc "98ffe4e621fb"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
