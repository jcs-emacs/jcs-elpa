;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.3.0.20260724.1"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "08972cd4e657d861b6725c9359660fd9fdbe68f1"
  :revdesc "08972cd4e657"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
