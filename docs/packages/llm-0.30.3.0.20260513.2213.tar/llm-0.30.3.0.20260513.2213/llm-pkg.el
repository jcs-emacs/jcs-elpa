;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.30.3.0.20260513.2213"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "0b20bcebba479b6388d6c8a2b82ad24a47d8a5fd"
  :revdesc "0b20bcebba47"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
