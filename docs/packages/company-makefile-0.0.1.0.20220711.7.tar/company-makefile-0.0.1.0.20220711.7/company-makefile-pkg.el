;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-makefile" "0.0.1.0.20220711.7"
  "Completion backend for gnu makefiles."
  '((emacs   "26.1")
    (company "0.8.12"))
  :url "https://github.com/elp-revive/company-makefile"
  :commit "19b2b1c6b99cb59c99ae714bc9e06d5227ed36da"
  :revdesc "19b2b1c6b99c"
  :keywords '("convenience" "matching")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
