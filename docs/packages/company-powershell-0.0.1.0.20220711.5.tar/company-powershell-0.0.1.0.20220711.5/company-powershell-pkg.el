;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-powershell" "0.0.1.0.20220711.5"
  "Emacs autocompletion backend for powershell."
  '((emacs   "26.1")
    (company "0.8.12")
    (ht      "2.4"))
  :url "https://github.com/elp-revive/company-powershell"
  :commit "0380259960aeac873c7bec1e9c5218da0a82c358"
  :revdesc "0380259960ae"
  :keywords '("convenience")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
