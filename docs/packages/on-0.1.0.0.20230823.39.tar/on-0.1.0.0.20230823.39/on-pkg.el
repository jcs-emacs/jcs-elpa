;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "on" "0.1.0.0.20230823.39"
  "Hooks for faster startup."
  '((emacs "27.1"))
  :url "https://github.com/elp-revive/on.el"
  :commit "26ff01594a1e326af468350e1a22dcd1b7da71ae"
  :revdesc "26ff01594a1e"
  :keywords '("convenience")
  :authors '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
