;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cisco-router-mode" "0.0.0.20100804.2"
  "Major mode for editing Cisco router configuration files."
  ()
  :url "https://github.com/emacsmirror/cisco-router-mode"
  :commit "3878fc6d6a1dea48eb9174af567f93659b8542e8"
  :revdesc "3878fc6d6a1d")
