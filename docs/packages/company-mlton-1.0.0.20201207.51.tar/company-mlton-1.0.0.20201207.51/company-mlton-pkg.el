;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-mlton" "1.0.0.20201207.51"
  "Company-mode backend for MLton/Standard ML."
  '((emacs   "24.4")
    (company "0.9.4")
    (dash    "2.13.0"))
  :url "https://github.com/MatthewFluet/company-mlton"
  :commit "9b09d209b4767a2af24784fb5321390ed1d445bf"
  :revdesc "9b09d209b476"
  :keywords '("company-mode" "mlton" "standard-ml")
  :authors '(("Matthew Fluet" . "Matthew.Fluet@gmail.com"))
  :maintainers '(("Matthew Fluet" . "Matthew.Fluet@gmail.com")))
