;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noflet" "0.0.15.0.20230414.531"
  "Locally override functions."
  '((emacs "26.1")
    (dash  "2.18"))
  :url "https://github.com/elp-revive/noflet"
  :commit "b2645dace4646977369c81e840324c0d4df746fa"
  :revdesc "b2645dace464"
  :keywords '("lisp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
