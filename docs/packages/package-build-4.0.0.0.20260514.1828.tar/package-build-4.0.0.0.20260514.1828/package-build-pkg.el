;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "4.0.0.0.20260514.1828"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "6bf9802866bf2a9d134999c1dae0658c6aff7b02"
  :revdesc "4.0.0-233-g6bf9802866bf"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
