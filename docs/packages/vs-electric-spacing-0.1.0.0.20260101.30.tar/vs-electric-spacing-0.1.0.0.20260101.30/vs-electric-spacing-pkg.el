;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-electric-spacing" "0.1.0.0.20260101.30"
  "Add spacing around operators like Visual Studio."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/vs-electric-spacing"
  :commit "dd99f91a264520d3ec79b7c883174b917557e16c"
  :revdesc "dd99f91a2645"
  :keywords '("convenience" "electric" "vs")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
