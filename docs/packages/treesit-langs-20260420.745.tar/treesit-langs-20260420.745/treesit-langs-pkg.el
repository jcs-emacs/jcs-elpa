;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260420.745"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "dd931b583eda4483907de4ce3f7dc6d3fc4f2f45"
  :revdesc "dd931b583eda"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
