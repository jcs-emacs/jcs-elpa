;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qss-mode" "0.1.0.0.20260101.602"
  "Major mode for Qt Style Sheets."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/qss-mode"
  :commit "418b91498171d845da010a8ff8c9ce4d542efd48"
  :revdesc "418b91498171"
  :keywords '("languages")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
