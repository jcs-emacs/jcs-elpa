;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbs" "0.1.0.0.20260101.11"
  "Minibuffer Stats."
  '((emacs "26.1")
    (s     "1.12.0"))
  :url "https://github.com/jcs-elpa/mbs"
  :commit "92286e02a4e2f8bcf966b9dad6263329dba7591e"
  :revdesc "92286e02a4e2"
  :keywords '("convenience" "minibuffer" "stats")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
