;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-edit-mode" "0.2.0.0.20260212.828"
  "Minor mode accomplish editing experience in Visual Studio."
  '((emacs     "28.1")
    (noflet    "0.0.15")
    (mwim      "0.4")
    (ts-fold   "0.1.0")
    (foldvis   "0.1.0")
    (savefold  "0.0.1")
    (fold-this "0.4.4"))
  :url "https://github.com/emacs-vs/vs-edit-mode"
  :commit "d3c5ca0d3f4fb99d8f058da1b00ef273ed4d2cb5"
  :revdesc "d3c5ca0d3f4f"
  :keywords '("convenience" "editing" "vs")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
