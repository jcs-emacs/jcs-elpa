;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-vale" "0.0.2.0.20260921.7"
  "Flymake integration for vale."
  '((emacs     "27.1")
    (flymake   "0.22")
    (let-alist "1.0.4")
    (compat    "29.1.4.4"))
  :url "https://github.com/tpeacock19/new"
  :commit "3ae16071d7e1ab7cf4b0d30a731584d65a6d1977"
  :revdesc "3ae16071d7e1"
  :authors '(("Trey Peacock" . "http://github/tpeacock19"))
  :maintainers '(("Trey Peacock" . "git@treypeacock.com")))
