;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-cmd" "0.0.1"
  "Company backend for cmd/batch."
  '((emacs   "26.1")
    (company "0.8.12")
    (ht      "2.4"))
  :url "https://github.com/elp-revive/company-cmd"
  :commit "cf393156e92fb2ac503dfa328e7e96b547fc2a97"
  :revdesc "cf393156e92f"
  :keywords '("convenience")
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
