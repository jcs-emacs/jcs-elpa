;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-refresh" "0.1.0.0.20260101.27"
  "Refresh vc-state in certain events for better UX."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/vc-refresh"
  :commit "e819edbaa19b7436381521425b8d77619964c717"
  :revdesc "e819edbaa19b"
  :keywords '("vc")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
