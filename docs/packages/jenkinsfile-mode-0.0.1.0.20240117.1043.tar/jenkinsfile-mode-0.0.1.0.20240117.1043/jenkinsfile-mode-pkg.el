;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jenkinsfile-mode" "0.0.1.0.20240117.1043"
  "Major mode for editing Jenkins declarative pipeline syntax."
  '((emacs       "24")
    (groovy-mode "2.0"))
  :url "https://github.com/elp-revive/jenkinsfile-mode"
  :commit "9ba38d93bad383c7321a14d6e24b8fd8b18a767e"
  :revdesc "9ba38d93bad3")
