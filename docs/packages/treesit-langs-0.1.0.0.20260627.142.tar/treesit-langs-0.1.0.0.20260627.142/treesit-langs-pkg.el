;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "0.1.0.0.20260627.142"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "7d933197f5372420924a511aa40d21ba2ab4d12e"
  :revdesc "7d933197f537"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
