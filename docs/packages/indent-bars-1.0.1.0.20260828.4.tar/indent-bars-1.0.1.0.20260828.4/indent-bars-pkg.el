;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-bars" "1.0.1.0.20260828.4"
  "Highlight indentation with bars."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/jdtsmith/indent-bars"
  :commit "5d4b9131696b2c5992df24cfbcbe029cc16c7cb4"
  :revdesc "5d4b9131696b"
  :keywords '("convenience")
  :authors '(("J.D. Smith" . "jdtsmith+elpa@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
