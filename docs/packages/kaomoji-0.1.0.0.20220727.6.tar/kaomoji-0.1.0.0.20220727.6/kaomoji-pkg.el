;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaomoji" "0.1.0.0.20220727.6"
  "Input kaomoji superb easily."
  '((emacs "24.3"))
  :url "https://github.com/elp-revive/kaomoji.el"
  :commit "a2e78406afdcb7d5650975006a69afd3e7c4c6ac"
  :revdesc "a2e78406afdc"
  :keywords '("tools" "fun")
  :authors '(("Ono Hiroko" . "azazabc123@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
