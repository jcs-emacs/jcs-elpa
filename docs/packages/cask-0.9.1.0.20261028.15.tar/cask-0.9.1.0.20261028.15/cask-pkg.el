;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cask" "0.9.1.0.20261028.15"
  "Cask: Project management for package development."
  '((emacs   "25.3")
    (s       "1.8.0")
    (f       "0.16.0")
    (epl     "0.5")
    (shut-up "0.1.0")
    (cl-lib  "0.3")
    (ansi    "0.4.1"))
  :url "https://github.com/cask/cask"
  :commit "38c3ec4c17d877a913d19a729b9f15094d43c8a0"
  :revdesc "38c3ec4c17d8"
  :keywords '("speed" "convenience")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
