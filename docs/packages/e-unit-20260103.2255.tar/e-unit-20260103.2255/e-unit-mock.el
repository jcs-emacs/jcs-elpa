;;; e-unit-mock.el --- Test doubles for E-Unit -*- lexical-binding: t; -*-

;; Copyright (C) 2025
;; SPDX-License-Identifier: GPL-3.0-only

;; Author: Aldric Giacomoni <trevoke@gmail.com>
;; URL: https://codeberg.org/Trevoke/eunit.el

;;; Commentary:

;; Test doubles based on Uncle Bob's "Little Mocker" taxonomy:
;; - Dummy: Returns nil, satisfies type requirements
;; - Stub: Returns predetermined values
;; - Spy: Records calls for inspection (with-spy, with-spy-call-through)
;; - Mock: Spy with auto-verification (:times, :never, :called-with)
;; - Fake: Simplified real implementation
;;
;; Hierarchy: Mock -> Spy -> Stub -> Dummy (Fake is separate)
;;
;; Key features:
;; - with-spy-call-through: Records calls while executing original function
;; - :never for with-mock: Verify a function was NOT called
;;
;; XP Guidance: Mock sparingly. Reserve mocks for architectural boundaries.
;; Prefer state verification over behavior verification.

;;; Code:

(require 'cl-lib)

;;; ============================================================
;;; TYPE 1: DUMMY - The Simplest Test Double
;;; ============================================================
;;
;; A Dummy returns nil for any call. Use when you need a function
;; to exist but don't care about its behavior.

(defmacro e-unit-mock-with-dummy (fn-name &rest body)
  "Execute BODY with FN-NAME replaced by a function returning nil.

A Dummy is the simplest test double - it exists solely to satisfy
the requirement that a function exists. Use when you don't care
about the function's behavior for this test.

Example:
  (with-dummy some-logger
    (my-function-that-logs))  ; logging is ignored

Uses `cl-letf' for automatic cleanup - original is always restored."
  (declare (indent 1))
  `(cl-letf (((symbol-function ',fn-name)
              (lambda (&rest _args) nil)))
     ,@body))

(defmacro e-unit-mock-with-dummy-var (var-name &rest body)
  "Execute BODY with VAR-NAME temporarily set to nil.

Like `with-dummy' but for variables instead of functions.

Example:
  (with-dummy-var some-config
    (my-function))  ; some-config is nil during body

Uses `cl-letf' for automatic cleanup - original value is always restored."
  (declare (indent 1))
  `(cl-letf (((symbol-value ',var-name) nil))
     ,@body))

;;; ============================================================
;;; TYPE 2: STUB - Dummy That Returns A Value
;;; ============================================================
;;
;; A Stub extends Dummy by returning a predetermined value.
;; Use when you need to control what a dependency returns.

(defmacro e-unit-mock-with-stub (fn-name return-value &rest body)
  "Execute BODY with FN-NAME returning RETURN-VALUE.

A Stub is a Dummy that returns a specific value. Use when you
need to control what a dependency returns.

Example:
  (with-stub get-config '(:debug t)
    (assert-true (debug-enabled-p)))

Uses `cl-letf' for automatic cleanup."
  (declare (indent 2))
  `(cl-letf (((symbol-function ',fn-name)
              (lambda (&rest _args) ,return-value)))
     ,@body))

(defmacro e-unit-mock-with-stub-seq (fn-name values &rest body)
  "Execute BODY with FN-NAME returning VALUES in sequence.

Each call to FN-NAME returns the next value from VALUES.
Returns nil when VALUES is exhausted.

Example:
  (with-stub-seq read-line '(\"first\" \"second\" \"eof\")
    (assert-equal \"first\" (read-line))
    (assert-equal \"second\" (read-line)))"
  (declare (indent 2))
  (let ((remaining (make-symbol "remaining")))
    `(let ((,remaining ,values))
       (cl-letf (((symbol-function ',fn-name)
                  (lambda (&rest _args)
                    (pop ,remaining))))
         ,@body))))

(defmacro e-unit-mock-with-stub-var (var-name value &rest body)
  "Execute BODY with VAR-NAME temporarily set to VALUE.

Like `with-stub' but for variables instead of functions.

Example:
  (with-stub-var debug-on-error t
    (my-function))  ; debug-on-error is t during body

Uses `cl-letf' for automatic cleanup - original value is always restored."
  (declare (indent 2))
  `(cl-letf (((symbol-value ',var-name) ,value))
     ,@body))

;;; ============================================================
;;; TYPE 3: SPY - Stub That Records Calls
;;; ============================================================
;;
;; A Spy extends Stub by recording all calls for later inspection.
;; Use when you need to verify HOW a dependency was called.

(defmacro e-unit-mock-with-spy (fn-name spy-var &rest body)
  "Execute BODY with FN-NAME replaced by a spy that records calls.

SPY-VAR is bound to a list of calls (most recent first).
Each call is a list of arguments passed to the function.

If the first element of BODY is not a list starting with a symbol
that looks like a function call, it's treated as a return value.

Example:
  (with-spy send-email calls
    (register-user \"alice\")
    (assert-equal 1 (spy-call-count calls))
    (assert-equal '(\"alice\") (spy-last-call calls)))

  ;; With return value:
  (with-spy get-data calls 42
    (assert-equal 42 (get-data))
    (assert-true (spy-called-p calls)))

Uses `cl-letf' for automatic cleanup."
  (declare (indent 2))
  ;; Parse optional return value from body
  ;; If first form is not a list or is a list starting with a known macro/special form,
  ;; treat it as body. Otherwise, could be a return value.
  ;; Simple heuristic: if first element is an atom (not a list), it's a return value
  (let ((return-value nil)
        (actual-body body))
    ;; Check if first element looks like a return value (atom or quoted form)
    (when (and body
               (or (atom (car body))
                   (and (listp (car body))
                        (eq 'quote (caar body)))))
      (setq return-value (car body))
      (setq actual-body (cdr body)))
    `(let ((,spy-var nil))
       (cl-letf (((symbol-function ',fn-name)
                  (lambda (&rest args)
                    (push args ,spy-var)
                    ,return-value)))
         ,@actual-body))))

(defmacro e-unit-mock-with-spy-call-through (fn-name spy-var &rest body)
  "Execute BODY with FN-NAME wrapped by a spy that calls through.

Like `with-spy', but calls the original function and returns its result.
SPY-VAR is bound to a list of calls (most recent first).

Use when you need to verify a function was called while preserving
its actual behavior.

Example:
  (with-spy-call-through message calls
    (my-function-that-logs)
    (assert-true (spy-called-p calls)))

Uses `cl-letf' for automatic cleanup."
  (declare (indent 2))
  (let ((original (make-symbol "original")))
    `(let ((,spy-var nil)
           (,original (symbol-function ',fn-name)))
       (cl-letf (((symbol-function ',fn-name)
                  (lambda (&rest args)
                    (push args ,spy-var)
                    (apply ,original args))))
         ,@body))))

;;; Spy Helper Functions

(defun e-unit-mock-spy-call-count (calls)
  "Return the number of recorded calls in CALLS."
  (length calls))

(defun e-unit-mock-spy-called-p (calls)
  "Return t if any calls were recorded in CALLS."
  (not (null calls)))

(defun e-unit-mock-spy-last-call (calls)
  "Return the arguments of the most recent call in CALLS."
  (car calls))

(defun e-unit-mock-spy-first-call (calls)
  "Return the arguments of the first call in CALLS."
  (car (last calls)))

;;; ============================================================
;;; TYPE 4: MOCK - Spy With Auto-Verification
;;; ============================================================
;;
;; A Mock extends Spy by automatically verifying expectations
;; when the block ends. Use when you want to declare expectations
;; upfront and have them verified automatically.

(defmacro e-unit-mock-with-mock (fn-name &rest args)
  "Execute body with FN-NAME mocked and expectations auto-verified.

Supported keyword arguments:
  :returns VALUE  - Mock returns this value
  :times N        - Expect exactly N calls
  :never          - Expect zero calls (mutually exclusive with :times)
  :called-with (ARGS...) - Expect at least one call with these args

Example:
  (with-mock send-email :returns t :times 1 :called-with (\"alice@example.com\")
    (register-user \"alice@example.com\"))

  ;; Verify function was NOT called:
  (with-mock send-email :never
    (validate-email \"invalid\"))

Verification happens at block end. Signals error if expectations not met.
Uses `cl-letf' for automatic cleanup - original restored even on error."
  (declare (indent 1))
  ;; Parse keyword arguments
  (let ((returns nil)
        (times nil)
        (never nil)
        (called-with nil)
        (body nil)
        (rest args))
    ;; Parse keyword args from the front
    (while (and rest (keywordp (car rest)))
      (pcase (car rest)
        (:returns (setq returns (cadr rest) rest (cddr rest)))
        (:times (setq times (cadr rest) rest (cddr rest)))
        (:never (setq never t rest (cdr rest)))  ; :never takes no value
        (:called-with (setq called-with (cadr rest) rest (cddr rest)))
        (_ (setq rest (cddr rest)))))  ; skip unknown keywords
    (setq body rest)
    ;; Check for mutually exclusive options
    (when (and never times)
      (error "Mock %s: :never and :times are mutually exclusive" fn-name))
    (let ((calls-sym (make-symbol "calls")))
      `(let ((,calls-sym nil))
         (cl-letf (((symbol-function ',fn-name)
                    (lambda (&rest args)
                      (push args ,calls-sym)
                      ,returns)))
           (unwind-protect
               (progn ,@body)
             ;; Verify expectations
             ,(when never
                `(when (> (length ,calls-sym) 0)
                   (error "Mock %s: expected never to be called, but was called %d time(s)"
                          ',fn-name (length ,calls-sym))))
             ,(when times
                `(unless (= (length ,calls-sym) ,times)
                   (error "Mock %s: expected %d calls, got %d"
                          ',fn-name ,times (length ,calls-sym))))
             ,(when called-with
                `(unless (member ',called-with ,calls-sym)
                   (error "Mock %s: expected call with %S, calls were %S"
                          ',fn-name ',called-with ,calls-sym)))))))))

;;; ============================================================
;;; TYPE 5: FAKE - Simplified Real Implementation
;;; ============================================================
;;
;; A Fake is a simplified but working implementation.
;; Use when you need real behavior but simpler than the real thing.

(defmacro e-unit-mock-with-fake (fn-name replacement &rest body)
  "Execute BODY with FN-NAME replaced by REPLACEMENT function.

A Fake is a simplified implementation. Unlike stubs that return
fixed values, fakes actually compute results.

Example:
  (with-fake database-query
      (lambda (query) (if (equal query \"SELECT 1\") '(1) nil))
    (assert-equal '(1) (database-query \"SELECT 1\")))

Uses `cl-letf' for automatic cleanup."
  (declare (indent 2))
  (let ((replacement-sym (make-symbol "replacement")))
    `(let ((,replacement-sym ,replacement))
       (cl-letf (((symbol-function ',fn-name) ,replacement-sym))
         ,@body))))

;;; Initialization

(defvar e-unit-mock--initialized nil
  "Whether e-unit-mock has been initialized.")

(defun e-unit-mock-initialize ()
  "Initialize e-unit-mock with short aliases."
  (unless e-unit-mock--initialized
    ;; Dummy (function and variable)
    (defalias 'with-dummy #'e-unit-mock-with-dummy)
    (defalias 'with-dummy-var #'e-unit-mock-with-dummy-var)

    ;; Stub (function and variable)
    (defalias 'with-stub #'e-unit-mock-with-stub)
    (defalias 'with-stub-seq #'e-unit-mock-with-stub-seq)
    (defalias 'with-stub-var #'e-unit-mock-with-stub-var)

    ;; Spy
    (defalias 'with-spy #'e-unit-mock-with-spy)
    (defalias 'with-spy-call-through #'e-unit-mock-with-spy-call-through)
    (defalias 'spy-call-count #'e-unit-mock-spy-call-count)
    (defalias 'spy-called-p #'e-unit-mock-spy-called-p)
    (defalias 'spy-last-call #'e-unit-mock-spy-last-call)
    (defalias 'spy-first-call #'e-unit-mock-spy-first-call)

    ;; Mock
    (defalias 'with-mock #'e-unit-mock-with-mock)

    ;; Fake
    (defalias 'with-fake #'e-unit-mock-with-fake)

    (setq e-unit-mock--initialized t)))

(provide 'e-unit-mock)

;;; e-unit-mock.el ends here
