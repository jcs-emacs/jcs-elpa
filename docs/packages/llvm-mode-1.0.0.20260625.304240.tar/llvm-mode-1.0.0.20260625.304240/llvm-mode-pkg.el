;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-mode" "1.0.0.20260625.304240"
  "Major mode for the LLVM assembler language."
  '((emacs "24.3"))
  :url "http://llvm.org/"
  :commit "c07bc2962c5f76ebcbd040c4e97fe5d129530087"
  :revdesc "c07bc2962c5f")
