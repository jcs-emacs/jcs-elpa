;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.3.0.20260801.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "791bf823259f495439e56c626975ccad487c779b"
  :revdesc "791bf823259f"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
