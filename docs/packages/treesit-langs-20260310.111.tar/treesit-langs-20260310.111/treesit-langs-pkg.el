;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260310.111"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "08c2c5bccd85019c6e600b8c936566dca097bd02"
  :revdesc "08c2c5bccd85"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
