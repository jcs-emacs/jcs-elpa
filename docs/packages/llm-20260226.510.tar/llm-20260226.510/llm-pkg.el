;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260226.510"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "050f33dc9af78c3c126fe30addb9f9e17b8e2ed1"
  :revdesc "050f33dc9af7"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
