;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.7.0.0.20260703.5"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "2d46055a9d0a088d2efce6dc12a894fba8b7659a"
  :revdesc "2d46055a9d0a"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
