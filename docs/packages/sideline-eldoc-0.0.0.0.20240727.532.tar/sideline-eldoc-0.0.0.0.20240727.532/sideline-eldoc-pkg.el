;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-eldoc" "0.0.0.0.20240727.532"
  "Sideline backend for eldoc."
  ()
  :url "https://github.com/ginqi7/sideline-eldoc"
  :commit "70f616af494586e19e6d79f491391b600321056b"
  :revdesc "70f616af4945"
  :authors '(("Qiqi Jin" . "ginqi7@gmail.com"))
  :maintainers '(("Qiqi Jin" . "ginqi7@gmail.com")))
