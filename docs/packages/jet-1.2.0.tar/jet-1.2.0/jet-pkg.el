;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jet" "1.2.0"
  "Emacs integration for jet Clojure tool."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/ericdallo/jet.el"
  :commit "67ded216a0a6af0bb8d6874a7faea538912c0345"
  :revdesc "67ded216a0a6"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
