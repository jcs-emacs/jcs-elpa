;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-elsa" "0.1.0.0.20251231.1620"
  "Flymake integration for Elsa."
  '((emacs        "26.1")
    (flymake-easy "0.1"))
  :url "https://github.com/flymake/flymake-elsa"
  :commit "6afe3d0828f991747a4cc1c610927cffd07674c3"
  :revdesc "6afe3d0828f9"
  :keywords '("lisp" "elsa")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
