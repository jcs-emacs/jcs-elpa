;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260308.2348"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "603168ba0e649530b5e17cdff2c14c6f12bc652f"
  :revdesc "603168ba0e64"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
