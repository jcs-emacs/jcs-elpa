;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selection-highlight-mode" "0.1.0"
  "Auto highlights matches to the current active region."
  '((emacs "25.1"))
  :url "https://github.com/balloneij/selection-highlight-mode"
  :commit "a1960f9e098b9980b2f07791488305ac835047ff"
  :revdesc "a1960f9e098b"
  :keywords '("matching")
  :authors '(("Isaac Ballone" . "isaac@ballone.dev"))
  :maintainers '(("Isaac Ballone" . "isaac@ballone.dev")))
