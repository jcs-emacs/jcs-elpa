;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-meta-net" "0.1.0.0.20260101.548"
  "Eldoc support for meta-net."
  '((emacs       "26.1")
    (meta-net    "1.1.0")
    (ht          "2.3")
    (csharp-mode "1.0.2"))
  :url "https://github.com/emacs-vs/eldoc-meta-net"
  :commit "b63e5b170df47fed6626ad81b4d060b8a4b358e0"
  :revdesc "b63e5b170df4"
  :keywords '("convenience" "eldoc" "c#" "dotnet" "sdk")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
