;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zoom-to-point" "0.2"
  "Zoom in or out on the line at point."
  ()
  :url "https://github.com/rmloveland/zoom-to-point"
  :commit "38b11fe8f110eae4c8c7e1a0b40e05f9e58c7f36"
  :revdesc "38b11fe8f110"
  :keywords '("convenience" "text size" "zoom")
  :authors '(("Rich Loveland" . "r@rmloveland.com"))
  :maintainers '(("Rich Loveland" . "r@rmloveland.com")))
