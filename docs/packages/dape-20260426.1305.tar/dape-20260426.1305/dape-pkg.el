;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260426.1305"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "dc9e8757bf79a1f5f1fa2c11574f8f93b5644d4b"
  :revdesc "dc9e8757bf79"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
