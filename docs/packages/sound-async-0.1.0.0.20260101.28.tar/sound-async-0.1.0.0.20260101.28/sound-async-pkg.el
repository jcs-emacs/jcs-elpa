;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sound-async" "0.1.0.0.20260101.28"
  "Play sound asynchronously."
  '((emacs "26.1")
    (async "1.9.3"))
  :url "https://github.com/jcs-elpa/sound-async"
  :commit "bf25ff858284cb232f704b67c3cbac127c2907a8"
  :revdesc "bf25ff858284"
  :keywords '("multimedia")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
