;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "savefold" "0.0.1.0.20251002.63"
  "Persistence for various folding systems."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/jcfk/savefold.el"
  :commit "068f67dcfca6653187fe4c208d66a08b1f5e642a"
  :revdesc "068f67dcfca6"
  :keywords '("convenience")
  :authors '(("Jacob Fong" . "jacobcfong@gmail.com"))
  :maintainers '(("Jacob Fong" . "jacobcfong@gmail.com")))
