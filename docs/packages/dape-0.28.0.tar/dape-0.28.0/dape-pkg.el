;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.28.0"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "1d45904b40bfdbdbe0e29546a13d7859a478f710"
  :revdesc "1d45904b40bf"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
