;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260924.10"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "a5dcf2d086a91fbe6e600b6de482d8f680f4410c"
  :revdesc "a5dcf2d086a9"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
