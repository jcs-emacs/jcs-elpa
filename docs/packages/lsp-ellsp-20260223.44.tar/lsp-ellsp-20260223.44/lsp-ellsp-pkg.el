;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ellsp" "20260223.44"
  "LSP Clients for Ellsp."
  '((emacs    "28.1")
    (lsp-mode "6.1"))
  :url "https://github.com/elisp-lsp/lsp-ellsp"
  :commit "e9a559076bf37b30ddaf3e8a2c6287eca89e33e0"
  :revdesc "e9a559076bf3"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
