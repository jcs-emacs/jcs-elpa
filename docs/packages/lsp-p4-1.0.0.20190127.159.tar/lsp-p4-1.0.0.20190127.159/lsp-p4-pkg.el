;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-p4" "1.0.0.20190127.159"
  "P4 support for lsp-mode."
  '((lsp-mode "3.0"))
  :url "https://github.com/dmakarov/p4ls"
  :commit "084e33a5782f9153502d9b03e63d9cbbe81cdaeb"
  :revdesc "084e33a5782f"
  :keywords '("lsp" "p4"))
