;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-ltex" "0.1.0.0.20260101.19"
  "Eglot Clients for LTEX."
  '((emacs "29.1")
    (eglot "1.4")
    (f     "0.20.0"))
  :url "https://github.com/emacs-languagetool/eglot-ltex"
  :commit "35bc85d98f1e55275f1d074f1edcf02edbefdf4d"
  :revdesc "35bc85d98f1e"
  :keywords '("convenience" "eglot" "languagetool" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
