;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260216.1845"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "9a21f0e2d9250b4a33e8a14d721d32f0d689c30d"
  :revdesc "9a21f0e2d925"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
