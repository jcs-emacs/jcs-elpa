;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-elpa" "0.0.1.0.20231201.21"
  "Build and publish ELPA repositories with GitHub Pages."
  '((package-build "1.0")
    (commander     "0.7.0")
    (git           "0.1.1"))
  :url "https://github.com/10sr/github-elpa"
  :commit "c818883d9dc8d34eaee03691574e0408f18db28a"
  :revdesc "c818883d9dc8"
  :authors '(("10sr" . "8slashes+el@gmail.com"))
  :maintainers '(("10sr" . "8slashes+el@gmail.com")))
