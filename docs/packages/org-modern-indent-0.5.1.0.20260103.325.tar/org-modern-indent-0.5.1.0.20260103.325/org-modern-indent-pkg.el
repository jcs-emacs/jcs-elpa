;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern-indent" "0.5.1.0.20260103.325"
  "Indent blocks like org-modern."
  '((emacs  "27.1")
    (org    "9.6.1")
    (compat "30.0"))
  :url "https://github.com/jdtsmith/org-modern-indent"
  :commit "476348d67e5043ed8fece78178d1623d6f323848"
  :revdesc "476348d67e50"
  :keywords '("convenience"))
