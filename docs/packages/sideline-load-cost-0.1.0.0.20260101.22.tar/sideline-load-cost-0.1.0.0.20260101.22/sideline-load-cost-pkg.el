;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-load-cost" "0.1.0.0.20260101.22"
  "Display load/require module size with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0"))
  :url "https://github.com/emacs-sideline/sideline-load-cost"
  :commit "49179633bf9bbedd23052d845525a032679934cd"
  :revdesc "49179633bf9b"
  :keywords '("help")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
