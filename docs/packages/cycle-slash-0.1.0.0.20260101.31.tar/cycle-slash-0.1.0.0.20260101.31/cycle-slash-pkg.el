;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-slash" "0.1.0.0.20260101.31"
  "Cycle through slash, backslash, and double backslash."
  '((emacs "28.1"))
  :url "https://github.com/jcs-elpa/cycle-slash"
  :commit "5e6cac9bf20936720ac600281d733d8829996e0b"
  :revdesc "5e6cac9bf209"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
