;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fringe-helper" "1.0.1.0.20140620.3"
  "Helper functions for fringe bitmaps."
  ()
  :url "http://nschum.de/src/emacs/fringe-helper/"
  :commit "9bc3d3e82c9cc3937aa090248dc4dd2e289fc55c"
  :revdesc "1.0.1-3-g9bc3d3e82c9c"
  :keywords '("lisp")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
