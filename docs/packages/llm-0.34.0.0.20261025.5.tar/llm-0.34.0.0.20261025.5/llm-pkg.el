;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0.0.20261025.5"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "ce9a7c4a434c27301cffbb8d2cf221b9500936d8"
  :revdesc "ce9a7c4a434c"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
