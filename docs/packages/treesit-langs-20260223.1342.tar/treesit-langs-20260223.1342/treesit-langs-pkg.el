;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260223.1342"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "4f94b8175f743c121ee54d9a8b12014459ea783e"
  :revdesc "4f94b8175f74"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
