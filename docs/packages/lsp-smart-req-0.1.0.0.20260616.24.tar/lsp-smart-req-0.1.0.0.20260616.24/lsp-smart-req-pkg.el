;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-smart-req" "0.1.0.0.20260616.24"
  "Lazy load LSP packages."
  '((emacs "29.1"))
  :url "https://github.com/jcs-elpa/lsp-smart-req"
  :commit "13b9eed3c3532babfb429cde919bf9380967d500"
  :revdesc "13b9eed3c353"
  :keywords '("internal" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
