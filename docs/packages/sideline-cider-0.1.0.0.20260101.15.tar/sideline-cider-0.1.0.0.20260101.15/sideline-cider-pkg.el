;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-cider" "0.1.0.0.20260101.15"
  "Show CIDER result with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0")
    (cider    "1.16.1"))
  :url "https://github.com/emacs-sideline/sideline-cider"
  :commit "f2e1d606fa159952e823cb329845ea96f10ca293"
  :revdesc "f2e1d606fa15"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
