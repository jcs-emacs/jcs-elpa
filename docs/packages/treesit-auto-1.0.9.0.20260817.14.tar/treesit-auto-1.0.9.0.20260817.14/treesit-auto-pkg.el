;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-auto" "1.0.9.0.20260817.14"
  "Automatically use tree-sitter enhanced major modes."
  '((emacs "29.0"))
  :url "https://github.com/renzmann/treesit-auto.git"
  :commit "c227806dddd4b413009a453c450285d1123e7d72"
  :revdesc "v1.0.9-14-gc227806dddd4"
  :keywords '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :authors '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers '(("Robb Enzmann" . "robbenzmann@gmail.com")))
