;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260323.243"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/dashboard"
  :commit "9cfcb08c5623816d8f9a68a76c54845bc4bf46df"
  :revdesc "9cfcb08c5623"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
