;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.5.0.20261016.23"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "31")
    (cl-lib "1.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "577c300433f9562980be2437852b591e15cb9c0b"
  :revdesc "577c300433f9"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
