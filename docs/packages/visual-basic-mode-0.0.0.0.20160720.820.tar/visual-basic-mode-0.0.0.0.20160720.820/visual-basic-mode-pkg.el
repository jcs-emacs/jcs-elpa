;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-basic-mode" "0.0.0.0.20160720.820"
  "A mode for editing Visual Basic programs."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/visual-basic-mode.el"
  :commit "483dd5a2c8c4675ddb3c32fdd93146c6d248285d"
  :revdesc "483dd5a2c8c4"
  :keywords '("languages" "basic" "evil")
  :authors '(("Fred White" . "fwhite@alum.mit.edu"))
  :maintainers '(("Fred White" . "fwhite@alum.mit.edu")))
