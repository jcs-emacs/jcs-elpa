;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptscript-mode" "0.0.1.0.20260101.538"
  "Major mode for editing GPTScript natural language."
  '((emacs "26.1"))
  :url "https://github.com/emacs-openai/gptscript-mode"
  :commit "ed6c1a7e0fd0b42bb0c09a239c5eddbc0bbfbb1b"
  :revdesc "ed6c1a7e0fd0"
  :keywords '("languages")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
