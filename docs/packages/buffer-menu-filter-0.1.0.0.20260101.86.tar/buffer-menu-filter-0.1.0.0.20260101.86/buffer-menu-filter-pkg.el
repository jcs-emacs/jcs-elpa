;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-menu-filter" "0.1.0.0.20260101.86"
  "Filter buffer-menu items using fake header."
  '((emacs               "26.1")
    (buffer-menu-project "0.1.0")
    (flx                 "0.6.1")
    (ht                  "2.0")
    (msgu                "0.1.0"))
  :url "https://github.com/jcs-elpa/buffer-menu-filter"
  :commit "b9ee831b510c81ea38d21b0624ab51c85b0241d5"
  :revdesc "b9ee831b510c"
  :keywords '("convenience" "buffer" "menu" "filter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
