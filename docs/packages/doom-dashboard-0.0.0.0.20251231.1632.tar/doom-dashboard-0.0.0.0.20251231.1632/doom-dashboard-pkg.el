;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-dashboard" "0.0.0.0.20251231.1632"
  "Doom dashboard style for emacs-dashboard."
  '((emacs      "27.1")
    (dashboard  "1.2.5")
    (nerd-icons "0.1.0"))
  :url "https://github.com/emacs-dashboard/doom-dashboard"
  :commit "27738ce5baad20449d3161ad41048d5a4128a68c"
  :revdesc "27738ce5baad"
  :keywords '("convenience" "tools" "extension")
  :authors '(("Elijah G." . "eg642616@gmail.com"))
  :maintainers '(("Elijah G." . "eg642616@gmail.com")))
