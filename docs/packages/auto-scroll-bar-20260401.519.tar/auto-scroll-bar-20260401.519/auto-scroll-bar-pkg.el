;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-scroll-bar" "20260401.519"
  "Automatically show/hide scroll-bars as needed."
  '((emacs "29.1")
    (elenv "0.1.0"))
  :url "https://github.com/emacs-vs/auto-scroll-bar"
  :commit "026f4cfbb659088df1ade912f13e5e611101cc6b"
  :revdesc "026f4cfbb659"
  :keywords '("convenience" "scrollbar")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
