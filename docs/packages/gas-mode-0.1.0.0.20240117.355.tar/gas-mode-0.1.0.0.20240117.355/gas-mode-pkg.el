;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gas-mode" "0.1.0.0.20240117.355"
  "Mode for editing assembly code with AT&T sintax."
  ()
  :url "https://codeberg.org/Enocstocks/gas-mode.el"
  :commit "599cbcebd01124cc9b429bdb78e0cade7a59bc66"
  :revdesc "599cbcebd011"
  :keywords '("languages")
  :authors '(("Bryan Hernández" . "masterenoc@tutamail.com"))
  :maintainers '(("Bryan Hernández" . "masterenoc@tutamail.com")))
