;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.1.0.20260717.4"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "4c0fb61e9e54a3bfbedb39a97a5a86df2edc0445"
  :revdesc "4c0fb61e9e54"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
