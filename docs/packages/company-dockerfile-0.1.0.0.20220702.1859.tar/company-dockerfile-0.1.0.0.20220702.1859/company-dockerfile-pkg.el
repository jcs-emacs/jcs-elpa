;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-dockerfile" "0.1.0.0.20220702.1859"
  "Company mode backend for dockefile."
  '((emacs           "24.4")
    (company         "0.8.12")
    (dockerfile-mode "1.0"))
  :url "https://github.com/elp-revive/company-dockerfile"
  :commit "9272a09eb300401fdcc99adaf900520d273bbffb"
  :revdesc "9272a09eb300"
  :keywords '("convenience")
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
