;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ic" "0.1.0.0.20260101.21"
  "Pretty print to debug."
  '((emacs "29.1")
    (ppp   "2.2.4")
    (msgu  "0.1.0")
    (ht    "2.0")
    (dash  "2.14.1"))
  :url "https://github.com/jcs-elpa/ic"
  :commit "0132c401d74b757005530dda01f3c607f5a2696f"
  :revdesc "0132c401d74b"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
