;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260530.3"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "b8179dec3e9a7d9ea3cfdcde7e62a404e1a68251"
  :revdesc "b8179dec3e9a"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
