;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260427.1833"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "23a617df77c6ffd1927f8ccd94bcab36d18e0594"
  :revdesc "23a617df77c6"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
