;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico-flx" "0.1.0.0.20260101.25"
  "Flx integration for vertico."
  '((emacs     "28.1")
    (vertico   "0.22")
    (flx       "0.5")
    (flx-style "0.1.1")
    (ht        "2.0")
    (f         "0.20.0")
    (mbs       "0.1.0")
    (s         "1.12.0"))
  :url "https://github.com/jcs-elpa/vertico-flx"
  :commit "bbfdbbb24937b3f172bfe0b1532a7e7fff411652"
  :revdesc "bbfdbbb24937"
  :keywords '("convenience" "vertico" "flx")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
