;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hurl-mode" "0.1.0"
  "Major mode for hurl."
  '((emacs "24"))
  :url "https://github.com/azzamsa/emacs-hurl"
  :commit "aa87da4a6f5dc6a612a576d34a81000835b819e0"
  :revdesc "aa87da4a6f5d"
  :keywords '("hurl" "shell")
  :authors '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers '(("Azzam S.A" . "vcs@azzamsa.com")))
