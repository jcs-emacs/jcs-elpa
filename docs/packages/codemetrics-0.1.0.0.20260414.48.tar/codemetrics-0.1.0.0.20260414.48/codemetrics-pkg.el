;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codemetrics" "0.1.0.0.20260414.48"
  "Plugin shows complexity information."
  '((emacs       "27.1")
    (tree-sitter "0.15.1")
    (s           "1.12.0")
    (dash        "2.19.1"))
  :url "https://github.com/emacs-vs/codemetrics"
  :commit "33ec0a3dc949163666ac559d03d7b5b835fec694"
  :revdesc "33ec0a3dc949"
  :keywords '("convenience" "complexity")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
