;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260219.621"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/emacs-dashboard"
  :commit "f2047cb1542426c943e56780a7c2344b23f0266a"
  :revdesc "f2047cb15424"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
