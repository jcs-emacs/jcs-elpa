;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.2"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "cc03cf723c007dd092932bacd86ea037273fbe0e"
  :revdesc "cc03cf723c00"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
