;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260330.1409"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "66592516b246071c4a14776235c08d5a444ace2b"
  :revdesc "66592516b246"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
