;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "dcbdffc68a3c89bbb89956161edde9f0fe062e64"
  :revdesc "dcbdffc68a3c"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
