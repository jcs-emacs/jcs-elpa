;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260329.1211"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "cca98a8ba895a5890b2d4d7d4a1da840413550c2"
  :revdesc "cca98a8ba895"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
