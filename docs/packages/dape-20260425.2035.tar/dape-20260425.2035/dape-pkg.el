;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260425.2035"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "9e16f6be855bdd90fb59f49cd88fa976779f1c87"
  :revdesc "9e16f6be855b"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
