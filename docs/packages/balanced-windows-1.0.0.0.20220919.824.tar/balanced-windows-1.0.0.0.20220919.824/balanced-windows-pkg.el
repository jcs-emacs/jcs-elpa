;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "balanced-windows" "1.0.0.0.20220919.824"
  "Keep windows balanced."
  '((emacs "25.1"))
  :url "https://github.com/elp-revive/emacs-balanced-windows"
  :commit "fd360ca6416e56d8df92bbcb0f7aec37e201f2e7"
  :revdesc "fd360ca6416e"
  :keywords '("convenience")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
