;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "0.1.0.0.20260616.139"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "cf616d163d54fea584606c233fcfdedf9256f40d"
  :revdesc "cf616d163d54"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
