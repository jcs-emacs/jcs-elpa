;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "point-history" "0.1.0.0.20200721.1117"
  "Show the history of points you visited before."
  '((popwin "1.0.0"))
  :url "https://github.com/blue0513/point-history"
  :commit "dd6d42cfbb25b3432786b263451f433a68eebabf"
  :revdesc "dd6d42cfbb25")
