;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typst-mode" "0.1.0.20230925.39"
  "A major mode for working with Typst typesetting system."
  '((polymode "0.2.2")
    (emacs    "24.3"))
  :url "https://github.com/Ziqi-Yang/typst-mode.el"
  :commit "5776fd4f3608350ff6a2b61b118d38165d342aa3"
  :revdesc "5776fd4f3608"
  :keywords '("outlines")
  :authors '(("Ziqi Yang" . "mr.meowking@anche.no"))
  :maintainers '(("Ziqi Yang" . "mr.meowking@anche.no")))
