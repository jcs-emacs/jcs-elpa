;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260216.1116"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "bd7a83c1bdb56196225866049cd153c208e2c76e"
  :revdesc "bd7a83c1bdb5"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
