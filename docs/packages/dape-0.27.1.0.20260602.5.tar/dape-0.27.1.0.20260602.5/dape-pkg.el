;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260602.5"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "083a16739fe6f4ae5f55c136de9e7ec3ceec2a4d"
  :revdesc "083a16739fe6"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
