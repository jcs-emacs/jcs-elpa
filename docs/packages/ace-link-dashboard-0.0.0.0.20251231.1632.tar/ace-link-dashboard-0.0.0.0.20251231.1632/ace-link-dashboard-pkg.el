;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-link-dashboard" "0.0.0.0.20251231.1632"
  "Ace link for dashboard."
  '((emacs "27.1")
    (avy   "0.5.0"))
  :url "https://github.com/emacs-dashboard/ace-link-dashboard"
  :commit "7b158a01ee230f0e43db022036bd5f7e5601e727"
  :revdesc "7b158a01ee23"
  :keywords '("tools")
  :maintainers '(("Ricardo Arredondo" . "ricardo.richo@gmail.com")
                 ("Jen-Chieh" . "jcs090218@gmail.com")))
