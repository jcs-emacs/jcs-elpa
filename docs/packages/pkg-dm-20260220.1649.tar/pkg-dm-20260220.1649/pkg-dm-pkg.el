;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkg-dm" "20260220.1649"
  "Package dependencies management."
  '((emacs        "28.1")
    (elenv        "0.1.0")
    (msgu         "0.1.0")
    (prt          "0.1.0")
    (recentf-excl "0.1.0")
    (s            "1.12.0"))
  :url "https://github.com/jcs-elpa/pkg-dm"
  :commit "753c465902cece32602bb124c523ae0db208ad0b"
  :revdesc "753c465902ce"
  :keywords '("maint")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
