;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deepl" "0.1.0.0.20260101.29"
  "Elisp library for the DeepL API."
  '((emacs   "26.1")
    (request "0.3.0"))
  :url "https://github.com/emacs-openai/deepl"
  :commit "3cec333f9032a015dae5312c631e44fdc9360dab"
  :revdesc "3cec333f9032"
  :keywords '("comm" "deepl")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
