;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "20260325.249"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "30.1.0.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "b9d8c3c42588237e4e4d2b34483e88fc6c4b7830"
  :revdesc "b9d8c3c42588"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
