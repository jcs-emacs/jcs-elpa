;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-dart" "0.1.0.20170318.2"
  "Autocompletion for Dart files."
  '((dart-mode "0.20")
    (company   "0")
    (pos-tip   "0.4.6"))
  :url "https://github.com/sid-kurias/company-dart"
  :commit "6508c728e2076de3463bd1af0819c9e6962912d3"
  :revdesc "6508c728e207"
  :keywords '("language"))
