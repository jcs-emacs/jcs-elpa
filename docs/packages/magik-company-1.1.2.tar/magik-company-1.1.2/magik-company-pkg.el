;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-company" "1.1.2"
  "Magik backend for company-mode."
  '((emacs      "29.1")
    (magik-mode "0.6.5")
    (company    "1.0.2")
    (yasnippet  "0.14.0"))
  :url "https://github.com/reinierkof/magik-company"
  :commit "959c0030a4fffbad61013394492ba42ca46e3180"
  :revdesc "959c0030a4ff"
  :keywords '("convenience")
  :authors '(("Reinier Koffijberg" . "reinierkof@gmail.com"))
  :maintainers '(("Reinier Koffijberg" . "reinierkof@gmail.com")))
