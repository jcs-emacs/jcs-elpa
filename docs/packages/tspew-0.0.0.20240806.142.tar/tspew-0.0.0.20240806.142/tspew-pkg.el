;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tspew" "0.0.0.20240806.142"
  "Clean and format \"template spew\" errors from gcc and Clang."
  '((emacs "29.1"))
  :url "https://github.com/jefftrull/tspew"
  :commit "582b7f63fe5bd69b343d5733d0f109f4d9a826a3"
  :revdesc "582b7f63fe5b"
  :authors '(("Jeff Trull" . "edaskel@att.net"))
  :maintainers '(("Jeff Trull" . "edaskel@att.net")))
