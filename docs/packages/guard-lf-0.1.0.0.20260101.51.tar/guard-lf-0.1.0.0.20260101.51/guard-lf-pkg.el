;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guard-lf" "0.1.0.0.20260101.51"
  "Guard large files."
  '((emacs "27.1"))
  :url "https://github.com/jcs-elpa/guard-lf"
  :commit "cea3ccc0b91e2bf4947e21bde777c00ed5b47ecb"
  :revdesc "cea3ccc0b91e"
  :keywords '("help")
  :authors '(("JenChieh" . "jcs090218@gmail.com"))
  :maintainers '(("JenChieh" . "jcs090218@gmail.com")))
