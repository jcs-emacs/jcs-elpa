;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-control" "0.4.0.0.20260128.1027"
  "Management for indentation level."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/indent-control"
  :commit "8bd4a44c2ae51f781bc3b86f09869f71343ca1ff"
  :revdesc "8bd4a44c2ae5"
  :keywords '("convenience" "control" "indent" "tab" "generic" "level")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
