;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellsp" "0.2.0"
  "Elisp Language Server."
  '((emacs    "29.1")
    (lsp-mode "6.0.1")
    (log4e    "0.1.0")
    (dash     "2.14.1")
    (s        "1.12.0")
    (company  "0.8.12")
    (msgu     "0.1.0"))
  :url "https://github.com/elisp-lsp/Ellsp"
  :commit "36580dd6e6f29a73c8a9ac53966d450b0399679b"
  :revdesc "36580dd6e6f2"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
