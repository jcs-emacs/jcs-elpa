;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260304.1331"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion"
  :commit "165cfcc5b4659f1ec6ab6fd27037aafd6d22f9b0"
  :revdesc "165cfcc5b465"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
