;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "breadcrumb" "1.1.0.0.20261127.4"
  "Project and imenu-based breadcrumb paths."
  '((emacs   "28.1")
    (project "0.9.8"))
  :url "https://github.com/joaotavora/breadcrumb"
  :commit "194f206ee956203a72d5992ee072d4d131fc76ba"
  :revdesc "194f206ee956"
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
