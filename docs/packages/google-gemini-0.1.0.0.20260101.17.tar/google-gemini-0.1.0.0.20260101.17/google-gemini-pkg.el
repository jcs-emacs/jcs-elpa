;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-gemini" "0.1.0.0.20260101.17"
  "Elisp library for the Google Gemini API."
  '((emacs   "26.1")
    (request "0.3.0")
    (tblui   "0.1.0"))
  :url "https://github.com/emacs-openai/google-gemini"
  :commit "45838ff35e4128d40258c20fd2b26e9a1701b149"
  :revdesc "45838ff35e41"
  :keywords '("comm" "google" "gemini")
  :authors '(("JenChieh" . "jcs090218@gmail.com"))
  :maintainers '(("JenChieh" . "jcs090218@gmail.com")))
