;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260406.820"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "39a4b1c3d64b845bb87d6750a10745d5d06e2b18"
  :revdesc "39a4b1c3d64b"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
