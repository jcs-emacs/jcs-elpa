;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-todo" "0.5.0.0.20250417.4"
  "Search hl-todo keywords in consult."
  '((emacs   "29.1")
    (consult "1.9")
    (hl-todo "3.8.2"))
  :url "https://github.com/eki3z/consult-todo"
  :commit "f9ba063a6714cb95ddbd886786ada93771f3c140"
  :revdesc "f9ba063a6714"
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
