;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuz-bin" "1.5.0.0.20230325.115"
  "Fast and precise fuzzy scoring/matching utils."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/fuz-bin"
  :commit "dcaee61d4d64e81f17859c5ed36412042f2c832e"
  :revdesc "dcaee61d4d64"
  :keywords '("lisp")
  :authors '(("Zhu Zihao" . "all_but_last@163.com")
             ("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Zhu Zihao" . "all_but_last@163.com")
                 ("Jen-Chieh" . "jcs090218@gmail.com")))
