;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-grammarly-un" "0.2.2.0.20230409.535"
  "LSP Clients for Grammarly (Unofficial)."
  '((emacs     "27.1")
    (lsp-mode  "6.1")
    (grammarly "0.3.0")
    (request   "0.3.0")
    (s         "1.12.0")
    (ht        "2.3"))
  :url "https://github.com/emacs-grammarly/lsp-grammarly-un"
  :commit "cf9142c57b9a1514f58bb5e17b2627bb928736d4"
  :revdesc "cf9142c57b9a"
  :keywords '("convenience" "lsp" "grammarly" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
