;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ff-guard" "0.1.0.0.20260101.559"
  "Create parent directory for non-existent file."
  '((emacs "26.1")
    (f     "0.20.0")
    (s     "1.9.0"))
  :url "https://github.com/jcs-elpa/ff-guard"
  :commit "8518474cf040d4428c6645d4b58852939c17ac2b"
  :revdesc "8518474cf040"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
