;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "20260503.1233"
  "LSP Clients for LTEX+."
  '((emacs    "29.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-languagetool/lsp-ltex-plus"
  :commit "c6bf97f4b75ca8485baa6e951536cee410010938"
  :revdesc "c6bf97f4b75c"
  :keywords '("convenience" "lsp" "languagetool" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
