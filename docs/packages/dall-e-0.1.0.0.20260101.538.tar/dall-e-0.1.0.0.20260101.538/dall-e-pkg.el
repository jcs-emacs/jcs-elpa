;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dall-e" "0.1.0.0.20260101.538"
  "Use DALL-E inside Emacs."
  '((emacs            "27.1")
    (openai           "0.1.0")
    (lv               "0.0")
    (ht               "2.0")
    (spinner          "1.7.4")
    (reveal-in-folder "0.1.2")
    (async            "1.9.3"))
  :url "https://github.com/emacs-openai/dall-e"
  :commit "036941cf7f39226d9cdd86ca331941c69c16f2ca"
  :revdesc "036941cf7f39"
  :keywords '("comm" "dall-e")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
