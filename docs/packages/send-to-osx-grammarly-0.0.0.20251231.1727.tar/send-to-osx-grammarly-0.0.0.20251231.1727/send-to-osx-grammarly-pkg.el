;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "send-to-osx-grammarly" "0.0.0.20251231.1727"
  "A simple plugin to sent text to Grammarly."
  '((emacs "24.3"))
  :url "https://github.com/emacs-grammarly/send-to-osx-grammarly"
  :commit "e4ee071e704e30f2704ca3fa3e233249e726a9ae"
  :revdesc "e4ee071e704e"
  :keywords '("convenience" "osx" "grammarly")
  :authors '(("Marcin Magnus" . "m.magnus@zoho.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
