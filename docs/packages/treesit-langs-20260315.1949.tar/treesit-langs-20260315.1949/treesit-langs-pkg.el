;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260315.1949"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "0c9a1d571d6de5dc6438629449e163189d4ce72e"
  :revdesc "0c9a1d571d6d"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
