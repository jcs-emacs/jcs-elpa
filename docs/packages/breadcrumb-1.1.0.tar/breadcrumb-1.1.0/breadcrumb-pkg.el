;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "breadcrumb" "1.1.0"
  "Project and imenu-based breadcrumb paths."
  '((emacs   "28.1")
    (project "0.9.8"))
  :url "https://github.com/joaotavora/breadcrumb"
  :commit "f636f2643a2492f350d7c3624b8e6b9ed9bd2a7f"
  :revdesc "f636f2643a24"
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
