;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-paths" "0.1.0.0.20260101.28"
  "A company backend for paths."
  '((emacs   "28.1")
    (company "0.8.12"))
  :url "https://github.com/emacs-vs/company-paths"
  :commit "66fc3915ce0603baddee1a1649557bffcbcd18fd"
  :revdesc "66fc3915ce06"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
