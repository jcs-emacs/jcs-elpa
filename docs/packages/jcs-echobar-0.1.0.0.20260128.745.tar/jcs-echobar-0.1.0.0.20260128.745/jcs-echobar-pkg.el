;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jcs-echobar" "0.1.0.0.20260128.745"
  "An echo-bar for jcs-emacs."
  '((emacs          "29.1")
    (elenv          "0.1.0")
    (echo-bar       "1.0.0")
    (indent-control "0.1.0")
    (show-eol       "0.1.0")
    (keycast        "1.2.0"))
  :url "https://github.com/jcs-emacs/jcs-echobar"
  :commit "c591041b81db465654b9bcb9cc68bc74f827399a"
  :revdesc "c591041b81db"
  :keywords '("faces" "echo-bar")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
