;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.6.0.20261016.2"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "31")
    (cl-lib "1.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "e834189f13c7b8add86fd419b3c243dd9afa90e9"
  :revdesc "e834189f13c7"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
