;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico-flx" "0.1.0.0.20260616.26"
  "Flx integration for vertico."
  '((emacs     "28.1")
    (vertico   "0.22")
    (flx       "0.5")
    (flx-style "0.1.0")
    (ht        "2.0")
    (f         "0.20.0")
    (mbs       "0.1.0")
    (s         "1.12.0"))
  :url "https://github.com/jcs-elpa/vertico-flx"
  :commit "115dfad9d1c60d877cb31e80034ce0f3a178d192"
  :revdesc "115dfad9d1c6"
  :keywords '("convenience" "vertico" "flx")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
