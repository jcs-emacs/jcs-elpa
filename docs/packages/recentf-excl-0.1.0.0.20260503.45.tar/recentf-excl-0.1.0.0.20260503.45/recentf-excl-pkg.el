;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recentf-excl" "0.1.0.0.20260503.45"
  "Exclude commands for recent files."
  '((emacs "26.1")
    (msgu  "0.1.0"))
  :url "https://github.com/jcs-elpa/recentf-excl"
  :commit "46a322a8a76d5ede2d80ec8e2dd7b5f6f7941050"
  :revdesc "46a322a8a76d"
  :keywords '("convenience" "excl" "exclude" "recentf")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
