;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellsp" "20260227.310"
  "Elisp Language Server."
  '((emacs    "28.1")
    (lsp-mode "6.0.1")
    (log4e    "0.1.0")
    (dash     "2.14.1")
    (s        "1.12.0")
    (company  "0.8.12")
    (msgu     "0.1.0"))
  :url "https://github.com/elisp-lsp/Ellsp"
  :commit "3a42472fd807da96d6ec0f89f5f4b2c1b411c113"
  :revdesc "3a42472fd807"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
