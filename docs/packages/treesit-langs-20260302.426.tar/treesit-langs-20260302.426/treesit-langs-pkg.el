;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260302.426"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "7115fbac63e29cae73f0001dd0aeb84bf2a39d0b"
  :revdesc "7115fbac63e2"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
