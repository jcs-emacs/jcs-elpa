;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "breadcrumb" "1.0.1.0.20260804.20"
  "Project and imenu-based breadcrumb paths."
  '((emacs   "28.1")
    (project "0.9.8"))
  :url "https://github.com/joaotavora/breadcrumb"
  :commit "bcf7f1d1c102f8430c017d66aeee5d12e26585a4"
  :revdesc "bcf7f1d1c102"
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
