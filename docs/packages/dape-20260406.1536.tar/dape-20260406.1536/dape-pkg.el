;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260406.1536"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "6fab87c15e5b68d9f3c7d0764978f196c53a578e"
  :revdesc "6fab87c15e5b"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
