;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-comment-return" "0.1.0.0.20260101.550"
  "Comment return like Visual Studio."
  '((emacs "28.1"))
  :url "https://github.com/emacs-vs/vs-comment-return"
  :commit "3f26e9337c0ed11621fdeb6b02a3f751b5e7bf19"
  :revdesc "3f26e9337c0e"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
