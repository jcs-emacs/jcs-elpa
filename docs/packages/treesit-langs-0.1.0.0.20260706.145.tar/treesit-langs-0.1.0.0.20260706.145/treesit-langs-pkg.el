;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "0.1.0.0.20260706.145"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "6df96a0dfcaec7b74bc656de9fc07785ad1ed627"
  :revdesc "6df96a0dfcae"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
