;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.0.0.20260906.6"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "f613b25a19aa7567a22ef17d76a09dab06ae7c4e"
  :revdesc "f613b25a19aa"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
