;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-c-headers" "0.1.0.0.20231223.805"
  "Company mode backend for C/C++ header files."
  '((emacs   "26.1")
    (company "0.8")
    (f       "0.20.0"))
  :url "https://github.com/elp-revive/company-c-headers"
  :commit "fa1b905a5f5bb0d9372ca2763d7ea23f3f58c624"
  :revdesc "fa1b905a5f5b"
  :keywords '("convenience" "development" "company")
  :authors '(("Alastair Rankine" . "alastair@girtby.net"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
