;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0.0.20261120.9"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "94c54d0583db6bf1f8db9213997500004d3d3884"
  :revdesc "94c54d0583db"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
