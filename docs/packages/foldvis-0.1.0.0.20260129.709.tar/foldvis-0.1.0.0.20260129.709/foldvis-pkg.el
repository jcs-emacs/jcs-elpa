;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "foldvis" "0.1.0.0.20260129.709"
  "Display indicators for various folding systems."
  '((emacs         "26.1")
    (elenv         "0.1.0")
    (fringe-helper "1.0.1"))
  :url "https://github.com/emacs-vs/foldvis"
  :commit "b54bef0ce0a484cb90a414eec9725bb786058fd5"
  :revdesc "b54bef0ce0a4"
  :keywords '("convenience" "folding")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
