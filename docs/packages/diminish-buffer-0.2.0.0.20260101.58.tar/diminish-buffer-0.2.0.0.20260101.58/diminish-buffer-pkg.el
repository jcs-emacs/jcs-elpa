;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diminish-buffer" "0.2.0.0.20260101.58"
  "Diminish (hide) buffers from buffer-menu."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/diminish-buffer"
  :commit "bd94b5b58655454728b655a30c93c0347749cf37"
  :revdesc "bd94b5b58655"
  :keywords '("convenience" "diminish" "hide" "buffer" "menu")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
