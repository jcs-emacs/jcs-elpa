;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260501.7"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "77db894f9e771573cf87aac23ab3ee8522d7e861"
  :revdesc "77db894f9e77"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
