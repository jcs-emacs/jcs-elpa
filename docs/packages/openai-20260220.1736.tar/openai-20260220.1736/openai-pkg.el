;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "openai" "20260220.1736"
  "Elisp library for the OpenAI API."
  '((emacs   "26.1")
    (request "0.3.0")
    (tblui   "0.1.0"))
  :url "https://github.com/emacs-openai/openai"
  :commit "f5439fff3a32c9f76338f79e0654473ff6096a63"
  :revdesc "f5439fff3a32"
  :keywords '("comm" "openai")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
