;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emp" "0.1.0.0.20260101.559"
  "Emacs Music Playlist."
  '((emacs       "27.1")
    (sound-async "0.1.0")
    (f           "0.20.0")
    (buffer-wrap "0.1.5")
    (msgu        "0.1.0"))
  :url "https://github.com/jcs-elpa/emp"
  :commit "5de03a71209e7b23859140d8ec22f53797f16299"
  :revdesc "5de03a71209e"
  :keywords '("multimedia")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
