;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jcs-modeline" "0.2.0.0.20260214.15"
  "A modeline for jcs-emacs."
  '((emacs             "29.1")
    (moody             "0.7.1")
    (minions           "0.3.7")
    (elenv             "0.1.0")
    (nerd-icons        "0.0.1")
    (reveal-in-folder  "0.1.2")
    (goto-line-preview "0.1.0")
    (goto-char-preview "0.1.0"))
  :url "https://github.com/jcs-emacs/jcs-modeline"
  :commit "a136c07fbe65628f5ff6ef80b466163ef02c3df5"
  :revdesc "a136c07fbe65"
  :keywords '("faces" "mode-line")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
