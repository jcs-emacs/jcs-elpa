;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-compose" "0.1.0"
  "Lsp-mode client for compose server."
  '((emacs "26"))
  :url "https://github.com/lepisma/compose-language-server.el"
  :commit "44df194778503cd2e29e907af4c6989c7ea27d1c"
  :revdesc "44df19477850"
  :authors '(("Abhinav Tushar" . "abhinav@lepisma.xyz"))
  :maintainers '(("Abhinav Tushar" . "abhinav@lepisma.xyz")))
