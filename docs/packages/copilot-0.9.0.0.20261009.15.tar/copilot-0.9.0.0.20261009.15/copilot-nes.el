;;; copilot-nes.el --- Copilot Next Edit Suggestions -*- lexical-binding: t; -*-

;; Copyright (C) 2022-2026 copilot-emacs maintainers

;; Author: Bozhidar Batsov <bozhidar@batsov.dev>
;; URL: https://github.com/copilot-emacs/copilot.el
;; Keywords: convenience copilot

;; The MIT License (MIT)

;; Permission is hereby granted, free of charge, to any person obtaining a copy
;; of this software and associated documentation files (the "Software"), to deal
;; in the Software without restriction, including without limitation the rights
;; to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
;; copies of the Software, and to permit persons to whom the Software is
;; furnished to do so, subject to the following conditions:

;; The above copyright notice and this permission notice shall be included in all
;; copies or substantial portions of the Software.

;; THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
;; IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
;; FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
;; AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
;; LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
;; OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
;; SOFTWARE.

;;; Commentary:

;; Copilot Next Edit Suggestions (NES) predicts edits the developer will want
;; to make next, based on recent edit history.  Unlike inline completions (ghost
;; text at cursor), NES suggestions can appear anywhere in the file and can
;; replace or delete existing text.
;;
;; Enable `copilot-nes-mode' in a buffer to start receiving suggestions.  NES
;; relies on `copilot-mode' to start and sync the language server, so enable
;; `copilot-mode' in the same buffer.
;;
;; Usage:
;;   (add-hook 'prog-mode-hook #'copilot-mode)
;;   (add-hook 'prog-mode-hook #'copilot-nes-mode)
;;
;; Key bindings (active when a suggestion is pending):
;;   TAB   — accept the suggestion
;;   C-g   — dismiss the suggestion

;;; Code:

(require 'copilot)
(require 'track-changes)

(defconst copilot-nes--min-server-version "1.434.0"
  "Minimum copilot-language-server version required for NES support.")

;;
;; Customization
;;

(defcustom copilot-nes-idle-delay 0.5
  "Seconds of idle time before requesting a NES suggestion."
  :type 'number
  :group 'copilot
  :package-version '(copilot . "0.5"))

(defcustom copilot-nes-auto-dismiss-move-count 3
  "Number of cursor movements before auto-dismissing a suggestion."
  :type 'integer
  :group 'copilot
  :package-version '(copilot . "0.5"))

(defcustom copilot-nes-auto-dismiss-distance 40
  "Max lines between point and suggestion before auto-dismissing."
  :type 'integer
  :group 'copilot
  :package-version '(copilot . "0.5"))

;;
;; Faces
;;

(defface copilot-nes-deletion-face
  '((t :inherit diff-removed :strike-through t))
  "Face for text that a NES suggestion would delete."
  :group 'copilot)

(defface copilot-nes-insertion-face
  '((t :inherit diff-added))
  "Face for text that a NES suggestion would insert."
  :group 'copilot)

;;
;; Buffer-local state
;;

(defvar-local copilot-nes--edit nil
  "The pending NES edit plist, or nil.
Contains keys :text, :range, :command, and :textDocument.")

(defvar-local copilot-nes--overlays nil
  "List of overlays used to display the current NES suggestion.")

(defvar-local copilot-nes--timer nil
  "Idle timer for requesting NES suggestions.")

(defvar-local copilot-nes--move-count 0
  "Number of cursor movements since the suggestion was shown.")

(defvar-local copilot-nes--last-point nil
  "Position of point after the previous command, for detecting actual movement.")

;;
;; Internal helpers
;;

(defun copilot-nes--check-server-version ()
  "Warn if the installed copilot-language-server is too old for NES."
  (let ((installed (copilot-installed-version)))
    (when (and installed
               (version-list-< (version-to-list installed)
                                (version-to-list copilot-nes--min-server-version)))
      (display-warning
       'copilot-nes
       (format "NES requires copilot-language-server >= %s, but %s is installed.
Run `M-x copilot-reinstall-server' to upgrade."
               copilot-nes--min-server-version installed)
       :warning))))

(defun copilot-nes--edit-start-line ()
  "Return the buffer line number where the current edit start, or nil."
  (when copilot-nes--edit
    (let* ((range (plist-get copilot-nes--edit :range))
           (start (plist-get range :start))
           (line (plist-get start :line)))
      (+ line copilot--line-bias))))

(defun copilot-nes--range-to-region (range)
  "Convert an LSP RANGE plist to a (BEG . END) cons in buffer positions."
  (let* ((start (plist-get range :start))
         (end (plist-get range :end))
         (sline (plist-get start :line))
         (schar (plist-get start :character))
         (eline (plist-get end :line))
         (echar (plist-get end :character))
         beg epos)
    (save-excursion
      (goto-char (point-min))
      (forward-line (+ sline (1- copilot--line-bias)))
      (copilot--goto-utf16-offset schar)
      (setq beg (point))
      (goto-char (point-min))
      (forward-line (+ eline (1- copilot--line-bias)))
      (copilot--goto-utf16-offset echar)
      (setq epos (point)))
    (cons beg epos)))

;;
;; Overlay display
;;

(defun copilot-nes--clear ()
  "Clear the current NES suggestion and overlays."
  (mapc #'delete-overlay copilot-nes--overlays)
  (setq copilot-nes--overlays nil)
  (setq copilot-nes--edit nil)
  (setq copilot-nes--move-count 0)
  (setq copilot-nes--last-point nil))

(defun copilot-nes--shadow-completion-p ()
  "Return non-nil when a pending NES suggestion should hide completions.
Registered in `copilot-disable-display-predicates' so that regular
`copilot-mode' completions are suppressed while a NES suggestion is
pending."
  copilot-nes--edit)

(add-to-list 'copilot-disable-display-predicates #'copilot-nes--shadow-completion-p)

(defun copilot-nes--joins-previous-p (string index)
  "Return non-nil if the character at INDEX in STRING joins the one before.
That is a combining mark, an emoji modifier, a zero-width joiner or the
character after one: a hunk boundary at INDEX would split what is
displayed as a single character."
  (and (< 0 index (length string))
       (let ((char (aref string index)))
         (or (memq (get-char-code-property char 'general-category) '(Mn Me))
             (<= #x1F3FB char #x1F3FF)
             (eq char #x200D)
             (eq (aref string (1- index)) #x200D)))))

(defun copilot-nes--trim-hunk (old new offset)
  "Return the minimal hunk that turns OLD into NEW, or nil if they match.
OFFSET is the buffer position where OLD starts.  The hunk is a list
\(BEG END TEXT) meaning the buffer text from BEG to END becomes TEXT;
the text OLD and NEW share at either end is left out of it, short of
splitting a character from the marks or modifiers attached to it."
  (unless (string= old new)
    (let ((prefix (length (copilot--string-common-prefix old new)))
          (suffix 0))
      (while (and (> prefix 0)
                  (or (copilot-nes--joins-previous-p old prefix)
                      (copilot-nes--joins-previous-p new prefix)))
        (setq prefix (1- prefix)))
      ;; Don't let the suffix reclaim characters already in the prefix
      ;; (e.g. "aa" -> "aaa").
      (setq suffix (min (length (copilot--string-common-prefix (reverse old)
                                                               (reverse new)))
                        (- (min (length old) (length new)) prefix)))
      (while (and (> suffix 0)
                  (or (copilot-nes--joins-previous-p old (- (length old) suffix))
                      (copilot-nes--joins-previous-p new (- (length new) suffix))))
        (setq suffix (1- suffix)))
      (list (+ offset prefix)
            (+ offset (- (length old) suffix))
            (substring new prefix (- (length new) suffix))))))

(defun copilot-nes--hunks (beg old new)
  "Return the hunks that turn OLD, starting at buffer position BEG, into NEW.
Each is a (BEG END TEXT) list as built by `copilot-nes--trim-hunk'.
When OLD and NEW have the same number of lines, each changed line gets
its own hunk, so an edit touching a few characters on several lines
reads as a few small changes rather than one block deletion followed by
one block insertion.  Otherwise return a single hunk with the unchanged
text at either end trimmed off."
  (let ((old-lines (split-string old "\n"))
        (new-lines (split-string new "\n")))
    (if (= (length old-lines) (length new-lines))
        (let ((pos beg)
              (hunks nil))
          (cl-loop for old-line in old-lines
                   for new-line in new-lines
                   do (when-let* ((hunk (copilot-nes--trim-hunk old-line new-line pos)))
                        (push hunk hunks))
                   (setq pos (+ pos (length old-line) 1)))
          (nreverse hunks))
      (delq nil (list (copilot-nes--trim-hunk old new beg))))))

(defun copilot-nes--display-hunk (beg end text)
  "Show the hunk replacing the buffer text from BEG to END with TEXT."
  ;; Deletion overlay: highlight replaced text with strikethrough
  (when (> end beg)
    (let ((ov (make-overlay beg end nil nil nil)))
      (overlay-put ov 'face 'copilot-nes-deletion-face)
      (overlay-put ov 'copilot-nes t)
      (overlay-put ov 'evaporate t)
      (overlay-put ov 'priority 100)
      (push ov copilot-nes--overlays)))
  ;; Insertion overlay: show new text.  The overlay is zero-width
  ;; (it only carries an `after-string'), so it must NOT be marked
  ;; `evaporate' — Emacs deletes an empty overlay the moment that
  ;; property is set, which would make the insertion invisible.
  (unless (string-empty-p text)
    (let ((ov (make-overlay end end nil nil nil)))
      (overlay-put ov 'after-string
                   (propertize text 'face 'copilot-nes-insertion-face))
      (overlay-put ov 'copilot-nes t)
      (overlay-put ov 'priority 100)
      (push ov copilot-nes--overlays))))

(defun copilot-nes--display (edit)
  "Display EDIT as overlays in the buffer.
Only the parts that actually change are highlighted (see
`copilot-nes--hunks'); accepting the suggestion still applies EDIT as a
whole.  An EDIT that changes nothing is dropped rather than left
pending, invisible."
  (copilot-nes--clear)
  (when-let* ((hunks (copilot--dbind (text range) edit
                       (let* ((region (copilot-nes--range-to-region range))
                              (beg (car region)))
                         (copilot-nes--hunks
                          beg
                          (buffer-substring-no-properties beg (cdr region))
                          (or text ""))))))
    (setq copilot-nes--edit edit)
    (pcase-dolist (`(,hunk-beg ,hunk-end ,hunk-text) hunks)
      (copilot-nes--display-hunk hunk-beg hunk-end hunk-text))
    ;; Shadow any completion that is already on screen; the disable-display
    ;; predicate keeps `copilot-mode' from re-showing one while the suggestion
    ;; is pending.
    (copilot-clear-overlay)
    ;; Record point so the post-command hook can detect actual movement
    (setq copilot-nes--last-point (point))
    ;; Notify server that we showed the suggestion
    (copilot--dbind (command) edit
      (when command
        (copilot--notify 'textDocument/didShowInlineEdit
                         (list :item (list :command command)))))))

;;
;; Request
;;

(defun copilot-nes--handle-response (response expected-uri expected-version)
  "Process RESPONSE from a NES request.
Only display the suggestion when the document version matches
EXPECTED-VERSION and the URI matches EXPECTED-URI."
  (copilot--dbind (edits) response
    (when (and edits (sequencep edits) (> (length edits) 0))
      (let* ((edit (if (vectorp edits) (aref edits 0) (car edits))))
        ;; Validate version matches
        (copilot--dbind (textDocument) edit
          (copilot--dbind (version (resp-version version)) textDocument
            (when (and (= resp-version expected-version)
                       (string= (plist-get textDocument :uri) expected-uri))
              (copilot-nes--display edit))))))))

(defun copilot-nes--request ()
  "Request a NES suggestion from the Copilot server."
  (interactive)
  (copilot-nes--clear)
  (when (copilot--connection-alivep)
    (let ((uri (copilot--get-uri))
          (version copilot--doc-version)
          (pos (copilot--lsp-pos)))
      (copilot--async-request
       'textDocument/copilotInlineEdit
       (list :textDocument (list :uri uri :version version)
             :position pos)
       :success-fn
       (lambda (response)
         (copilot-nes--handle-response response uri version))
       :timeout-fn
       (lambda ()
         (copilot--log 'warning "NES request timed out."))))))

;;
;; Accept
;;

(defun copilot-nes-accept ()
  "Accept the current NES suggestion.
If point is far from the edit, jump there first.  On second
invocation (or when already at the edit), apply the edit."
  (interactive)
  (when copilot-nes--edit
    (let* ((region (copilot-nes--range-to-region
                    (plist-get copilot-nes--edit :range)))
           (beg (car region))
           (end (cdr region))
           (text (plist-get copilot-nes--edit :text))
           (command (plist-get copilot-nes--edit :command))
           (near-edit (<= (abs (- (line-number-at-pos) (line-number-at-pos beg))) 1)))
      (if (not near-edit)
          ;; Jump to the edit location so the user can see what they're accepting
          (goto-char beg)
        ;; Clear the overlays before touching the buffer so the suggestion's
        ;; ghost text can't linger over the applied edit until the next
        ;; command (notably under evil-mode).  The edit details are already
        ;; captured above, so resetting state here is safe.
        (copilot-nes--clear)
        ;; Apply the edit
        (delete-region beg end)
        (goto-char beg)
        (insert (or text ""))
        ;; Telemetry: execute the command associated with the edit
        (when command
          (copilot--notify 'workspace/executeCommand
                           (list :command (plist-get command :command)
                                 :arguments (plist-get command :arguments))))))))

;;
;; Dismiss
;;

(defun copilot-nes-dismiss ()
  "Dismiss the current NES suggestion."
  (interactive)
  (copilot-nes--clear))

;;
;; Auto-triggering
;;

(defvar-local copilot-nes--track-changes-id nil
  "Tracker id from `track-changes-register' for this buffer.")

(defun copilot-nes--on-change (id &optional _distance)
  "Handle a `track-changes' signal for tracker ID.
Any buffer edit shifts the positions a pending suggestion was drawn at,
so drop it (e.g. after accepting a `copilot-mode' completion) and
schedule a fresh request.  This catches every text modification, no
matter which command produced it."
  (condition-case err
      (progn
        ;; We don't need the change details, but must fetch to re-arm the tracker.
        (track-changes-fetch id #'ignore)
        (when copilot-nes--edit
          (copilot-nes--clear))
        (copilot-nes--schedule-request))
    (error
     (copilot--log 'error "NES change fetch failed: %s"
                   (error-message-string err)))))

(defun copilot-nes--post-command ()
  "Auto-dismiss a pending suggestion once point wanders away from it.
Text edits are handled separately via `track-changes'; this only tracks
cursor movement, which does not modify the buffer."
  (when copilot-nes--edit
    (when (and copilot-nes--last-point (/= (point) copilot-nes--last-point))
      (cl-incf copilot-nes--move-count)
      (when (or (>= copilot-nes--move-count copilot-nes-auto-dismiss-move-count)
                (copilot-nes--too-far-p))
        (copilot-nes--clear))))
  (setq copilot-nes--last-point (point)))

(defun copilot-nes--too-far-p ()
  "Return non-nil if point is too far from the current suggestion."
  (when copilot-nes--edit
    (let ((edit-line (copilot-nes--edit-start-line)))
      (and edit-line
           (> (abs (- (line-number-at-pos) edit-line))
              copilot-nes-auto-dismiss-distance)))))

(defun copilot-nes--schedule-request ()
  "Schedule a NES request after idle delay."
  (copilot-nes--cancel-timer)
  (setq copilot-nes--timer
        (run-with-idle-timer copilot-nes-idle-delay nil
                             #'copilot-nes--request-in-buffer
                             (current-buffer))))

(defun copilot-nes--request-in-buffer (buffer)
  "Request a NES suggestion in BUFFER if it is still live."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (when copilot-nes-mode
        (copilot-nes--request)))))

(defun copilot-nes--cancel-timer ()
  "Cancel the pending NES idle timer."
  (when (timerp copilot-nes--timer)
    (cancel-timer copilot-nes--timer)
    (setq copilot-nes--timer nil)))

;;
;; Minor mode
;;

(defvar copilot-nes-mode-map
  (let ((map (make-sparse-keymap))
        (accept `(menu-item "" copilot-nes-accept
                             :filter ,(lambda (cmd)
                                        (when copilot-nes--edit cmd))))
        (dismiss `(menu-item "" copilot-nes-dismiss
                              :filter ,(lambda (cmd)
                                         (when copilot-nes--edit cmd)))))
    ;; Bind both TAB (C-i) and <tab> (function key) so the binding
    ;; works regardless of whether another mode intercepts <tab>
    ;; before function-key-map translates it to TAB.
    (define-key map (kbd "TAB") accept)
    (define-key map [tab] accept)
    (define-key map (kbd "C-g") dismiss)
    map)
  "Keymap for `copilot-nes-mode'.
Bindings only activate when a NES suggestion is pending.")

(defun copilot-nes--warn-without-copilot-mode (buffer)
  "Warn if BUFFER has `copilot-nes-mode' enabled but not `copilot-mode'.
NES does not start or sync the language server on its own; it relies on
`copilot-mode' for that, so without it no suggestions ever appear."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (when (and copilot-nes-mode (not (bound-and-true-p copilot-mode)))
        (message "Copilot: `copilot-nes-mode' needs `copilot-mode' enabled in this buffer to receive suggestions")))))

;;;###autoload
(define-minor-mode copilot-nes-mode
  "Minor mode for Copilot Next Edit Suggestions.
NES predicts edits you will want to make next, based on recent
edit history.  Suggestions can appear anywhere in the file and
can replace or delete existing text.

NES does not start or sync the language server itself; it relies on
`copilot-mode' to do that.  Enable `copilot-mode' in the same buffer,
otherwise `copilot-nes-mode' produces no suggestions.

\\{copilot-nes-mode-map}"
  :lighter " NES"
  :keymap copilot-nes-mode-map
  (if copilot-nes-mode
      (progn
        (copilot-nes--check-server-version)
        ;; Warn when `copilot-mode' is missing, deferred to idle so that
        ;; enabling both modes from the same hook (in either order) doesn't
        ;; trigger a spurious warning.
        (run-with-idle-timer 0 nil
                             #'copilot-nes--warn-without-copilot-mode
                             (current-buffer))
        (unless copilot-nes--track-changes-id
          (setq copilot-nes--track-changes-id
                (track-changes-register #'copilot-nes--on-change :nobefore t)))
        (add-hook 'post-command-hook #'copilot-nes--post-command nil t))
    (copilot-nes--cancel-timer)
    (copilot-nes--clear)
    (when copilot-nes--track-changes-id
      (track-changes-unregister copilot-nes--track-changes-id)
      (setq copilot-nes--track-changes-id nil))
    (remove-hook 'post-command-hook #'copilot-nes--post-command t)))

(provide 'copilot-nes)

;;; copilot-nes.el ends here
