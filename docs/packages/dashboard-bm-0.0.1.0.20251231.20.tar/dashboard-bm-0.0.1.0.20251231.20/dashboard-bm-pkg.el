;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard-bm" "0.0.1.0.20251231.20"
  "Visual Bookmarks for Dashboard."
  '((emacs     "27.1")
    (dashboard "1.2.5")
    (bm        "0"))
  :url "https://github.com/emacs-dashboard/dashboard-bm"
  :commit "04cca2f177d16539112fad9cb873ee1d31b84b51"
  :revdesc "04cca2f177d1"
  :keywords '("tools")
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
