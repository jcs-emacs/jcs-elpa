;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mlua" "0.1.0.0.20260616.9"
  "LSP Clients for mLua."
  '((emacs    "29.1")
    (lsp-mode "6.1"))
  :url "https://github.com/MSW-cmty/lsp-mlua"
  :commit "5c924c216a317727e1e05fb4d41f01cf13fa04a1"
  :revdesc "5c924c216a31"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
