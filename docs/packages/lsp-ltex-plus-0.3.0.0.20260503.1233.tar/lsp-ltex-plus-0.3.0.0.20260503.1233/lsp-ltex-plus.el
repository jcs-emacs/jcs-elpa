;;; lsp-ltex-plus.el --- LSP Clients for LTEX+  -*- lexical-binding: t; -*-

;; Copyright (C) 2021-2026  Shen, Jen-Chieh
;; Created date 2021-04-03 00:35:56

;; Author: Shen, Jen-Chieh <jcs090218@gmail.com>
;; URL: https://github.com/emacs-languagetool/lsp-ltex-plus
;; Package-Version: 0.3.0.0.20260503.1233
;; Package-Revision: c6bf97f4b75c
;; Package-Requires: ((emacs "29.1") (lsp-mode "6.1"))
;; Keywords: convenience lsp languagetool checker

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; LSP server implementation for LTEX+
;;

;;; Code:

(require 'custom)
(require 'subr-x)

(require 'lsp-mode)
(require 'github-tags nil t)

(defgroup lsp-ltex-plus nil
  "Settings for the LTEX+ Language Server.

https://github.com/ltex-plus/ltex-ls-plus"
  :prefix "lsp-ltex-plus-"
  :group 'lsp-mode
  :link '(url-link :tag "Github" "https://github.com/emacs-languagetool/lsp-ltex-plus"))

(defconst lsp-ltex-plus-repo-path "ltex-plus/ltex-ls-plus"
  "Path points to the repository url.")

(defcustom lsp-ltex-plus-active-modes
  '( text-mode
     bibtex-mode context-mode
     latex-mode LaTeX-mode  ; AUCTeX 14+ has renamed latex-mode to LaTeX-mode
     markdown-mode gfm-mode
     org-mode
     rst-mode
     message-mode mu4e-compose-mode)
  "List of major mode that work with LTEX+ Language Server."
  :type '(list symbol)
  :group 'lsp-ltex-plus)

(defvar lsp-ltex-plus--filename nil "File base name.")
(defvar lsp-ltex-plus--extension-name nil "File name of the extension file from language server.")
(defvar lsp-ltex-plus--server-download-url nil "Automatic download url for lsp-ltex.")

(defcustom lsp-ltex-plus-server-store-path
  (expand-file-name "ltex-ls-plus" lsp-server-install-dir)
  "The path to the file in which LTEX+ Language Server will be stored."
  :type 'file
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-user-rules-path
  (let ((path (expand-file-name "lsp-ltex-plus" user-emacs-directory)))
    (unless (and (file-exists-p path) (file-directory-p path))
      (mkdir path t))
    path)
  "The path to the directory where `lsp-ltex-plus' will store user rules."
  :type 'directory
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-enabled nil
  "Controls whether the extension is enabled."
  :type '(choice (const :tag "false" nil)
                 (const :tag "true" t)
                 (vector string))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-language "en-US"
  "The language LanguageTool should check against."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-dictionary nil
  "Lists of additional words that should not be counted as spelling errors."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-disabled-rules nil
  "Lists of rules that should be disabled (if enabled by default by
LanguageTool)."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-enabled-rules nil
  "Lists of rules that should be enabled (if disabled by default by
LanguageTool)."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-hidden-false-positives nil
  "Lists of false-positive diagnostics to hide."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-bibtex-fields nil
  "List of BibTEX fields whose values are to be checked in BibTEX files."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-latex-commands nil
  "List of LATEX commands to be handled by the LATEX parser, listed together
with empty arguments."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-latex-environments nil
  "List of names of LATEX environments to be handled by the LATEX parser."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-markdown-nodes nil
  "List of Markdown node types to be handled by the Markdown parser."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-enable-picky-rules nil
  "Enable LanguageTool rules that are marked as picky and that are disabled
by default, e.g., rules about passive voice, sentence length, etc."
  :type 'boolean
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-mother-tongue ""
  "Optional mother tongue of the user (e.g., \"de-DE\")."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-language-model ""
  "Optional path to a directory with rules of a language model with
n-gram occurrence counts."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-neural-network-model ""
  "Optional path to a directory with rules of a pretrained neural network model."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-word-2-vec-model ""
  "Optional path to a directory with rules of a word2vec language model."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-languagetool-http-server-uri ""
  "If set to a non-empty string, LTEX+ will not use the bundled,
built-in version of LanguageTool.  Instead, LTEX+ will connect to an
external LanguageTool HTTP server."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-languagetool-org-username ""
  "Username/email as used to log in at languagetool.org for Premium API access.
Only relevant if `lsp-ltex-plus-languagetool-http-server-uri' is set."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-languagetool-org-api-key ""
  "API key for Premium API access.
Only relevant if `lsp-ltex-plus-languagetool-http-server-uri' is set."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-ls-path ""
  "If set to an empty string, LTEX+ automatically downloads ltex-ls from GitHub.
It stores it in the folder of the extension, and uses it for the checking
process.  You can point this setting to an ltex-ls release you downloaded by
yourself."
  :type 'directory
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-log-level "fine"
  "Logging level (verbosity) of the ltex-ls server log."
  :type '(choice (const "severe")
                 (const "warning")
                 (const "info")
                 (const "config")
                 (const "fine")
                 (const "finer")
                 (const "finest"))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-java-path ""
  "If set to an empty string and LTEX+ could not find Java on your computer,
LTEX+ automatically downloads a Java distribution (AdoptOpenJDK), stores it
in the folder of the extension, and uses it to run ltex-ls.  You can point
this setting to an existing Java installation on your computer to use that
installation instead."
  :type 'string
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-java-initial-heap-size 64
  "Initial size of the Java heap memory in megabytes.
Corresponds to Java's -Xmx option, this must be a positive integer"
  :type 'integer
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-java-maximum-heap-size 512
  "Maximum size of the Java heap memory in megabytes.
Corresponds to Java's -Xmx option, this must be a positive integer"
  :type 'integer
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-sentence-cache-size 2000
  "Size of the LanguageTool `ResultCache` in sentences.
This must be a positive integer."
  :type 'integer
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-completion-enabled nil ;; TODO: Add proper implementation
  "If this this is enabled, auto-completion list for the current word is sent.
The editor need to send a completion request."
  :type 'boolean
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-diagnostic-severity "information"
  "Severity of the diagnostics corresponding to the grammar and spelling errors."
  :type '(choice (const "error")
                 (const "warning")
                 (const "information")
                 (const "hint"))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-check-frequency "edit"
  "Controls when documents should be checked."
  :type '(choice (const "edit")
                 (const "save")
                 (const "manual"))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-clear-diagnostics-when-closing-file t
  "If non-nil, diagnostics of a file are cleared when the file is closed."
  :type 'boolean
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-status-bar-item nil ;; TODO: Add proper implementation
  "If non-nil, the status of LTEX+ is shown permanently in the status bar."
  :type 'boolean
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-trace-server "off"
  "Debug setting to log the communication between language client and server."
  :type '(choice (const "off")
                 (const "messages")
                 (const "verbose"))
  :group 'lsp-ltex-plus)

;;
;; (@* "Externals" )
;;

(declare-function github-tags "ext:github-tags.el")

;;
;; (@* "Util" )
;;

(defmacro lsp-ltex-plus--mute-apply (&rest body)
  "Execute BODY without message."
  (declare (indent 0) (debug t))
  `(let (message-log-max)
     (with-temp-message (or (current-message) nil)
       (let ((inhibit-message t)) ,@body))))

(defun lsp-ltex-plus--s-replace (old new s)
  "Replace OLD with NEW in S."
  (replace-regexp-in-string (regexp-quote old) new s t t))

(defun lsp-ltex-plus--execute (cmd &rest args)
  "Return non-nil if CMD executed succesfully with ARGS."
  (save-window-excursion
    (lsp-ltex-plus--mute-apply
      (= 0 (shell-command (concat cmd " "
                                  (mapconcat #'shell-quote-argument
                                             (cl-remove-if #'null args)
                                             " ")))))))

(defun lsp-ltex-plus--plist-keys (plist)
  "Return the keys of PLIST."
  (let (keys)
    (while plist
      (push (car plist) keys)
      (setq plist (cddr plist)))
    keys))

(defun lsp-ltex-plus--lsp-keys (table)
  "Similar to `lsp-get' and `lsp-put', it return the keys in TABLE."
  (if lsp-use-plists
      (lsp-ltex-plus--plist-keys table)
    (hash-table-keys table)))

(defun lsp-ltex-plus--serialize-symbol (sym dir)
  "Serialize SYM to DIR.
Return the written file name, or nil if SYM is not bound."
  (when (boundp sym)
    (let ((out-file (expand-file-name
                     (lsp-ltex-plus--s-replace "lsp-ltex-plus--" ""
                                               (symbol-name sym))
                     dir)))
      (lsp-message "[INFO] Saving `%s' to file \"%s\"" (symbol-name sym) out-file)
      (with-temp-buffer
        (prin1 (eval sym) (current-buffer))
        (lsp-ltex-plus--mute-apply (write-file out-file)))
      out-file)))

(defun lsp-ltex-plus--deserialize-symbol (sym dir &optional mutate)
  "Deserialize SYM from DIR, if MUTATE is non-nil, assign the object to SYM.
Return the deserialized object, or nil if the SYM.el file dont exist."
  (let ((in-file (expand-file-name
                  (lsp-ltex-plus--s-replace "lsp-ltex-plus--" ""
                                            (symbol-name sym))
                  dir))
        res)
    (when (file-exists-p in-file)
      (lsp-message "[INFO] Loading `%s' from file \"%s\"" (symbol-name sym) in-file)
      (with-temp-buffer
        (insert-file-contents in-file)
        (goto-char (point-min))
        (ignore-errors (setq res (read (current-buffer)))))
      (when mutate (set sym res)))
    res))

(defun lsp-ltex-plus--add-rule (lang rule rules-plist)
  "Add RULE of language LANG to the plist named RULES-PLIST (symbol)."
  (when (null (eval rules-plist))
    (set rules-plist (list lang [])))
  (plist-put (eval rules-plist) lang
             (vconcat (list rule) (plist-get (eval rules-plist) lang)))
  (when-let* ((out-file (lsp-ltex-plus--serialize-symbol rules-plist lsp-ltex-plus-user-rules-path)))
    (lsp-message "[INFO] Rule for language %s saved to file \"%s\"" (symbol-name lang) out-file)))

(defun lsp-ltex-plus-combine-plists (&rest plists)
  "Create a single property list from all plists in PLISTS.
Modified from `org-combine-plists'.  This supposes the values to be vectors,
and concatenate them."
  (let ((res (copy-sequence (pop plists)))
        prop val plist)
    (while plists
      (setq plist (pop plists))
      (while plist
        (setq prop (pop plist) val (pop plist))
        (setq res (plist-put res prop (vconcat val (plist-get res prop))))))
    res))

;;
;; (@* "Installation and Upgrade" )
;;

(defun lsp-ltex-plus--downloaded-extension-path ()
  "Return full path of the downloaded extension (compressed file).

This is use to unzip the language server files."
  (expand-file-name lsp-ltex-plus--extension-name lsp-ltex-plus-server-store-path))

(defun lsp-ltex-plus--extension-root ()
  "Return the root of the extension path.

This is use to active language server and check if language server's existence."
  (expand-file-name "latest" lsp-ltex-plus-server-store-path))

(defun lsp-ltex-plus--store-locally-p ()
  "Return non-nil if language server is installed locally."
  (and (string-prefix-p lsp-server-install-dir lsp-ltex-plus-server-store-path)
       (file-directory-p lsp-ltex-plus-server-store-path)))

(defun lsp-ltex-plus--current-version ()
  "Return the current version of LTEX."
  (if (lsp-ltex-plus--store-locally-p)
      (when-let* ((gz-files (directory-files-recursively lsp-ltex-plus-server-store-path "\\.gz"))
                  (tar (car gz-files))
                  (fn (file-name-nondirectory (lsp-ltex-plus--s-replace ".tar.gz" "" tar))))
        (lsp-ltex-plus--s-replace "ltex-ls-plus-" "" fn))
    (ignore-errors (gethash "ltex-ls-plus" (json-parse-string (shell-command-to-string "ltex-ls -V"))))))

(defun lsp-ltex-plus--latest-version ()
  "Return the latest version from remote repository."
  (when (featurep 'github-tags)
    (when-let* ((response (ignore-errors (github-tags lsp-ltex-plus-repo-path))))
      (let ((names (plist-get (cdr response) :names))
            (index 0) version ver)
        ;; Loop through tag name and fine the stable version
        (while (and (not version) (< index (length names)))
          (setq ver (nth index names)
                index (1+ index))
          (when (string-match-p "^[0-9.]+$" ver)  ; stable version are only with numbers and dot
            (setq version ver)))
        version))))

(defun lsp-ltex-plus--lsp-dependency ()
  "Register LSP dependency once."
  (lsp-dependency
   'ltex-ls-plus
   '(:system "ltex-ls-plus")
   `(:download :url ,lsp-ltex-plus--server-download-url
               :store-path ,(lsp-ltex-plus--downloaded-extension-path))))

(defcustom lsp-ltex-plus-version (or (lsp-ltex-plus--current-version)
                                     (lsp-ltex-plus--latest-version)
                                     "18.2.0")  ; fall back to preset version
  "Version of LTEX+ language server."
  :type 'string
  :set (lambda (symbol value)
         (set-default symbol value)
         (setq lsp-ltex-plus--filename (format "ltex-ls-plus-%s" value)
               lsp-ltex-plus--extension-name (format "%s.tar.gz" lsp-ltex-plus--filename)
               lsp-ltex-plus--server-download-url
               (format "https://github.com/%s/releases/download/%s/%s"
                       lsp-ltex-plus-repo-path value lsp-ltex-plus--extension-name))
         (lsp-ltex-plus--lsp-dependency))
  :group 'lsp-ltex-plus)

(defun lsp-ltex-plus-upgrade-ls ()
  "Upgrade LTEX+ to latest stable version.

If current server not found, install it then."
  (interactive)
  (let ((latest (lsp-ltex-plus--latest-version))
        (current (lsp-ltex-plus--current-version)))
    (if (and current (version<= latest current))
        (message "[INFO] Current LTEX+ server is up to date: %s" current)
      (when current
        ;; First delete all binary files
        (delete-directory lsp-ltex-plus-server-store-path t))
      (custom-set-variables `(lsp-ltex-plus-version ,latest))
      (lsp-install-server t 'ltex-ls)  ; this is async
      (message "[INFO] %s LTEX+ server version: %s"
               (if current "Upgrading" "Installing") lsp-ltex-plus-version))))

(defun lsp-ltex-plus-install-ls ()
  "Install LTEX+ language server."
  (let* ((tar (lsp-ltex-plus--downloaded-extension-path))
         (dest (file-name-directory tar))
         (output (expand-file-name lsp-ltex-plus--filename dest))
         (latest (expand-file-name "latest" (file-name-directory output)))
         (is-windows (eq system-type 'windows-nt)))
    (if (lsp-ltex-plus--execute "tar" "-xvzf" tar "-C" dest)
        (unless (lsp-ltex-plus--execute (if is-windows "move" "mv")
                                        (unless is-windows "-f")
                                        output latest)
          (error "[ERROR] Failed to rename version `%s` to latest" lsp-ltex-plus-version))
      (error "[ERROR] Failed to unzip tar, %s" tar))))

;;
;; (@* "Activation" )
;;

(defvar lsp-ltex-plus--stored-dictionary
  (lsp-ltex-plus--deserialize-symbol 'lsp-ltex-plus--stored-dictionary
                                     lsp-ltex-plus-user-rules-path)
  "The dictionary created from interactively added words.")

(defvar lsp-ltex-plus--stored-disabled-rules
  (lsp-ltex-plus--deserialize-symbol 'lsp-ltex-plus--stored-disabled-rules
                                     lsp-ltex-plus-user-rules-path)
  "The rules created from interactively added words.")

(defvar lsp-ltex-plus--stored-hidden-false-positives
  (lsp-ltex-plus--deserialize-symbol 'lsp-ltex-plus--stored-hidden-false-positives
                                     lsp-ltex-plus-user-rules-path)
  "The rules created from interactively added words.")

(defvar lsp-ltex-plus--combined-dictionary
  (lsp-ltex-plus-combine-plists lsp-ltex-plus-dictionary lsp-ltex-plus--stored-dictionary)
  "The combined `lsp-ltex-plus-dictionary' and interactively added words.")

(defvar lsp-ltex-plus--combined-disabled-rules
  (lsp-ltex-plus-combine-plists lsp-ltex-plus-disabled-rules lsp-ltex-plus--stored-disabled-rules)
  "The combined `lsp-ltex-plus-disabled-rules' and interactively added rules.")

(defvar lsp-ltex-plus--combined-hidden-false-positives
  (lsp-ltex-plus-combine-plists lsp-ltex-plus-hidden-false-positives
                                lsp-ltex-plus--stored-hidden-false-positives)
  "The combined `lsp-ltex-plus-hidden-false-positives' and interactively added rules.")

(defun lsp-ltex-plus--server-entry ()
  "Return the server entry file.

This file is use to activate the language server."
  (if (lsp-ltex-plus--store-locally-p)
      (concat (file-name-as-directory (lsp-ltex-plus--extension-root))
              (file-name-as-directory "bin")
              (if (eq system-type 'windows-nt)
                  "ltex-ls-plus.bat"
                "ltex-ls-plus"))
    (executable-find "ltex-ls-plus")))

(defun lsp-ltex-plus--server-command ()
  "Startup command for LTEX+ language server."
  (list (lsp-ltex-plus--server-entry)))

(lsp-register-custom-settings
 '(("ltex.enabled" lsp-ltex-plus-enabled)
   ("ltex.language" lsp-ltex-plus-language)
   ("ltex.dictionary" lsp-ltex-plus--combined-dictionary)
   ("ltex.disabledRules" lsp-ltex-plus--combined-disabled-rules)
   ("ltex.enabledRules" lsp-ltex-plus-enabled-rules)
   ("ltex.hiddenFalsePositives" lsp-ltex-plus--combined-hidden-false-positives)
   ("ltex.bibtex.fields" lsp-ltex-plus-bibtex-fields)
   ("ltex.latex.commands" lsp-ltex-plus-latex-commands)
   ("ltex.latex.environments" lsp-ltex-plus-latex-environments)
   ("ltex.markdown.nodes" lsp-ltex-plus-markdown-nodes)
   ("ltex.additionalRules.enablePickyRules" lsp-ltex-plus-additional-rules-enable-picky-rules t)
   ("ltex.additionalRules.motherTongue" lsp-ltex-plus-mother-tongue)
   ("ltex.additionalRules.languageModel" lsp-ltex-plus-additional-rules-language-model)
   ("ltex.additionalRules.neuralNetworkModel" lsp-ltex-plus-additional-rules-neural-network-model)
   ("ltex.additionalRules.word2VecModel" lsp-ltex-plus-additional-rules-word-2-vec-model)
   ("ltex.languageToolHttpServerUri" lsp-ltex-plus-languagetool-http-server-uri)
   ("ltex.languageToolOrg.username" lsp-ltex-plus-languagetool-org-username)
   ("ltex.languageToolOrg.apiKey" lsp-ltex-plus-languagetool-org-api-key)
   ("ltex.ltex-ls.path" lsp-ltex-plus-ls-path)
   ("ltex.ltex-ls.logLevel" lsp-ltex-plus-log-level)
   ("ltex.java.path" lsp-ltex-plus-java-path)
   ("ltex.java.initialHeapSize" lsp-ltex-plus-java-initial-heap-size)
   ("ltex.java.maximumHeapSize" lsp-ltex-plus-java-maximum-heap-size)
   ("ltex.sentenceCacheSize" lsp-ltex-plus-sentence-cache-size)
   ("ltex.completionEnabled" lsp-ltex-plus-completion-enabled t)
   ("ltex.diagnosticSeverity" lsp-ltex-plus-diagnostic-severity)
   ("ltex.checkFrequency" lsp-ltex-plus-check-frequency)
   ("ltex.clearDiagnosticsWhenClosingFile" lsp-ltex-plus-clear-diagnostics-when-closing-file t)
   ("ltex.statusBarItem" lsp-ltex-plus-status-bar-item t)
   ("ltex.trace.server" lsp-ltex-plus-trace-server)))

(lsp-ltex-plus--lsp-dependency)

(defun lsp-ltex-plus--action-add-to-rules (action-ht key rules-plist &optional store)
  "Execute action ACTION-HT by getting KEY and storing it in the RULES-PLIST.
When STORE is non-nil, this will also store the new plist in the directory
`lsp-ltex-plus-user-rules-path'."
  (let ((args-ht (lsp-get (if (vectorp action-ht) (elt action-ht 0) action-ht) key)))
    (dolist (lang (lsp-ltex-plus--lsp-keys args-ht))
      (let ((lang-key (if (stringp lang) (intern (concat ":" lang)) lang)))
        (mapc (lambda (rule)
                (lsp-ltex-plus--add-rule lang-key rule rules-plist)
                (when store
                  (lsp-ltex-plus--serialize-symbol rules-plist lsp-ltex-plus-user-rules-path)))
              (lsp-get args-ht lang-key))))))

(lsp-defun lsp-ltex-plus--code-action-add-to-dictionary ((&Command :arguments?))
  "Handle action for \"_ltex.addToDictionary\"."
  ;; Add rule internally to the `lsp-ltex-plus--stored-dictionary' plist and
  ;; store it in the directory `lsp-ltex-plus-user-rules-path'
  (lsp-ltex-plus--action-add-to-rules
   arguments? :words 'lsp-ltex-plus--stored-dictionary t)
  ;; Combine user configured words `lsp-ltex-plus-dictionary' and the internal
  ;; interactively generated `lsp-ltex-plus--stored-dictionary', and store them in
  ;; the internal `lsp-ltex-plus--combined-dictionary', which is sent to ltex-ls
  (setq lsp-ltex-plus--combined-dictionary
        (lsp-ltex-plus-combine-plists lsp-ltex-plus-dictionary lsp-ltex-plus--stored-dictionary))
  (lsp-message "[INFO] Word added to dictionary."))

(lsp-defun lsp-ltex-plus--code-action-hide-false-positives ((&Command :arguments?))
  "Handle action for \"_ltex.hideFalsePositives\"."
  (lsp-ltex-plus--action-add-to-rules arguments? :falsePositives
                                      'lsp-ltex-plus--stored-hidden-false-positives t)
  (setq lsp-ltex-plus--combined-hidden-false-positives
        (lsp-ltex-plus-combine-plists lsp-ltex-plus-hidden-false-positives
                                      lsp-ltex-plus--stored-hidden-false-positives))
  (lsp-message "[INFO] Rule added to false positives."))

(lsp-defun lsp-ltex-plus--code-action-disable-rules ((&Command :arguments?))
  "Handle action for \"_ltex.disableRules\"."
  (lsp-ltex-plus--action-add-to-rules arguments? :ruleIds
                                      'lsp-ltex-plus--stored-disabled-rules t)
  (setq lsp-ltex-plus--combined-disabled-rules
        (lsp-ltex-plus-combine-plists lsp-ltex-plus-disabled-rules
                                      lsp-ltex-plus--stored-disabled-rules))
  (lsp-message "[INFO] Rule disabled."))

(lsp-register-client
 (make-lsp-client
  :new-connection (lsp-stdio-connection
                   #'lsp-ltex-plus--server-command
                   (lambda () (let ((entry (lsp-ltex-plus--server-entry)))
                                (and (file-exists-p entry)
                                     (not (file-directory-p entry))
                                     (file-executable-p entry)))))
  :major-modes lsp-ltex-plus-active-modes
  :action-handlers
  (lsp-ht
   ("_ltex.addToDictionary" #'lsp-ltex-plus--code-action-add-to-dictionary)
   ("_ltex.disableRules" #'lsp-ltex-plus--code-action-disable-rules)
   ("_ltex.hideFalsePositives" #'lsp-ltex-plus--code-action-hide-false-positives))
  :priority -1
  :add-on? t
  :server-id 'ltex-ls-plus
  :download-server-fn
  (lambda (_client callback error-callback _update?)
    (lsp-package-ensure 'ltex-ls-plus (lambda (&rest _)
                                        (lsp-ltex-plus-install-ls)
                                        (funcall callback))
                        error-callback))))

(provide 'lsp-ltex-plus)
;;; lsp-ltex-plus.el ends here
