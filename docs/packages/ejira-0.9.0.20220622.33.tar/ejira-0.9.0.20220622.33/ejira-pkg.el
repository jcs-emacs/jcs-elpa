;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejira" "0.9.0.20220622.33"
  "Org-mode interface to JIRA."
  '((emacs "26.1"))
  :url "https://github.com/nyyManni/ejira"
  :commit "49cb61239b19bf13775528231d7d49656ec7a8bb"
  :revdesc "0.9-78-g49cb61239b19"
  :keywords '("calendar" "data" "org" "jira")
  :authors '(("Henrik Nyman" . "h@nyymanni.com"))
  :maintainers '(("Henrik Nyman" . "h@nyymanni.com")))
