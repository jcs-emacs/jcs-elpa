;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-geiser" "0.1.0.0.20260101.541"
  "Show Geiser result with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0")
    (geiser   "0.31.1"))
  :url "https://github.com/emacs-sideline/sideline-geiser"
  :commit "e93ac0afd43468b50d76f102868e0a9db4970725"
  :revdesc "e93ac0afd434"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
