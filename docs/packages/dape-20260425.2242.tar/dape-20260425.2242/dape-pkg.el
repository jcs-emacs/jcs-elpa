;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260425.2242"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "c8800ea78c118b70b631b8f892af3f4242db2296"
  :revdesc "c8800ea78c11"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
