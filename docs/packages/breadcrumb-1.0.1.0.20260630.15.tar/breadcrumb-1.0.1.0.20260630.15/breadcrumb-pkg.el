;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "breadcrumb" "1.0.1.0.20260630.15"
  "Project and imenu-based breadcrumb paths."
  '((emacs   "28.1")
    (project "0.9.8"))
  :url "https://github.com/joaotavora/breadcrumb"
  :commit "899ddc05c54ba9e005974deeea7518c798c1bd87"
  :revdesc "899ddc05c54b"
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
