;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260405.1707"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "39d842b99cb1e1712a9231650c847d2882307911"
  :revdesc "39d842b99cb1"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
