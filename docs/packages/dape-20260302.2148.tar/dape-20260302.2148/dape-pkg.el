;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260302.2148"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "0bdbcdf00d6de6a38c0ae596f515a457f24d9d93"
  :revdesc "0bdbcdf00d6d"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
