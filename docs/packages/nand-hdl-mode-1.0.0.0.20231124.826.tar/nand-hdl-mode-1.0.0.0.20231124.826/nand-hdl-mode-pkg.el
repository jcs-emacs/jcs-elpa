;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nand-hdl-mode" "1.0.0.0.20231124.826"
  "Major mode for NAND hdl files."
  '((emacs "25.1"))
  :url "https://github.com/nverno/nand-hdl-mode"
  :commit "b7701cf416b7fdbffd3ad0c3467e08f9c6a92abf"
  :revdesc "b7701cf416b7"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
