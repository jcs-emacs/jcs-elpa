;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260304.1606"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion"
  :commit "cfbae07c70d5ca32df171ce7e05fe9e298a20b59"
  :revdesc "cfbae07c70d5"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
