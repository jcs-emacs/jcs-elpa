;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "javap-mode" "9.0.20220523.1728"
  "Javap major mode."
  ()
  :url "https://github.com/elp-revive/javap-mode"
  :commit "25c3cd0d13b122fa1f06c054e319ef8218f9b48f"
  :revdesc "25c3cd0d13b1")
