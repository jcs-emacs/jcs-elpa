;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260216.525"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "d7cce4e92d90df2c71f8dfcc9c55a3e3f3ac9485"
  :revdesc "d7cce4e92d90"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
