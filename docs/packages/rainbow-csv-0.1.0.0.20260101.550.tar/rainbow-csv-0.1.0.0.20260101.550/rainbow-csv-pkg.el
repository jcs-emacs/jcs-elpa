;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-csv" "0.1.0.0.20260101.550"
  "Highlight CSV and TSV files in different rainbow colors."
  '((emacs    "27.1")
    (csv-mode "1.22"))
  :url "https://github.com/emacs-vs/rainbow-csv"
  :commit "5b0bbaca8c6c1785b5ddd48fdf16817acc046ad2"
  :revdesc "5b0bbaca8c6c"
  :keywords '("convenience" "csv")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
