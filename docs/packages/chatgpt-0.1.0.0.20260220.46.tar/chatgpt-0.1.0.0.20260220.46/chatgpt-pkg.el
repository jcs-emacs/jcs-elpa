;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt" "0.1.0.0.20260220.46"
  "Use ChatGPT inside Emacs."
  '((emacs         "28.1")
    (openai        "0.1.1")
    (lv            "0.0")
    (ht            "2.0")
    (markdown-mode "2.1")
    (spinner       "1.7.4"))
  :url "https://github.com/emacs-openai/chatgpt"
  :commit "49f16aad6c78fba3a4827f000710f26de5328693"
  :revdesc "49f16aad6c78"
  :keywords '("comm" "openai")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
