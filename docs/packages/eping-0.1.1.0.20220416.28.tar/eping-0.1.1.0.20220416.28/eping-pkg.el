;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eping" "0.1.1.0.20220416.28"
  "Ping websites to check internet connectivity."
  '((emacs "25.1"))
  :url "https://github.com/elp-revive/eping"
  :commit "b5ac5f046bfabdd60f1fa5fc0afde2487f72158f"
  :revdesc "b5ac5f046bfa"
  :keywords '("comm" "processes" "terminals" "unix")
  :authors '(("Sean Hutchings" . "seanhut@yandex.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
