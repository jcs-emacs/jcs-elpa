;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ts-docstr" "0.1.0.0.20260101.550"
  "A document string minor mode using tree-sitter."
  '((emacs       "27.1")
    (tree-sitter "0.15.1")
    (s           "1.9.0")
    (list-utils  "0.4.6")
    (msgu        "0.1.0")
    (refine      "0.4"))
  :url "https://github.com/emacs-vs/ts-docstr"
  :commit "f292ad9c433b3db08daf25679511e1e6a64987aa"
  :revdesc "f292ad9c433b"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
