;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-scroll-bar" "20260401.553"
  "Automatically show/hide scroll-bars as needed."
  '((emacs "29.1")
    (elenv "0.1.0"))
  :url "https://github.com/emacs-vs/auto-scroll-bar"
  :commit "eda69534357822aa68c0138481d26958c3b8d3d6"
  :revdesc "eda695343578"
  :keywords '("convenience" "scrollbar")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
