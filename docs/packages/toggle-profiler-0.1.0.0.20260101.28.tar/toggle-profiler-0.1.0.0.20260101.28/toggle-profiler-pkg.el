;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-profiler" "0.1.0.0.20260101.28"
  "Useful functions to interact with profiler."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/toggle-profiler"
  :commit "08763f55aa0fb5e1cea241749ac91b4d5b898b46"
  :revdesc "08763f55aa0f"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
