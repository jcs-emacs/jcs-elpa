;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jcs-frametitle" "0.1.0.0.20251231.1614"
  "A frame title for jcs-emacs."
  '((emacs "28.1")
    (elenv "0.1.0"))
  :url "https://github.com/jcs-emacs/jcs-frametitle"
  :commit "caacf59fc8afc8e9b0b194ac998e8de05cda1bc6"
  :revdesc "caacf59fc8af"
  :keywords '("faces" "frame-title")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
