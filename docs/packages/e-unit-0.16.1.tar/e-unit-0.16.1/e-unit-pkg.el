;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e-unit" "0.16.1"
  "Minitest/JUnit-style testing framework for Emacs Lisp."
  '((emacs "28.1"))
  :url "https://codeberg.org/Trevoke/eunit.el"
  :commit "5acaa0ec0ebfb71b5ca0b5c892c79100d2a98eb1"
  :revdesc "5acaa0ec0ebf"
  :keywords '("tools" "lisp" "testing" "tdd")
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
