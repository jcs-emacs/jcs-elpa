;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-fold" "0.2.0.0.20260417.1708"
  "Code folding using treesit."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-fold"
  :commit "e6b215b8f25f8c58606ab4f850794b61b61111e1"
  :revdesc "e6b215b8f25f"
  :keywords '("convenience" "folding" "tree-sitter")
  :authors '(("Junyi Hou" . "junyi.yi.hou@gmail.com")
             ("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
