;;; e-unit.el --- Minitest/JUnit-style testing framework for Emacs Lisp -*- lexical-binding: t -*-

;; Copyright (C) 2025
;; SPDX-License-Identifier: GPL-3.0-only

;; Author: Aldric Giacomoni <trevoke@gmail.com>
;; Package-Version: 20260103.2255
;; Package-Revision: 368867b491f0
;; Package-Requires: ((emacs "28.1"))
;; Keywords: tools, lisp, testing, tdd
;; URL: https://codeberg.org/Trevoke/eunit.el

;;; Commentary:

;; E-Unit is a minitest/JUnit-style testing framework for Emacs Lisp.
;; It provides test definition, assertions, extensibility, and output.
;;
;; Basic usage:
;;
;;   (deftest test-basic-math ()
;;     "Test basic arithmetic"
;;     (assert-equal 4 (+ 2 2)))
;;
;;   (e-unit-run-buffer)
;;
;; Suggested keybindings (add to your init.el):
;;
;;   (global-set-key (kbd "C-c C-t b") #'e-unit-run-buffer-compilation)
;;   (global-set-key (kbd "C-c C-t d") #'e-unit-run-directory-compilation)

;;; Code:

(require 'cl-lib)
(require 'compile)
(require 'xml)

;;; Global state

(defvar e-unit--tests nil
  "Registry of all defined tests.")

(defvar e-unit--file-hooks nil
  "Alist mapping files to their hook functions.
Structure: ((file . (:setup-each (fn1 fn2...)
                     :teardown-each (fn1 fn2...)
                     :setup-file (fn1 fn2...)
                     :teardown-file (fn1 fn2...))))")

(defvar e-unit--setup-suite-functions nil
  "List of functions to run once before the entire test suite.")

(defvar e-unit--teardown-suite-functions nil
  "List of functions to run once after the entire test suite.")

(defvar e-unit--current-test nil
  "Currently running test name.")

(defvar e-unit--results nil
  "Results of the current test run.")

(defvar e-unit--captured-error-location nil
  "Captured error location from backtrace.
Plist with :file, :line, :column keys.")

(defvar e-unit--assertion-position-queue nil
  "Queue of (file line column) for assertions in the file being loaded.
Built by `e-unit--scan-assertion-positions' before eval.")

(defvar e-unit--scanning-file nil
  "The file currently being scanned for assertion positions.")

(defvar e-unit--suite-setup-done nil
  "Whether suite setup has been run.")

(defvar e-unit--current-file nil
  "Currently running file name.")

(defvar e-unit--file-setups-done nil
  "Alist of files and whether their setup has been run.")

(defvar e-unit--context-stack nil
  "Current context stack (list of strings).
Plugins use this to scope hooks and create test grouping concepts.
Example: (\"describe:User Auth\" \"file:my-test.el\" \"suite\")")

(defvar e-unit--last-results nil
  "Results from the most recent test run.")

(defvar e-unit--in-directory-run nil
  "Non-nil when running tests as part of a directory run.
Used to suppress per-file summaries in favor of overall summary.")

(defvar e-unit--current-seed nil
  "Random seed for current test run.")

(defvar e-unit--config-shuffle-tests t
  "Whether to shuffle test execution order within a file.")

(defvar e-unit--config-shuffle-files t
  "Whether to shuffle file execution order in directory runs.")

(defvar e-unit--config-seed nil
  "Fixed random seed for reproducible test ordering.
When nil, uses random seed.")

(defvar e-unit--config-verbose nil
  "Whether to print verbose test output.")

(defvar e-unit--config-stop-on-failure nil
  "Whether to stop test execution on first failure.")

(defvar e-unit--include-autoload-tests nil
  "Whether to include autoload tests in normal test runs.
When nil (default), autoload tests are skipped during normal runs.
Set to t or use `e-unit-run-autoload-tests' to run them.")

(defvar e-unit-autoload-source-dirs nil
  "List of directories to add to load-path for autoload tests.
When nil (default), uses the project root directory.
Example: \\='(\"lisp/\" \"src/\")")

(defvar e-unit-autoload-package-name nil
  "Package name for autoload generation.
When nil (default), derived from project directory name.")

(defvar e-unit--initialized nil
  "Non-nil if `e-unit-initialize' has been called.
Used to make `e-unit-initialize' idempotent.")

(defvar e-unit--config-loaded nil
  "Non-nil if project config file has been loaded for current session.")

(defvar e-unit-config-file-name "Eunit"
  "Name of the project configuration file.
This file is searched for in the project root and loaded before
running tests.  Users can put configuration like `(e-unit-initialize)'
and reporter setup in this file.")

;;; Registration Hooks

(defvar e-unit-register-test-hook nil
  "Hook run during test registration (before storing).
Each function receives INFO, a plist with:
  :name      - Test name (symbol, immutable)
  :docstring - Test description (string, mutable)
  :file      - Definition file (string, immutable)
  :context   - Context stack at definition (list of strings)

Functions may:
- Modify :docstring (e.g., prepend context path)
- Add new keys to INFO (stored with test)
- Throw \\='e-unit-skip-registration to prevent registration

Functions run in order. Modifications accumulate.")

(defvar e-unit-after-register-test-hook nil
  "Hook run after test is fully registered.
Each function receives NAME (symbol) and INFO (plist, now immutable).
Typically used to add metadata via `e-unit-set-test-metadata'.")

;;; Project Configuration

(defun e-unit-project-root ()
  "Find the project root directory.
Searches upward from `default-directory' for a directory containing
either a `.git' directory or an `Eunit' file (or whatever
`e-unit-config-file-name' is set to).
Returns the directory path without trailing slash, or nil if not found."
  (let ((root (or (locate-dominating-file default-directory ".git")
                  (locate-dominating-file default-directory e-unit-config-file-name))))
    (when root
      (directory-file-name root))))

(defun e-unit-load-config ()
  "Load the project configuration file if it exists.
Searches for a file named `e-unit-config-file-name' (default \"Eunit\")
in the project root directory.  The file is evaluated as Emacs Lisp.

This function is idempotent - it only loads the config once per session.
Returns t if config was loaded, nil otherwise."
  (if e-unit--config-loaded
      nil
    (let* ((root (e-unit-project-root))
           (config-file (when root
                          (expand-file-name e-unit-config-file-name root))))
      (if (and config-file (file-exists-p config-file))
          (progn
            (load config-file nil t)
            (setq e-unit--config-loaded t)
            t)
        nil))))

;;; Error Location Capture

(defun e-unit--capture-error-location (&rest debugger-args)
  "Custom debugger function that captures error location from backtrace.
DEBUGGER-ARGS are the arguments passed by Emacs to the debugger.
This captures the source location and then signals to continue."
  ;; Only capture on error entry (first arg is 'error)
  (when (eq (car debugger-args) 'error)
    (let ((frames (backtrace-get-frames 'e-unit--capture-error-location)))
      ;; Walk frames to find one with source position
      (cl-loop for frame in frames
               for buffer = (backtrace-frame-buffer frame)
               for pos = (backtrace-frame-pos frame)
               when (and buffer pos (buffer-live-p buffer))
               do (with-current-buffer buffer
                    (save-excursion
                      (goto-char pos)
                      (setq e-unit--captured-error-location
                            (list :file (or buffer-file-name
                                            (buffer-name))
                                  :line (line-number-at-pos)
                                  :column (current-column)))))
               and return nil)))
  ;; Don't enter debugger - let error propagate to condition-case
  nil)

;;; Context Stack API

(defun e-unit-push-context (context-string)
  "Push CONTEXT-STRING onto the context stack.
This is used by plugins to create scoping contexts for hooks and test groups.
Returns nil (side-effect only operation)."
  (push context-string e-unit--context-stack)
  nil)

(defun e-unit-pop-context ()
  "Pop and return the most recent context from the stack.
Returns the popped context string, or nil if stack is empty."
  (pop e-unit--context-stack))

(defun e-unit-get-current-context ()
  "Get a copy of the current context stack.
Returns a list of context strings in LIFO order (most recent first).
Returns nil if the stack is empty.
The returned list is a copy to prevent accidental modification."
  (copy-sequence e-unit--context-stack))

;;; Hook Registry

(defvar e-unit--hooks (make-hash-table :test 'eq)
  "Registry of hooks by hook point.
Structure: {hook-point => [(fn . context-stack) ...]}")

(defun e-unit-add-hook (hook-point fn)
  "Register FN at HOOK-POINT, scoped to current context.
Hooks are executed in registration order (FIFO) when context matches."
  (let* ((current-context (e-unit-get-current-context))
         (entry (cons fn current-context))
         (hooks (gethash hook-point e-unit--hooks)))
    (puthash hook-point (append hooks (list entry)) e-unit--hooks)))

(defun e-unit-remove-hook (hook-point fn)
  "Remove FN from HOOK-POINT."
  (let ((hooks (gethash hook-point e-unit--hooks)))
    (puthash hook-point
             (cl-remove-if (lambda (entry) (eq (car entry) fn)) hooks)
             e-unit--hooks)))

(defun e-unit-list-hooks (hook-point)
  "List all hook functions registered at HOOK-POINT."
  (mapcar #'car (gethash hook-point e-unit--hooks)))

;;; Hook Execution

(defun e-unit--context-matches-p (hook-context current-context)
  "Check if HOOK-CONTEXT matches CURRENT-CONTEXT.
A hook context matches if the current context extends or equals
the hook context.
Example: hook registered with (\"file:test.el\") matches current
context (\"describe:User\" \"file:test.el\") because current extends
hook's context."
  (let ((hook-ctx-reversed (reverse hook-context))
        (curr-ctx-reversed (reverse current-context)))
    ;; Current context must contain all elements of hook context in same order
    ;; We compare from the end (most general to most specific)
    (catch 'mismatch
      (while hook-ctx-reversed
        (unless (and curr-ctx-reversed
                     (equal (car hook-ctx-reversed) (car curr-ctx-reversed)))
          (throw 'mismatch nil))
        (setq hook-ctx-reversed (cdr hook-ctx-reversed))
        (setq curr-ctx-reversed (cdr curr-ctx-reversed)))
      t)))

(defun e-unit--execute-hooks (hook-point context)
  "Execute all hooks at HOOK-POINT with CONTEXT plist.
Only executes hooks whose registration context matches current
context stack.  Hooks execute in FIFO order.  Errors are captured
and added to context."
  (let ((hooks (gethash hook-point e-unit--hooks))
        (current-context (e-unit-get-current-context)))
    (cl-block execute-hooks
      (dolist (entry hooks)
        (let ((hook-fn (car entry))
              (hook-context (cdr entry)))
          ;; Only execute if context matches
          (when (e-unit--context-matches-p hook-context current-context)
            (condition-case err
                (funcall hook-fn context)
              (error
               ;; Capture error in context and stop execution
               (plist-put context :hook-error (error-message-string err))
               ;; Return early - don't execute remaining hooks after error
               (cl-return-from execute-hooks nil)))))))))

(defun e-unit--execute-around-hooks (hook-point context body-fn)
  "Execute around hooks at HOOK-POINT with CONTEXT plist and BODY-FN.
Around hooks receive a proceed continuation and context.  They can
choose whether to call proceed.  Hooks nest in FIFO order (first
registered is outermost).  Errors are captured and prevent proceed
from being called."
  (let ((hooks (gethash hook-point e-unit--hooks))
        (current-context (e-unit-get-current-context))
        (matching-hooks nil))
    ;; Filter hooks that match current context
    (dolist (entry hooks)
      (let ((hook-fn (car entry))
            (hook-context (cdr entry)))
        (when (e-unit--context-matches-p hook-context current-context)
          (push hook-fn matching-hooks))))
    ;; Reverse to get FIFO order (we pushed, so it's LIFO)
    (setq matching-hooks (reverse matching-hooks))
    ;; Build nested continuation
    ;; Note: hooks call (funcall proceed context) but we ignore the arg since
    ;; context is already in the closure
    (let ((proceed (lambda (&rest _args) (funcall body-fn))))
      (dolist (hook-fn (reverse matching-hooks))
        (let ((current-proceed proceed))
          (setq proceed
                (lambda (&rest _args)
                  (condition-case err
                      (funcall hook-fn current-proceed context)
                    (error
                     ;; Capture error in context and don't call proceed
                     (plist-put context :hook-error (error-message-string err))))))))
      ;; Execute the outermost hook (or body if no hooks)
      (funcall proceed))))

;;; Test Metadata Storage

(defvar e-unit--test-metadata (make-hash-table :test 'eq)
  "Metadata storage for tests.
Structure: {test-name => plist}
Example: {'my-test => (:timeout 5.0 :tags (:slow) :skip nil)}")

(defun e-unit-set-test-metadata (test-name key value)
  "Set metadata KEY to VALUE for TEST-NAME.
TEST-NAME should be a symbol (the test function name).
KEY should be a keyword (e.g., :timeout, :tags).
VALUE can be any Lisp value.

Reserved keys:
  :timeout - Max execution time (float, seconds)
  :skip - Skip test (t or reason string)
  :pending - Mark as pending/TODO
  :focus - Run only focused tests
  :tags - List of tag symbols

Plugins can use namespaced keys (e.g., :mock/auto-cleanup)."
  (let ((metadata (gethash test-name e-unit--test-metadata)))
    (unless metadata
      (setq metadata nil))
    (setq metadata (plist-put metadata key value))
    (puthash test-name metadata e-unit--test-metadata)))

(defun e-unit-get-test-metadata (test-name &optional key)
  "Get metadata for TEST-NAME.
If KEY is provided, returns the value for that specific key.
If KEY is nil, returns the entire metadata plist.
Returns nil if test has no metadata or key doesn't exist."
  (let ((metadata (gethash test-name e-unit--test-metadata)))
    (if key
        (plist-get metadata key)
      metadata)))

(defun e-unit-delete-test-metadata (test-name key)
  "Delete metadata KEY from TEST-NAME.
If the test or key doesn't exist, this is a no-op.
Does not delete the entire test metadata, only the specific key."
  (let ((metadata (gethash test-name e-unit--test-metadata)))
    (when metadata
      ;; Remove the key from the plist
      (let ((new-metadata nil)
            (keys-vals metadata))
        (while keys-vals
          (let ((k (car keys-vals))
                (v (cadr keys-vals)))
            (unless (eq k key)
              (setq new-metadata (plist-put new-metadata k v)))
            (setq keys-vals (cddr keys-vals))))
        (puthash test-name new-metadata e-unit--test-metadata)))))

;;; Context Object

(defvar e-unit--current-context nil
  "Context plist for currently executing test.
This is dynamically bound during test execution and contains:
  :test-name - Symbol of the current test
  :test-metadata - Plist of test metadata
  :context-stack - List of current context strings
  :file - String path to the test file
  :start-time - Time when test started
  :duration - Float seconds (set after test completes)
  :status - Symbol: \\='pass, \\='fail, \\='error, \\='skip
  :error - String error message if failed

Plugins can add namespaced keys (e.g., :mock/stubs, :db/connection).")

(defun e-unit--create-test-context (test-name)
  "Create fresh context plist for TEST-NAME.
Returns a new plist containing:
  :test-name - TEST-NAME
  :test-metadata - Metadata plist from `e-unit-get-test-metadata'
  :context-stack - Copy of current context stack
  :file - Current test file from `e-unit--current-file'
  :start-time - Current time

The context object flows through hooks and is available to tests."
  (list :test-name test-name
        :test-metadata (e-unit-get-test-metadata test-name)
        :context-stack (e-unit-get-current-context)
        :file e-unit--current-file
        :start-time (current-time)))

;;; Core test definition

(defmacro e-unit-deftest (name params &rest body)
  "Define a test named NAME with PARAMS and BODY.
If PARAMS is empty (), creates a regular test.
If PARAMS is (context), the test receives a context object as parameter.
If PARAMS has other parameters, creates a parameterized test function.

BODY can contain:
  - Optional docstring (first element if string)
  - Metadata keywords (:timeout, :tags, :skip, or custom :namespace/key)
  - Test code with assertions

Examples:
  (e-unit-deftest my-test ()
    \"Simple test\"
    (assert-equal 1 1))

  (e-unit-deftest my-test ()
    \"Test with metadata\"
    :timeout 5
    :tags (slow integration)
    (assert-true t))

  (e-unit-deftest my-test (context)
    \"Test with context injection\"
    :timeout 3
    (assert-true (plist-get context :test-name)))"
  (declare (indent 2))

  ;; Parse body to extract docstring, metadata, and test code
  (let ((docstring nil)
        (metadata nil)
        (test-body nil)
        (remaining-body body))

    ;; Extract optional docstring
    (when (and remaining-body (stringp (car remaining-body)))
      (setq docstring (car remaining-body))
      (setq remaining-body (cdr remaining-body)))

    ;; Extract metadata (keyword-value pairs)
    (while (and remaining-body (keywordp (car remaining-body)))
      (let ((key (car remaining-body))
            (value (cadr remaining-body)))
        (setq metadata (plist-put metadata key value))
        (setq remaining-body (cddr remaining-body))))

    ;; Remaining is test body
    (setq test-body remaining-body)

    ;; Check if this is a context-injecting test
    (let ((has-context-param (and (equal (length params) 1)
                                   (eq (car params) 'context))))

      (cond
       ;; Regular test without parameters or context injection test
       ((or (null params) has-context-param)
        `(progn
           ;; Store metadata if any
           ,@(when metadata
               (let ((metadata-forms nil))
                 (while metadata
                   (let ((key (car metadata))
                         (value (cadr metadata)))
                     (push `(e-unit-set-test-metadata ',name ,key ',value) metadata-forms)
                     (setq metadata (cddr metadata))))
                 (reverse metadata-forms)))

           ;; Define the test function
           ,(if has-context-param
                ;; Context-injecting test
                `(defun ,name ()
                   ,@(when docstring (list docstring))
                   (let ((e-unit--current-context (e-unit--create-test-context ',name)))
                     (funcall (lambda (context) ,@test-body) e-unit--current-context)))
              ;; Regular test
              `(defun ,name ()
                 ,@(when docstring (list docstring))
                 (let ((e-unit--current-context (e-unit--create-test-context ',name)))
                   ,@test-body)))

           ;; Register the test with source location
           (e-unit--register-test ',name ,(or docstring "") ,(line-number-at-pos))))

       ;; Parameterized test with parameters
       (t
        `(progn
           ;; Store metadata if any
           ,@(when metadata
               (let ((metadata-forms nil))
                 (while metadata
                   (let ((key (car metadata))
                         (value (cadr metadata)))
                     (push `(e-unit-set-test-metadata ',name ,key ',value) metadata-forms)
                     (setq metadata (cddr metadata))))
                 (reverse metadata-forms)))

           ;; Define parameterized test function
           (defun ,name ,params
             ,@(when docstring (list docstring))
             ,@test-body)))))))

(defun e-unit--register-test (name docstring &optional line)
  "Register test NAME with DOCSTRING in the test registry.
LINE is the source line number where the test was defined.
Captures the current context stack and runs registration hooks."
  (let* ((current-file (or load-file-name buffer-file-name "unknown-file"))
         (info (list :name name
                     :docstring docstring
                     :file current-file
                     :line (or line 1)
                     :context (copy-sequence e-unit--context-stack))))

    (catch 'e-unit-skip-registration
      ;; Run before-hooks: extensions can modify info or skip registration
      (run-hook-with-args 'e-unit-register-test-hook info)

      ;; Remove any existing test with same name from the same file
      (setq e-unit--tests (cl-remove-if (lambda (test)
                                          (and (eq (plist-get test :name) name)
                                               (equal (plist-get test :file) current-file)))
                                        e-unit--tests))

      ;; Add the new test (allow same names in different files)
      (push info e-unit--tests)

      ;; Run after-hooks: extensions can add metadata
      (run-hook-with-args 'e-unit-after-register-test-hook name info))))

;;; File-scoped hook management

(defun e-unit--get-current-file ()
  "Get the current file for hook registration."
  (or load-file-name buffer-file-name "unknown-file"))

(defun e-unit--add-file-hook (hook-type hook-fn)
  "Add HOOK-FN of HOOK-TYPE to the current file's hooks."
  (let* ((file (e-unit--get-current-file))
         (file-entry (assoc file e-unit--file-hooks))
         (hooks-plist (cdr file-entry))
         (current-hooks (plist-get hooks-plist hook-type)))

    ;; Add the new hook function
    (setq current-hooks (cons hook-fn current-hooks))

    ;; Update the hooks plist
    (setq hooks-plist (plist-put hooks-plist hook-type current-hooks))

    ;; Update or create the file entry
    (if file-entry
        (setcdr file-entry hooks-plist)
      (push (cons file hooks-plist) e-unit--file-hooks))))

(defun e-unit--get-file-hooks (file hook-type)
  "Get hooks of HOOK-TYPE for FILE."
  (let ((file-entry (assoc file e-unit--file-hooks)))
    (when file-entry
      (plist-get (cdr file-entry) hook-type))))

;;; Convenience Macros for Common Hook Points

(defmacro e-unit-setup-each (&rest body)
  "Register a :before-each hook with BODY.
Executes before each test in the current context."
  `(e-unit-add-hook :before-each (lambda (context) ,@body)))

(defmacro e-unit-teardown-each (&rest body)
  "Register an :after-each hook with BODY.
Executes after each test in the current context."
  `(e-unit-add-hook :after-each (lambda (context) ,@body)))

(defmacro e-unit-setup-file (&rest body)
  "Register a :before-file hook with BODY.
Executes once before all tests in current file."
  `(e-unit-add-hook :before-file (lambda (context) ,@body)))

(defmacro e-unit-teardown-file (&rest body)
  "Register an :after-file hook with BODY.
Executes once after all tests in current file."
  `(e-unit-add-hook :after-file (lambda (context) ,@body)))

(defmacro e-unit-setup-suite (&rest body)
  "Register a :before-suite hook with BODY.
Executes once before entire test suite."
  `(progn
     (e-unit-add-hook :before-suite (lambda (context) ,@body))
     (add-to-list 'e-unit--setup-suite-functions (lambda () ,@body))))

(defmacro e-unit-teardown-suite (&rest body)
  "Register an :after-suite hook with BODY.
Executes once after entire test suite."
  `(progn
     (e-unit-add-hook :after-suite (lambda (context) ,@body))
     (add-to-list 'e-unit--teardown-suite-functions (lambda () ,@body))))

(defmacro e-unit-around-each (args &rest body)
  "Register an :around-each hook with BODY.
ARGS should be (proceed context).
BODY must call (funcall proceed) to run the test."
  (let ((proceed (car args))
        (context (cadr args)))
    `(e-unit-add-hook :around-each (lambda (,proceed ,context) ,@body))))

(defmacro e-unit-around-file (args &rest body)
  "Register an :around-file hook with BODY.
ARGS should be (proceed context).
BODY must call (funcall proceed) to run file tests."
  (let ((proceed (car args))
        (context (cadr args)))
    `(e-unit-add-hook :around-file (lambda (,proceed ,context) ,@body))))

(defmacro e-unit-around-suite (args &rest body)
  "Register an :around-suite hook with BODY.
ARGS should be (proceed context).
BODY must call (funcall proceed) to run suite."
  (let ((proceed (car args))
        (context (cadr args)))
    `(e-unit-add-hook :around-suite (lambda (,proceed ,context) ,@body))))

;;; Emacs 29+ compatibility for positioned symbols
;;
;; These functions provide fallbacks for Emacs 28 where position-tracking
;; reader functions don't exist. On Emacs 28, assertion position scanning
;; gracefully degrades - assertions still work, just without column info.

(defun e-unit--compat-read-positioning-symbols (stream)
  "Read from STREAM, capturing symbol positions if available.
Uses `read-positioning-symbols' on Emacs 29+, falls back to `read' on Emacs 28."
  (if (fboundp 'read-positioning-symbols)
      (read-positioning-symbols stream)
    (read stream)))

(defun e-unit--compat-symbol-with-pos-p (obj)
  "Return non-nil if OBJ is a symbol with position info.
Uses `symbol-with-pos-p' on Emacs 29+, returns nil on Emacs 28."
  (and (fboundp 'symbol-with-pos-p)
       (symbol-with-pos-p obj)))

(defun e-unit--compat-bare-symbol (sym)
  "Return the bare symbol from SYM, stripping position info if present.
Uses `bare-symbol' on Emacs 29+, returns SYM unchanged on Emacs 28."
  (if (fboundp 'bare-symbol)
      (bare-symbol sym)
    sym))

(defun e-unit--compat-symbol-with-pos-pos (sym)
  "Return the position from SYM if it has position info.
Uses `symbol-with-pos-pos' on Emacs 29+, returns nil on Emacs 28."
  (and (fboundp 'symbol-with-pos-pos)
       (symbol-with-pos-pos sym)))

;;; Assertion position scanning
;;
;; Uses Emacs's `read-positioning-symbols' to capture exact source locations
;; of assertion macros. This allows precise file:line:column error reporting.
;; On Emacs 28, this gracefully degrades - assertions work without column info.

(defconst e-unit--assertion-macro-names
  '(assert-equal assert-true assert-nil assert-not-equal assert-same)
  "List of assertion macro names that support position capture.
These macros will have their source positions pre-scanned.")

(defun e-unit--scan-assertion-positions (file)
  "Scan FILE for assertion macro positions.
Populates `e-unit--assertion-position-queue' with (file line column) entries
in the order they appear in the file."
  (setq e-unit--assertion-position-queue nil)
  (setq e-unit--scanning-file file)
  (when (and file (file-readable-p file))
    (with-temp-buffer
      (insert-file-contents file)
      ;; Build position map: buffer-position -> (line . column)
      (let ((position-map (make-hash-table)))
        (goto-char (point-min))
        (while (< (point) (point-max))
          (puthash (point)
                   (cons (line-number-at-pos) (current-column))
                   position-map)
          (forward-char 1))
        ;; Read forms with position info and find assertions
        (goto-char (point-min))
        (condition-case nil
            (while t
              (let ((form (e-unit--compat-read-positioning-symbols (current-buffer))))
                (e-unit--collect-assertion-positions form position-map file)))
          (end-of-file nil))
        ;; Queue was built in reverse order, so reverse it
        (setq e-unit--assertion-position-queue
              (nreverse e-unit--assertion-position-queue))))))

(defun e-unit--collect-assertion-positions (form position-map file)
  "Recursively collect assertion positions from FORM.
POSITION-MAP maps buffer positions to (line . column).
FILE is the source file path.
Pushes found positions directly to `e-unit--assertion-position-queue'."
  (cond
   ;; Symbol with position - check if it's an assertion
   ((e-unit--compat-symbol-with-pos-p form)
    (when (memq (e-unit--compat-bare-symbol form) e-unit--assertion-macro-names)
      (let* ((pos (e-unit--compat-symbol-with-pos-pos form))
             (info (gethash pos position-map)))
        (when info
          (push (list file (car info) (cdr info))
                e-unit--assertion-position-queue)))))
   ;; Cons cell - recurse into car and cdr
   ((consp form)
    (e-unit--collect-assertion-positions (car form) position-map file)
    (e-unit--collect-assertion-positions (cdr form) position-map file))))

(defun e-unit--get-scanned-position ()
  "Get the next scanned assertion position, or nil if unavailable.
Returns (file line column) or nil."
  (when (and e-unit--scanning-file
             e-unit--assertion-position-queue
             (equal e-unit--scanning-file (or load-file-name buffer-file-name)))
    (pop e-unit--assertion-position-queue)))

;;; Core assertions

(define-error 'e-unit-assertion-error "E-Unit assertion failed")

(defun e-unit--signal-assertion-error (message &optional file line column)
  "Signal an assertion error with MESSAGE and optional location info.
FILE, LINE, and COLUMN specify where the assertion was written."
  (signal 'e-unit-assertion-error
          (list :message message
                :file file
                :line line
                :column column)))

(defun e-unit-assert-equal--impl (expected actual file line column)
  "Implementation of assert-equal with location info."
  (unless (equal expected actual)
    (e-unit--signal-assertion-error
     (format "Expected: %S\nActual: %S" expected actual)
     file line column)))

(defmacro e-unit-assert-equal (expected actual)
  "Assert that EXPECTED equals ACTUAL."
  (let* ((scanned (e-unit--get-scanned-position))
         (file (if scanned (nth 0 scanned) (or load-file-name buffer-file-name)))
         (line (if scanned (nth 1 scanned) (line-number-at-pos)))
         (column (if scanned (nth 2 scanned) (current-column))))
    `(e-unit-assert-equal--impl ,expected ,actual ,file ,line ,column)))

(defun e-unit-assert-true--impl (value file line column)
  "Implementation of assert-true with location info."
  (unless value
    (e-unit--signal-assertion-error
     (format "Expected: non-nil\nActual: %S" value)
     file line column)))

(defmacro e-unit-assert-true (value)
  "Assert that VALUE is non-nil."
  (let* ((scanned (e-unit--get-scanned-position))
         (file (if scanned (nth 0 scanned) (or load-file-name buffer-file-name)))
         (line (if scanned (nth 1 scanned) (line-number-at-pos)))
         (column (if scanned (nth 2 scanned) (current-column))))
    `(e-unit-assert-true--impl ,value ,file ,line ,column)))

(defun e-unit-assert-nil--impl (value file line column)
  "Implementation of assert-nil with location info."
  (when value
    (e-unit--signal-assertion-error
     (format "Expected: nil\nActual: %S" value)
     file line column)))

(defmacro e-unit-assert-nil (value)
  "Assert that VALUE is nil."
  (let* ((scanned (e-unit--get-scanned-position))
         (file (if scanned (nth 0 scanned) (or load-file-name buffer-file-name)))
         (line (if scanned (nth 1 scanned) (line-number-at-pos)))
         (column (if scanned (nth 2 scanned) (current-column))))
    `(e-unit-assert-nil--impl ,value ,file ,line ,column)))

(defun e-unit-assert-not-equal--impl (expected actual file line column)
  "Implementation of assert-not-equal with location info."
  (when (equal expected actual)
    (e-unit--signal-assertion-error
     (format "Expected: not %S\nActual: %S" expected actual)
     file line column)))

(defmacro e-unit-assert-not-equal (expected actual)
  "Assert that EXPECTED does not equal ACTUAL."
  (let* ((scanned (e-unit--get-scanned-position))
         (file (if scanned (nth 0 scanned) (or load-file-name buffer-file-name)))
         (line (if scanned (nth 1 scanned) (line-number-at-pos)))
         (column (if scanned (nth 2 scanned) (current-column))))
    `(e-unit-assert-not-equal--impl ,expected ,actual ,file ,line ,column)))

(defun e-unit-assert-same--impl (expected actual file line column)
  "Implementation of assert-same with location info."
  (unless (eq expected actual)
    (e-unit--signal-assertion-error
     (format "Expected same object: %S\nActual: %S" expected actual)
     file line column)))

(defmacro e-unit-assert-same (expected actual)
  "Assert that EXPECTED and ACTUAL are the same object (eq)."
  (let* ((scanned (e-unit--get-scanned-position))
         (file (if scanned (nth 0 scanned) (or load-file-name buffer-file-name)))
         (line (if scanned (nth 1 scanned) (line-number-at-pos)))
         (column (if scanned (nth 2 scanned) (current-column))))
    `(e-unit-assert-same--impl ,expected ,actual ,file ,line ,column)))

(defun e-unit-assert-not-same (expected actual)
  "Assert that EXPECTED and ACTUAL are not the same object (not eq)."
  (when (eq expected actual)
    (signal 'e-unit-assertion-error
            (format "Expected: not same object as %S\nActual: %S" expected actual))))

(defun e-unit-refute-nil (value)
  "Assert that VALUE is not nil."
  (unless value
    (signal 'e-unit-assertion-error
            (format "Expected: non-nil\nActual: nil"))))

(defun e-unit-assert-false (value)
  "Assert that VALUE is nil (false in Lisp)."
  (when value
    (signal 'e-unit-assertion-error
            (format "Expected: nil (false)\nActual: %S" value))))

;; Approximate assertions

(defun e-unit-assert-in-delta (expected actual delta)
  "Assert that EXPECTED and ACTUAL differ by at most DELTA.
Delta comparison: |EXPECTED - ACTUAL| <= DELTA."
  (unless (numberp expected)
    (signal 'e-unit-assertion-error
            (format "Expected must be a number, got: %S" expected)))
  (unless (numberp actual)
    (signal 'e-unit-assertion-error
            (format "Actual must be a number, got: %S" actual)))
  (unless (numberp delta)
    (signal 'e-unit-assertion-error
            (format "Delta must be a number, got: %S" delta)))
  (unless (>= delta 0)
    (signal 'e-unit-assertion-error
            (format "Delta must be non-negative, got: %S" delta)))
  (let ((diff (abs (- expected actual))))
    (unless (<= diff delta)
      (signal 'e-unit-assertion-error
              (format "Expected %S ± %S\nActual: %S\nDifference: %S"
                      expected delta actual diff)))))

(defun e-unit-assert-in-epsilon (expected actual epsilon)
  "Assert that the relative error between EXPECTED and ACTUAL is within EPSILON.
Epsilon is a relative tolerance, typically between 0 and 1.
Special case: when EXPECTED = 0, uses absolute comparison |ACTUAL| <= EPSILON."
  (unless (numberp expected)
    (signal 'e-unit-assertion-error
            (format "Expected must be a number, got: %S" expected)))
  (unless (numberp actual)
    (signal 'e-unit-assertion-error
            (format "Actual must be a number, got: %S" actual)))
  (unless (numberp epsilon)
    (signal 'e-unit-assertion-error
            (format "Epsilon must be a number, got: %S" epsilon)))
  (unless (>= epsilon 0)
    (signal 'e-unit-assertion-error
            (format "Epsilon must be non-negative, got: %S" epsilon)))
  (if (= expected 0)
      ;; Special case: if expected is 0, use absolute difference
      (let ((diff (abs actual)))
        (unless (<= diff epsilon)
          (signal 'e-unit-assertion-error
                  (format "Expected: 0 (within relative epsilon %S)\nActual: %S\nAbsolute difference: %S"
                          epsilon actual diff))))
    ;; Normal case: relative error
    (let ((relative-error (/ (abs (- expected actual)) (abs expected))))
      (unless (<= relative-error epsilon)
        (signal 'e-unit-assertion-error
                (format "Expected: %S (within relative epsilon %S)\nActual: %S\nRelative error: %S"
                        expected epsilon actual relative-error))))))

(defun e-unit-refute-in-delta (expected actual delta)
  "Assert that EXPECTED and ACTUAL differ by MORE than DELTA.
Delta comparison: |EXPECTED - ACTUAL| > DELTA."
  (unless (numberp expected)
    (signal 'e-unit-assertion-error
            (format "Expected must be a number, got: %S" expected)))
  (unless (numberp actual)
    (signal 'e-unit-assertion-error
            (format "Actual must be a number, got: %S" actual)))
  (unless (numberp delta)
    (signal 'e-unit-assertion-error
            (format "Delta must be a number, got: %S" delta)))
  (unless (>= delta 0)
    (signal 'e-unit-assertion-error
            (format "Delta must be non-negative, got: %S" delta)))
  (let ((diff (abs (- expected actual))))
    (when (<= diff delta)
      (signal 'e-unit-assertion-error
              (format "Expected difference > %S\nActual difference: %S\nBetween %S and %S"
                      delta diff expected actual)))))

(defun e-unit-refute-in-epsilon (expected actual epsilon)
  "Assert relative error between EXPECTED and ACTUAL NOT within EPSILON.
Special case: when EXPECTED = 0, use absolute comparison
|ACTUAL| > EPSILON."
  (unless (numberp expected)
    (signal 'e-unit-assertion-error
            (format "Expected must be a number, got: %S" expected)))
  (unless (numberp actual)
    (signal 'e-unit-assertion-error
            (format "Actual must be a number, got: %S" actual)))
  (unless (numberp epsilon)
    (signal 'e-unit-assertion-error
            (format "Epsilon must be a number, got: %S" epsilon)))
  (unless (>= epsilon 0)
    (signal 'e-unit-assertion-error
            (format "Epsilon must be non-negative, got: %S" epsilon)))
  (if (= expected 0)
      ;; Special case: if expected is 0, use absolute difference
      (let ((diff (abs actual)))
        (when (<= diff epsilon)
          (signal 'e-unit-assertion-error
                  (format "Expected: NOT 0 (within relative epsilon %S)\nActual: %S\nAbsolute difference: %S (should be > %S)"
                          epsilon actual diff epsilon))))
    ;; Normal case: relative error
    (let ((relative-error (/ (abs (- expected actual)) (abs expected))))
      (when (<= relative-error epsilon)
        (signal 'e-unit-assertion-error
                (format "Expected: NOT %S (within relative epsilon %S)\nActual: %S\nRelative error: %S (should be > %S)"
                        expected epsilon actual relative-error epsilon))))))

;;; Property-aware string assertion helpers

(defun e-unit--string-has-properties-p (str)
  "Return non-nil if STR has any text properties."
  (let ((len (length str))
        (pos 0)
        (has-props nil))
    (while (and (< pos len) (not has-props))
      (when (text-properties-at pos str)
        (setq has-props t))
      (setq pos (1+ pos)))
    has-props))

(defun e-unit--string-for-display (value)
  "Format VALUE for error messages.
If VALUE is a propertized string, strip properties and add hint."
  (if (stringp value)
      (if (e-unit--string-has-properties-p value)
          (format "%S [has text properties]" (substring-no-properties value))
        (format "%S" value))
    (format "%S" value)))

(defun e-unit--properties-at-match (string position)
  "Return plist of text properties at POSITION in STRING."
  (text-properties-at position string))

(defun e-unit--check-properties (actual-props property-specs)
  "Check ACTUAL-PROPS against PROPERTY-SPECS.
PROPERTY-SPECS is a plist that may contain:
  - :has-properties (list) - properties that must exist (any value)
  - Other keywords - specific property values to check

Returns (ok mismatches missing) where:
  - ok is t if all checks pass
  - mismatches is alist of (prop expected actual)
  - missing is list of properties from :has-properties not found"
  (let ((mismatches nil)
        (missing nil)
        (has-properties (plist-get property-specs :has-properties))
        (specs-without-has (copy-sequence property-specs)))
    ;; Remove :has-properties from specs for value checking
    (cl-remf specs-without-has :has-properties)
    ;; Check :has-properties
    (when has-properties
      (dolist (prop has-properties)
        (unless (plist-member actual-props prop)
          (push prop missing))))
    ;; Check specific values
    (let ((spec specs-without-has))
      (while spec
        (let* ((prop (car spec))
               (expected (cadr spec))
               (prop-name (intern (substring (symbol-name prop) 1)))  ; :face -> face
               (actual (plist-get actual-props prop-name)))
          (unless (equal expected actual)
            (push (list prop-name expected actual) mismatches)))
        (setq spec (cddr spec))))
    (list (and (null mismatches) (null missing))
          (nreverse mismatches)
          (nreverse missing))))

;; Collection assertions (using cl-defgeneric for polymorphism)

(cl-defgeneric e-unit-assert-includes (collection _item)
  "Assert that COLLECTION includes ITEM."
  (signal 'e-unit-assertion-error
          (format "assert-includes not implemented for type: %S" (type-of collection))))

(cl-defmethod e-unit-assert-includes ((collection string) item)
  "Assert that string COLLECTION includes ITEM."
  (unless (stringp item)
    (signal 'e-unit-assertion-error
            (format "When searching in string, item must be a string, got: %S" item)))
  (let ((case-fold-search nil))
    (unless (string-match-p (regexp-quote item) collection)
      (signal 'e-unit-assertion-error
              (format "Expected string to include: %S\nString: %s" item (e-unit--string-for-display collection))))))

(cl-defmethod e-unit-assert-includes ((collection list) item)
  "Assert that list COLLECTION includes ITEM."
  (unless (member item collection)
    (signal 'e-unit-assertion-error
            (format "Expected collection to include: %S\nCollection: %S" item collection))))

(cl-defmethod e-unit-assert-includes ((collection array) item)
  "Assert that array COLLECTION includes ITEM."
  ;; Need to check if it's a string first, since strings are also arrays
  (if (stringp collection)
      (e-unit-assert-includes collection item)  ; Dispatch to string method
    (let ((found nil)
          (i 0))
      (while (and (< i (length collection)) (not found))
        (when (equal (aref collection i) item)
          (setq found t))
        (setq i (1+ i)))
      (unless found
        (signal 'e-unit-assertion-error
                (format "Expected array to include: %S\nArray: %S" item collection))))))

(cl-defgeneric e-unit-refute-includes (collection _item)
  "Assert that COLLECTION does not include ITEM."
  (signal 'e-unit-assertion-error
          (format "refute-includes not implemented for type: %S" (type-of collection))))

(cl-defmethod e-unit-refute-includes ((collection string) item)
  "Assert that string COLLECTION does not include ITEM."
  (unless (stringp item)
    (signal 'e-unit-assertion-error
            (format "When searching in string, item must be a string, got: %S" item)))
  (let ((case-fold-search nil))
    (when (string-match-p (regexp-quote item) collection)
      (signal 'e-unit-assertion-error
              (format "Expected string NOT to include: %S\nString: %s" item (e-unit--string-for-display collection))))))

(cl-defmethod e-unit-refute-includes ((collection list) item)
  "Assert that list COLLECTION does not include ITEM."
  (when (member item collection)
    (signal 'e-unit-assertion-error
            (format "Expected collection NOT to include: %S\nCollection: %S" item collection))))

(cl-defmethod e-unit-refute-includes ((collection array) item)
  "Assert that array COLLECTION does not include ITEM."
  ;; Need to check if it's a string first, since strings are also arrays
  (if (stringp collection)
      (e-unit-refute-includes collection item)  ; Dispatch to string method
    (let ((found nil)
          (i 0))
      (while (and (< i (length collection)) (not found))
        (when (equal (aref collection i) item)
          (setq found t))
        (setq i (1+ i)))
      (when found
        (signal 'e-unit-assertion-error
                (format "Expected array NOT to include: %S\nArray: %S" item collection))))))

(cl-defgeneric e-unit-assert-empty (collection)
  "Assert that COLLECTION is empty."
  (signal 'e-unit-assertion-error
          (format "assert-empty not implemented for type: %S" (type-of collection))))

(cl-defmethod e-unit-assert-empty ((collection string))
  "Assert that string COLLECTION is empty."
  (unless (= (length collection) 0)
    (signal 'e-unit-assertion-error
            (format "Expected empty string\nActual: %S (length: %d)" collection (length collection)))))

(cl-defmethod e-unit-assert-empty ((collection list))
  "Assert that list COLLECTION is empty."
  (when collection
    (signal 'e-unit-assertion-error
            (format "Expected empty list\nActual: %S (length: %d)" collection (length collection)))))

(cl-defmethod e-unit-assert-empty ((collection array))
  "Assert that array COLLECTION is empty."
  (if (stringp collection)
      (e-unit-assert-empty collection)  ; Dispatch to string method
    (unless (= (length collection) 0)
      (signal 'e-unit-assertion-error
              (format "Expected empty array\nActual: %S (length: %d)" collection (length collection))))))

(cl-defgeneric e-unit-refute-empty (collection)
  "Assert that COLLECTION is not empty."
  (signal 'e-unit-assertion-error
          (format "refute-empty not implemented for type: %S" (type-of collection))))

(cl-defmethod e-unit-refute-empty ((collection string))
  "Assert that string COLLECTION is not empty."
  (when (= (length collection) 0)
    (signal 'e-unit-assertion-error
            "Expected non-empty string\nActual: empty string")))

(cl-defmethod e-unit-refute-empty ((collection list))
  "Assert that list COLLECTION is not empty."
  (unless collection
    (signal 'e-unit-assertion-error
            "Expected non-empty list\nActual: empty list")))

(cl-defmethod e-unit-refute-empty ((collection array))
  "Assert that array COLLECTION is not empty."
  (if (stringp collection)
      (e-unit-refute-empty collection)  ; Dispatch to string method
    (when (= (length collection) 0)
      (signal 'e-unit-assertion-error
              "Expected non-empty array\nActual: empty array"))))

(cl-defgeneric e-unit-assert-length (collection _expected-length)
  "Assert that COLLECTION has EXPECTED-LENGTH."
  (signal 'e-unit-assertion-error
          (format "assert-length not implemented for type: %S" (type-of collection))))

(cl-defmethod e-unit-assert-length ((collection sequence) expected-length)
  "Assert that sequence COLLECTION has EXPECTED-LENGTH."
  (unless (numberp expected-length)
    (signal 'e-unit-assertion-error
            (format "Expected length must be a number, got: %S" expected-length)))
  (unless (>= expected-length 0)
    (signal 'e-unit-assertion-error
            (format "Expected length must be non-negative, got: %S" expected-length)))
  (let ((actual-length (length collection)))
    (unless (= actual-length expected-length)
      (signal 'e-unit-assertion-error
              (format "Expected length: %d\nActual length: %d\nCollection: %S"
                      expected-length actual-length collection)))))

;; Type/predicate assertions

(defun e-unit-assert-instance-of (expected-type object)
  "Assert that OBJECT is an instance of EXPECTED-TYPE."
  (cond
   ;; Built-in type checks
   ((eq expected-type 'string)
    (unless (stringp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: string\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'number)
    (unless (numberp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: number\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'integer)
    (unless (integerp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: integer\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'float)
    (unless (floatp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: float\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'symbol)
    (unless (symbolp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: symbol\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'list)
    (unless (listp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: list\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'cons)
    (unless (consp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: cons\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'array)
    (unless (arrayp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: array\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'vector)
    (unless (vectorp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: vector\nActual: %S (type: %s)" object (type-of object)))))
   ((eq expected-type 'function)
    (unless (functionp object)
      (signal 'e-unit-assertion-error
              (format "Expected instance of: function\nActual: %S (type: %s)" object (type-of object)))))
   ;; Use type-of for other types
   (t
    (let ((actual-type (type-of object)))
      (unless (eq actual-type expected-type)
        (signal 'e-unit-assertion-error
                (format "Expected instance of: %s\nActual: %S (type: %s)" expected-type object actual-type)))))))

(defun e-unit-assert-kind-of (expected-type object)
  "Assert that OBJECT is a kind of EXPECTED-TYPE (supports inheritance)."
  ;; For now, this is the same as assert-instance-of since Emacs Lisp doesn't have
  ;; a traditional class hierarchy. This can be extended later for custom types.
  (e-unit-assert-instance-of expected-type object))

(defun e-unit-assert-responds-to (object method)
  "Assert that OBJECT responds to METHOD (has the function/method defined)."
  (cond
   ;; For symbols, check if the method is a bound function
   ((symbolp object)
    (unless (fboundp method)
      (signal 'e-unit-assertion-error
              (format "Expected %S to respond to method: %S\nMethod is not defined" object method))))
   ;; For other objects, this is more complex in Emacs Lisp
   ;; We could check for specific known method patterns
   (t
    ;; For now, just check if the method exists as a function
    (unless (fboundp method)
      (signal 'e-unit-assertion-error
              (format "Expected %S to respond to method: %S\nMethod is not defined" object method))))))

(defun e-unit-assert-predicate (object predicate)
  "Assert that PREDICATE return non-nil when applied to OBJECT."
  (unless (functionp predicate)
    (signal 'e-unit-assertion-error
            (format "Predicate must be a function, got: %S" predicate)))
  (let ((result (funcall predicate object)))
    (unless result
      (signal 'e-unit-assertion-error
              (format "Expected predicate %S to be true for: %S\nActual result: %S" predicate object result)))))

;; Comparison and pattern assertions

(defun e-unit-assert-operator (obj1 operator obj2)
  "Assert that (OPERATOR OBJ1 OBJ2) return non-nil."
  (unless (functionp operator)
    (signal 'e-unit-assertion-error
            (format "Operator must be a function, got: %S" operator)))
  (let ((result (funcall operator obj1 obj2)))
    (unless result
      (signal 'e-unit-assertion-error
              (format "Expected: (%S %S %S) to be true\nActual result: %S" operator obj1 obj2 result)))))

(defun e-unit-assert-match (pattern string)
  "Assert that STRING matches PATTERN (regular expression)."
  (unless (stringp string)
    (signal 'e-unit-assertion-error
            (format "String must be a string, got: %S" string)))
  (unless (stringp pattern)
    (signal 'e-unit-assertion-error
            (format "Pattern must be a string, got: %S" pattern)))
  (let ((case-fold-search nil))
    (unless (string-match-p pattern string)
      (signal 'e-unit-assertion-error
              (format "Expected string to match pattern: %S\nString: %s" pattern (e-unit--string-for-display string))))))

(defun e-unit-refute-match (pattern string)
  "Assert that STRING does NOT match PATTERN (regular expression)."
  (unless (stringp string)
    (signal 'e-unit-assertion-error
            (format "String must be a string, got: %S" string)))
  (unless (stringp pattern)
    (signal 'e-unit-assertion-error
            (format "Pattern must be a string, got: %S" pattern)))
  (let ((case-fold-search nil))
    (when (string-match-p pattern string)
      (signal 'e-unit-assertion-error
              (format "Expected string NOT to match pattern: %S\nString: %s" pattern (e-unit--string-for-display string))))))

(defun e-unit-assert-match-with-properties (pattern string &rest property-specs)
  "Assert that STRING matches PATTERN and has specified text properties.
PROPERTY-SPECS can include:
  :has-properties (list) - properties that must exist at match location
  :property value - specific property values to check (e.g., :face \\='bold)

Properties are checked at the start of the matched substring."
  (unless (stringp string)
    (signal 'e-unit-assertion-error
            (format "String must be a string, got: %S" string)))
  (unless (stringp pattern)
    (signal 'e-unit-assertion-error
            (format "Pattern must be a string, got: %S" pattern)))
  (let ((case-fold-search nil))
    (if (not (string-match pattern string))
        ;; Pattern didn't match - use basic error format
        (signal 'e-unit-assertion-error
                (format "Expected string to match pattern: %S\nString: %s"
                        pattern (e-unit--string-for-display string)))
      ;; Pattern matched - check properties at match start
      (let* ((match-start (match-beginning 0))
             (match-end (match-end 0))
             (actual-props (e-unit--properties-at-match string match-start))
             (check-result (e-unit--check-properties actual-props property-specs))
             (ok (car check-result))
             (mismatches (nth 1 check-result))
             (missing (nth 2 check-result)))
        (unless ok
          (signal 'e-unit-assertion-error
                  (e-unit--format-property-error
                   pattern match-start match-end
                   mismatches missing actual-props)))))))

(defun e-unit--format-property-error (pattern start end mismatches missing actual-props)
  "Format error message for property assertion failure."
  (let ((parts (list (format "Expected string to match pattern: %S" pattern)
                     (format "Match found at positions %d-%d" start end))))
    (when mismatches
      (push "\nProperty mismatches:" parts)
      (dolist (m mismatches)
        (push (format "  %s: expected %S, got %S" (nth 0 m) (nth 1 m) (nth 2 m)) parts)))
    (when missing
      (push (format "\nMissing properties: %S" missing) parts))
    (push (format "\nActual properties at match:\n  %S" actual-props) parts)
    (mapconcat #'identity (nreverse parts) "\n")))

(defun e-unit-refute-match-with-properties (pattern string &rest property-specs)
  "Assert that STRING does NOT match PATTERN with specified properties.
Passes if either:
  - Pattern doesn't match, OR
  - Pattern matches but properties don't match specs

PROPERTY-SPECS: see `e-unit-assert-match-with-properties'."
  (unless (stringp string)
    (signal 'e-unit-assertion-error
            (format "String must be a string, got: %S" string)))
  (unless (stringp pattern)
    (signal 'e-unit-assertion-error
            (format "Pattern must be a string, got: %S" pattern)))
  (let ((case-fold-search nil))
    (when (string-match pattern string)
      (let* ((match-start (match-beginning 0))
             (match-end (match-end 0))
             (actual-props (e-unit--properties-at-match string match-start))
             (check-result (e-unit--check-properties actual-props property-specs))
             (ok (car check-result)))
        (when ok
          ;; Both pattern and properties matched - this is a failure
          (signal 'e-unit-assertion-error
                  (format "Expected string NOT to match pattern with properties: %S\nBut match found at positions %d-%d with matching properties\n\nActual properties at match:\n  %S"
                          pattern match-start match-end actual-props)))))))

(defun e-unit-assert-includes-with-properties (string substring &rest property-specs)
  "Assert that STRING includes SUBSTRING with specified text properties.
PROPERTY-SPECS: see `e-unit-assert-match-with-properties'."
  (unless (stringp string)
    (signal 'e-unit-assertion-error
            (format "String must be a string, got: %S" string)))
  (unless (stringp substring)
    (signal 'e-unit-assertion-error
            (format "Substring must be a string, got: %S" substring)))
  (let ((case-fold-search nil)
        (pattern (regexp-quote substring)))
    (if (not (string-match pattern string))
        (signal 'e-unit-assertion-error
                (format "Expected string to include: %S\nString: %s"
                        substring (e-unit--string-for-display string)))
      (let* ((match-start (match-beginning 0))
             (match-end (match-end 0))
             (actual-props (e-unit--properties-at-match string match-start))
             (check-result (e-unit--check-properties actual-props property-specs))
             (ok (car check-result))
             (mismatches (nth 1 check-result))
             (missing (nth 2 check-result)))
        (unless ok
          (signal 'e-unit-assertion-error
                  (e-unit--format-property-error
                   substring match-start match-end
                   mismatches missing actual-props)))))))

(defun e-unit-refute-includes-with-properties (string substring &rest property-specs)
  "Assert that STRING does NOT include SUBSTRING with specified properties.
Passes if either:
  - Substring not found, OR
  - Substring found but properties don't match specs

PROPERTY-SPECS: see `e-unit-assert-match-with-properties'."
  (unless (stringp string)
    (signal 'e-unit-assertion-error
            (format "String must be a string, got: %S" string)))
  (unless (stringp substring)
    (signal 'e-unit-assertion-error
            (format "Substring must be a string, got: %S" substring)))
  (let ((case-fold-search nil)
        (pattern (regexp-quote substring)))
    (when (string-match pattern string)
      (let* ((match-start (match-beginning 0))
             (match-end (match-end 0))
             (actual-props (e-unit--properties-at-match string match-start))
             (check-result (e-unit--check-properties actual-props property-specs))
             (ok (car check-result)))
        (when ok
          (signal 'e-unit-assertion-error
                  (format "Expected string NOT to include with properties: %S\nBut found at positions %d-%d with matching properties\n\nActual properties at match:\n  %S"
                          substring match-start match-end actual-props)))))))

(defmacro e-unit-assert-raises (error-type &rest body)
  "Assert that BODY raise an error of ERROR-TYPE."
  `(let ((result
          (condition-case err
              (progn
                ,@body
                ;; If we get here, no error was raised
                'no-error)
            (error
             ;; An error was raised - check if it's the right type
             (let ((caught-type (car err)))
               (if (eq caught-type ,error-type)
                   'success
                 'wrong-type))))))
     (cond
      ((eq result 'no-error)
       (signal 'e-unit-assertion-error
               (format "Expected error of type: %S\nBut no error was raised" ,error-type)))
      ((eq result 'wrong-type)
       (signal 'e-unit-assertion-error
               (format "Expected error of type: %S\nActual error type was different" ,error-type)))
      ((eq result 'success)
       t)  ; Success!
      (t
       (signal 'e-unit-assertion-error "Unknown error in assert-raises")))))

;;; Assertion Definition DSL

(defmacro e-unit-define-assertion (name args &rest clauses)
  "Define a custom assertion named NAME with ARGS and CLAUSES.

CLAUSES:
  :test EXPR      - Expression should evaluate to non-nil for pass
  :message EXPR   - Error message string if assertion fails
  :diff EXPR      - Diff/comparison output string

Example:
  (e-unit-define-assertion assert-positive (value)
    :test (> value 0)
    :message (format \"%s should be positive\" value)
    :diff (format \"Expected: positive\\n  Actual: %s\" value))

The defined function will signal `e-unit-assertion-error' if :test
fails."
  (let ((test-expr nil)
        (message-expr nil)
        (diff-expr nil))

    ;; Parse clauses
    (while clauses
      (let ((clause (car clauses)))
        (cond
         ((eq clause :test)
          (setq clauses (cdr clauses))
          (setq test-expr (car clauses)))
         ((eq clause :message)
          (setq clauses (cdr clauses))
          (setq message-expr (car clauses)))
         ((eq clause :diff)
          (setq clauses (cdr clauses))
          (setq diff-expr (car clauses)))
         (t
          (error "Unknown clause in e-unit-define-assertion: %s" clause)))
        (setq clauses (cdr clauses))))

    ;; :test is required
    (unless test-expr
      (error "e-unit-define-assertion requires :test clause"))

    ;; Generate the assertion function
    `(defun ,name ,args
       ,(format "Custom assertion: %s" name)
       (unless ,test-expr
         (let ((msg ,(or message-expr
                        `(format "Assertion failed: %s" ',name)))
               (diff ,(or diff-expr 'nil)))
           (if diff
               (signal 'e-unit-assertion-error (list msg diff))
             (signal 'e-unit-assertion-error (list msg))))))))

;;; Hook management

(defun e-unit--run-suite-setup ()
  "Run suite setup hooks if not already run."
  (unless e-unit--suite-setup-done
    (dolist (setup-fn e-unit--setup-suite-functions)
      (condition-case err
          (funcall setup-fn)
        (error
         (e-unit--print "Warning: suite setup failed: %S" err))))
    (setq e-unit--suite-setup-done t)))

(defun e-unit--run-suite-teardown ()
  "Run suite teardown hooks."
  (dolist (teardown-fn e-unit--teardown-suite-functions)
    (condition-case err
        (funcall teardown-fn)
      (error
       (e-unit--print "Warning: suite teardown failed: %S" err))))
  (setq e-unit--suite-setup-done nil))

(defun e-unit--run-file-setup (file)
  "Run file setup hooks for FILE if not already run."
  (unless (alist-get file e-unit--file-setups-done nil nil 'equal)
    (let ((setup-fns (e-unit--get-file-hooks file :setup-file)))
      (dolist (setup-fn setup-fns)
        (condition-case err
            (funcall setup-fn)
          (error
           (e-unit--print "Warning: file setup failed for %s: %S" file err)))))
    (setq e-unit--file-setups-done (cons (cons file t) e-unit--file-setups-done))))

(defun e-unit--run-file-teardown (file)
  "Run file teardown hooks for FILE."
  (let ((teardown-fns (e-unit--get-file-hooks file :teardown-file)))
    (dolist (teardown-fn teardown-fns)
      (condition-case err
          (funcall teardown-fn)
        (error
         (e-unit--print "Warning: file teardown failed for %s: %S" file err)))))
  ;; Remove from setup tracking
  (setq e-unit--file-setups-done (cl-remove-if (lambda (entry) (equal (car entry) file)) e-unit--file-setups-done)))

;;; Test discovery and running

(defun e-unit--run-test (test-name)
  "Execute a single test TEST-NAME with hook integration.
Creates context object, executes hooks, updates context with results."
  (cl-block e-unit--run-test
    (let* ((context (e-unit--create-test-context test-name))
           (test-fn (symbol-function test-name))
           (error-message nil))

      ;; Execute around-each hooks wrapping the core test execution
      (e-unit--execute-around-hooks
       :around-each
       context
       (lambda ()
         ;; Check for hook error from around phase
         (when (plist-get context :hook-error)
           (setq error-message (plist-get context :hook-error))
           (cl-return-from e-unit--run-test nil))

         ;; Execute before-each hooks
         (e-unit--execute-hooks :before-each context)

         ;; Check for hook error
         (when (plist-get context :hook-error)
           (setq error-message (plist-get context :hook-error))
           (cl-return-from e-unit--run-test nil))

         ;; Execute the actual test
         (condition-case err
             (progn
               (funcall test-fn)
               (plist-put context :status 'pass))
           (error
            (setq error-message (error-message-string err))
            (plist-put context :status 'fail)
            (plist-put context :error error-message)))

         ;; Execute after-each hooks (even if test failed)
         (e-unit--execute-hooks :after-each context)))

      ;; Calculate duration
      (let* ((start-time (plist-get context :start-time))
             (end-time (current-time))
             (duration (float-time (time-subtract end-time start-time))))
        (plist-put context :duration duration))

      ;; If no status set (e.g., hook error), mark as error
      (unless (plist-get context :status)
        (plist-put context :status 'error)
        (when error-message
          (plist-put context :error error-message)))

      context)))

(defun e-unit--filter-tests-for-run (tests)
  "Filter TESTS based on current run configuration.
Excludes autoload tests unless `e-unit--include-autoload-tests' is set."
  (if e-unit--include-autoload-tests
      tests
    (cl-remove-if (lambda (test)
                    (plist-get test :autoload))
                  tests)))

(defun e-unit--discover-tests (&optional buffer)
  "Discover all tests in BUFFER (default: current buffer)."
  (with-current-buffer (or buffer (current-buffer))
    (let ((current-file (or buffer-file-name "unknown-file")))
      ;; Return only tests from the current file, shuffled if configured
      (let ((tests (cl-remove-if-not (lambda (test)
                                      (equal (plist-get test :file) current-file))
                                    e-unit--tests)))
        (e-unit--shuffle-list (e-unit--filter-tests-for-run tests))))))

(defun e-unit--run-single-test (test-name)
  "Run a single test TEST-NAME and return result."
  (cl-block e-unit--run-single-test
    (let* ((start-time (current-time))
           (e-unit--current-test test-name)
           (result nil)
           (test-info (cl-find test-name e-unit--tests :key (lambda (test) (plist-get test :name))))
           (test-file (or (plist-get test-info :file) "unknown-file"))
           ;; Restore the test's captured context for hook matching
           (test-context (plist-get test-info :context))
           (saved-context-stack e-unit--context-stack))

      ;; Temporarily extend context stack with test's describe context for hook matching
      ;; Only do this if test has describe contexts (context contains "describe:")
      (when (and test-context
                 (cl-some (lambda (ctx) (string-prefix-p "describe:" ctx)) test-context))
        (setq e-unit--context-stack test-context))

      (unwind-protect
          (progn
            ;; Run setup hooks for the test's file
            (let ((setup-fns (e-unit--get-file-hooks test-file :setup-each)))
              (dolist (setup-fn setup-fns)
                (condition-case err
                    (funcall setup-fn)
                  (error
                   (setq result (list :status 'error
                                      :name test-name
                                      :error (format "setup-each failed: %s"
                                                     (error-message-string err))
                                      :duration (float-time (time-subtract (current-time) start-time))))
                   (cl-return-from e-unit--run-single-test result)))))

            ;; Create context for hooks
            (let ((context (list :test-name test-name :file test-file)))

              ;; Execute around-each hooks wrapping the test execution
              (e-unit--execute-around-hooks
               :around-each
               context
               (lambda ()
                 ;; Execute before-each hooks
                 (e-unit--execute-hooks :before-each context)

                 ;; Run the test
                 (condition-case err
                     (progn
                       (funcall test-name)
                       (setq result (list :status 'pass
                                          :name test-name
                                          :duration (float-time (time-subtract (current-time) start-time)))))
                   (e-unit-assertion-error
                    (let ((err-data (cdr err)))
                      ;; err-data is either:
                      ;; - A plist with :message, :file, :line, :column (new style)
                      ;; - A string (old style, for backward compatibility)
                      (setq result (list :status 'fail
                                         :name test-name
                                         :error (cond
                                                 ((stringp err-data) err-data)
                                                 ((plist-get err-data :message)
                                                  (plist-get err-data :message))
                                                 (t (format "%S" err-data)))
                                         :error-file (unless (stringp err-data)
                                                       (plist-get err-data :file))
                                         :error-line (unless (stringp err-data)
                                                       (plist-get err-data :line))
                                         :error-column (unless (stringp err-data)
                                                         (plist-get err-data :column))
                                         :duration (float-time (time-subtract (current-time) start-time))))))
                   (error
                    ;; For runtime errors, we can't capture precise location
                    ;; Fall back to test definition line (stored in test-info :line)
                    (setq result (list :status 'error
                                       :name test-name
                                       :error (format "%S: %S" (car err) (cdr err))
                                       :duration (float-time (time-subtract (current-time) start-time))))))

                 ;; Execute after-each hooks (even if test failed)
                 (e-unit--execute-hooks :after-each context)))

              ;; If hook error occurred without running test, create error result
              (unless result
                (setq result (list :status 'error
                                   :name test-name
                                   :error (or (plist-get context :hook-error)
                                              "Hook error prevented test execution")
                                   :duration (float-time (time-subtract (current-time) start-time))))))

            ;; Run teardown hooks for the test's file
            (let ((teardown-fns (e-unit--get-file-hooks test-file :teardown-each)))
              (dolist (teardown-fn teardown-fns)
                (condition-case err
                    (funcall teardown-fn)
                  (error
                   (e-unit--print "Warning: teardown failed: %S" err)))))

            result)

        ;; Cleanup: restore original context stack
        (setq e-unit--context-stack saved-context-stack)))))

(defun e-unit-run-file (file-path)
  "Run all tests in FILE-PATH."
  (interactive "fTest file: ")
  (unless (file-exists-p file-path)
    (error "File does not exist: %s" file-path))
  (let ((absolute-path (expand-file-name file-path)))
    ;; Pre-scan for assertion positions before loading
    (e-unit--scan-assertion-positions absolute-path)
    (with-temp-buffer
      (insert-file-contents absolute-path)
      (setq buffer-file-name absolute-path)
      (emacs-lisp-mode)
      ;; Bind load-file-name so tests register with correct file
      (let ((load-file-name absolute-path))
        (eval-buffer))
      (e-unit-run-buffer (current-buffer)))))

(defun e-unit-run-test (test-name)
  "Run a specific test by TEST-NAME."
  (interactive
   (list (intern (completing-read "Test name: "
                                  (mapcar (lambda (test) (symbol-name (car test))) e-unit--tests)
                                  nil t))))
  (unless (assq test-name e-unit--tests)
    (error "Test not found: %s" test-name))

  (e-unit--run-with-reporting
   (format "Single Test: %s" test-name)
   (lambda ()
     (let ((result (e-unit--run-single-test test-name)))
       (e-unit--notify-test-results (list result))
       (list result)))))

(defun e-unit-run-pattern (pattern &optional directory)
  "Run tests whose names match PATTERN.
If DIRECTORY is provided, search in that directory, otherwise use current
directory test files."
  (interactive "sTest name pattern (regexp): ")
  (let* ((test-files (if directory
                        (directory-files directory t ".*-test\\.el$")
                      (list (buffer-file-name))))
         (matching-tests nil))

    ;; Load all test files and collect matching tests
    (dolist (file test-files)
      (when (and file (file-exists-p file))
        ;; Pre-scan for assertion positions before loading
        (e-unit--scan-assertion-positions file)
        (with-temp-buffer
          (insert-file-contents file)
          (emacs-lisp-mode)
          (eval-buffer)
          ;; Find tests that match the pattern
          (dolist (test e-unit--tests)
            (when (string-match-p pattern (symbol-name (car test)))
              (push test matching-tests))))))

    (unless matching-tests
      (e-unit--print "No tests found matching pattern: %s" pattern)
      nil)

    (e-unit--run-with-reporting
     (format "Pattern Match: %s" pattern)
     (lambda ()
       (let ((results nil))
         ;; Run matching tests
         (dolist (test matching-tests)
           (let ((result (e-unit--run-single-test (car test))))
             (push result results)
             (e-unit--notify-reporters 'e-unit-reporter-test-result result)))
         (reverse results))))))

(defun e-unit-run-failed ()
  "Re-run tests that failed in the last test run."
  (interactive)
  (unless e-unit--last-results
    (error "No previous test results found"))

  (let ((failed-tests (cl-remove-if-not
                       (lambda (result)
                         (memq (plist-get result :status) '(fail error)))
                       e-unit--last-results)))

    (if (not failed-tests)
        (progn
          (e-unit--print "No failed tests from last run!")
          nil)

      (e-unit--print "Re-running %d failed test(s)..." (length failed-tests))

      (e-unit--run-with-reporting
       "Failed Tests Re-run"
       (lambda ()
         (let ((results nil))
           ;; Re-run each failed test
           (dolist (failed-test failed-tests)
             (let* ((test-name (plist-get failed-test :name))
                    (result (e-unit--run-single-test test-name)))
               (push result results)
               (e-unit--notify-reporters 'e-unit-reporter-test-result result)))
           (reverse results)))))))

(defun e-unit-run-interactive ()
  "Interactive test runner with multiple options."
  (interactive)
  (let ((choice (completing-read "Run tests: "
                                '(("Current buffer" . buffer)
                                  ("Specific file" . file)
                                  ("Directory" . directory)
                                  ("Single test" . test)
                                  ("Pattern match" . pattern)
                                  ("Failed tests" . failed))
                                nil t)))
    (cond
     ((string= choice "Current buffer")
      (e-unit-run-buffer))

     ((string= choice "Specific file")
      (let ((file (read-file-name "Test file: " nil nil t nil
                                  (lambda (name) (string-match-p ".*-test\\.el$" name)))))
        (e-unit-run-file file)))

     ((string= choice "Directory")
      (let ((dir (read-directory-name "Test directory: " "test/")))
        (e-unit-run-directory dir)))

     ((string= choice "Single test")
      (if e-unit--tests
          (let ((test-name (intern (completing-read "Test name: "
                                                   (mapcar (lambda (test) (symbol-name (plist-get test :name))) e-unit--tests)
                                                   nil t))))
            (e-unit-run-test test-name))
        (message "No tests found. Load a test file first.")))

     ((string= choice "Pattern match")
      (let ((pattern (read-string "Test name pattern (regexp): "))
            (dir (read-directory-name "Search directory (optional): " nil nil t)))
        (if (string-empty-p dir)
            (e-unit-run-pattern pattern)
          (e-unit-run-pattern pattern dir))))

     ((string= choice "Failed tests")
      (e-unit-run-failed))

     (t (message "Invalid choice")))))

(defun e-unit-run-buffer (&optional buffer)
  "Run all tests in BUFFER (default: current buffer)."
  (interactive)
  (let* ((buffer (or buffer (current-buffer)))
         (tests nil)
         (results nil)
         (start-time (current-time))
         (file (or buffer-file-name
                   (with-current-buffer buffer buffer-file-name)
                   (buffer-name buffer))))

    ;; Initialize seed for this run
    (e-unit--initialize-seed)

    ;; Get tests (will be shuffled if configured)
    (setq tests (e-unit--discover-tests buffer))

    (setq e-unit--results nil)

    ;; Ensure we have at least one reporter
    (e-unit--ensure-default-reporter)

    ;; Notify reporters that test suite is starting (unless in directory run)
    (unless e-unit--in-directory-run
      (e-unit--notify-reporters 'e-unit-reporter-start
                               (list :name (format "Test File: %s" (buffer-name buffer))
                                     :file file)))

    ;; Run suite setup if needed
    (e-unit--run-suite-setup)

    ;; Run file setup if needed - always run for each buffer
    (e-unit--run-file-setup file)

    (unwind-protect
        (progn
          ;; Push file context
          (e-unit-push-context (format "file:%s" file))

          ;; Create context for hooks
          (let ((context (list :file file)))

            ;; Execute around-file hooks wrapping the execution
            (e-unit--execute-around-hooks
             :around-file
             context
             (lambda ()
               ;; Execute before-file hooks
               (e-unit--execute-hooks :before-file context)

               (let ((stop-testing nil))
                 (dolist (test tests)
                   (unless stop-testing
                     (let* ((test-name (plist-get test :name))
                            (result (e-unit--run-single-test test-name)))
                       (push result results)
                       (e-unit--print-test-result result)

                       ;; Stop on failure if configured
                       (when (and e-unit--config-stop-on-failure
                                  (memq (plist-get result :status) '(fail error)))
                         (e-unit--print "Stopping test run due to failure (stop-on-failure enabled)")
                         (setq stop-testing t))))))

               ;; Execute after-file hooks
               (e-unit--execute-hooks :after-file context)))))

      ;; Cleanup: pop context and run file teardown
      (e-unit-pop-context)
      (e-unit--run-file-teardown file))

    (setq e-unit--results (reverse results))

    ;; Only print summary if not in directory run
    (unless e-unit--in-directory-run
      (e-unit--print-summary results (float-time (time-subtract (current-time) start-time))))

    ;; Store results for e-unit-run-failed
    (setq e-unit--last-results results)

    results))

(defun e-unit-run-directory (directory)
  "Run all tests in DIRECTORY."
  (interactive "DTest directory: ")
  ;; Load project config file (Eunit) if present
  (e-unit-load-config)

  (let ((test-files (directory-files-recursively directory ".*-test\\.el$")))
    (if (not test-files)
        (progn
          (e-unit--print "No test files found in %s" directory)
          nil)

      ;; Initialize seed for this run
      (e-unit--initialize-seed)

      ;; Shuffle test files if configured
      (when e-unit--config-shuffle-files
        (setq test-files (e-unit--shuffle-list test-files "test-files")))

      (when e-unit--config-verbose
        (e-unit--print "Found test files: %s" (mapcar #'file-name-nondirectory test-files)))

      ;; Push suite context BEFORE discovery so hooks register with correct context
      ;; This ensures context during discovery matches context during execution
      (e-unit-push-context (format "suite:%s" directory))

      ;; Phase 1: Discovery - Load all files to register tests and hooks
      (dolist (test-file test-files)
        ;; Pre-scan for assertion positions before loading each file
        (e-unit--scan-assertion-positions test-file)
        ;; Push file context so hooks registered during loading are scoped correctly
        (e-unit-push-context (format "file:%s" test-file))
        (with-temp-buffer
          (insert-file-contents test-file)
          (emacs-lisp-mode)
          (setq buffer-file-name test-file)
          ;; Bind load-file-name so hooks/tests register with correct file
          (let ((load-file-name test-file))
            (eval-buffer)))
        (e-unit-pop-context))

      ;; Phase 2: Execution - Run all discovered tests with proper hook order
      ;; Note: Suite context remains pushed from discovery phase

      ;; Ensure we have at least one reporter
      (e-unit--ensure-default-reporter)

      ;; Notify reporters that test suite is starting
      (e-unit--notify-reporters 'e-unit-reporter-start
                               (list :name (format "Test Directory: %s" directory)
                                     :files test-files))

      (e-unit--run-suite-setup)

      ;; Set directory run flag to suppress per-file summaries
      ;; Save old value to support nested directory runs
      (let ((old-in-directory-run e-unit--in-directory-run))
        (setq e-unit--in-directory-run t)

        (unwind-protect
            (let ((total-results nil)
                  (start-time (current-time)))

            ;; Create context for hooks
            (let ((context (list :directory directory :files test-files)))

              ;; Execute around-suite hooks wrapping the execution
              (e-unit--execute-around-hooks
               :around-suite
               context
               (lambda ()
                 ;; Execute before-suite hooks
                 (e-unit--execute-hooks :before-suite context)

                 (dolist (test-file test-files)
                   (with-temp-buffer
                     (setq buffer-file-name test-file)
                     (let ((file-results (e-unit-run-buffer)))
                       (setq total-results (append total-results file-results)))))

                 ;; Execute after-suite hooks
                 (e-unit--execute-hooks :after-suite context))))

            ;; Print overall summary
            (e-unit--print-summary total-results (float-time (time-subtract (current-time) start-time)))

            ;; Store results for e-unit-run-failed
            (setq e-unit--last-results total-results)

            total-results)

          ;; Cleanup: pop context, restore flag, and run suite teardown
          (e-unit-pop-context)
          (setq e-unit--in-directory-run old-in-directory-run)
          (e-unit--run-suite-teardown))))))

;;; Test Output

(defun e-unit--print (format-string &rest args)
  "Print FORMAT-STRING with ARGS to standard output.
This is for test framework output that should:
- Go to stdout in batch mode
- Appear in compilation buffers
- Not be suppressed by `inhibit-message'
Unlike `message', this does not display in the echo area or log
to *Messages* buffer."
  (princ (apply #'format format-string args))
  (terpri))

;;; Compilation buffer integration

(defvar e-unit--compilation-reporter nil
  "Whether to use `compilation-mode' compatible output format.")

(defun e-unit--print-test-result (result)
  "Print RESULT of a single test."
  ;; Notify all active reporters
  (e-unit--notify-reporters 'e-unit-reporter-test-result result))

(defun e-unit--print-console-result (result)
  "Print test RESULT in console format."
  (let* ((status (plist-get result :status))
         (name (plist-get result :name))
         (duration (plist-get result :duration))
         (error-msg (plist-get result :error))
         ;; Prefer error location from result, fall back to test definition
         (test-info (cl-find-if (lambda (test) (eq (plist-get test :name) name)) e-unit--tests))
         (file (or (plist-get result :error-file)
                   (plist-get test-info :file)
                   "unknown"))
         (line (or (plist-get result :error-line)
                   (plist-get test-info :line)
                   1))
         (column (plist-get result :error-column)))

    (cond
     ((eq status 'pass)
      (e-unit--print "✓ %s [%.3fs]" name duration))
     ((eq status 'fail)
      (e-unit--print "✗ %s [%.3fs]" name duration)
      (e-unit--print "  %s" error-msg)
      (if column
          (e-unit--print "  at %s:%d:%d" file line column)
        (e-unit--print "  at %s:%d" file line)))
     ((eq status 'error)
      (e-unit--print "E %s [%.3fs]" name duration)
      (e-unit--print "  ERROR: %s" error-msg)
      (if column
          (e-unit--print "  at %s:%d:%d" file line column)
        (e-unit--print "  at %s:%d" file line))))))

(defun e-unit--print-compilation-result (result)
  "Print test RESULT in `compilation-mode' compatible format.
Uses file:line:column format for error navigation."
  (let* ((status (plist-get result :status))
         (name (plist-get result :name))
         (error-msg (plist-get result :error))
         ;; Prefer error location from result, fall back to test definition
         (test-info (cl-find-if (lambda (test) (eq (plist-get test :name) name)) e-unit--tests))
         (file (or (plist-get result :error-file)
                   (plist-get test-info :file)
                   load-file-name
                   buffer-file-name
                   "unknown-file"))
         (line (or (plist-get result :error-line)
                   (plist-get test-info :line)
                   1))
         (column (or (plist-get result :error-column) 1)))

    (cond
     ((eq status 'pass)
      ;; Don't print passing tests in compilation mode to reduce noise
      nil)
     ((eq status 'fail)
      (e-unit--print "%s:%d:%d: FAIL %s" file line column name)
      (when error-msg
        (e-unit--print "  %s" error-msg)))
     ((eq status 'error)
      (e-unit--print "%s:%d:%d: ERROR %s" file line column name)
      (when error-msg
        (e-unit--print "  %s" error-msg))))))

(defun e-unit--print-summary (results total-duration)
  "Print summary of test RESULTS and TOTAL-DURATION."
  (let* ((total (length results))
         (passed (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'pass)) results)))
         (failed (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'fail)) results)))
         (errors (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'error)) results)))
         (summary (list :total total :passed passed :failed failed :errors errors :duration total-duration)))

    ;; Notify all active reporters
    (e-unit--notify-reporters 'e-unit-reporter-finish summary)))

(defun e-unit--print-console-summary (summary)
  "Print test run SUMMARY in console format."
  (let ((total (plist-get summary :total))
        (passed (plist-get summary :passed))
        (failed (plist-get summary :failed))
        (errors (plist-get summary :errors))
        (duration (plist-get summary :duration)))

    (e-unit--print "")
    (e-unit--print "Finished in %.3fs" duration)
    (e-unit--print "%d tests: %d passed, %d failed, %d errors" total passed failed errors)))

;;; Compilation mode runners

(defun e-unit-run-buffer-compilation ()
  "Run current buffer tests in compilation buffer."
  (interactive)
  (let ((current-file (buffer-file-name)))
    (if (not current-file)
        (message "Buffer has no file name")
      (e-unit--run-compilation-command
       (format "emacs -batch -Q -L %s -l eunit -l %s --eval '(e-unit-set-reporter (quote compilation))' --eval '(e-unit-run-buffer)'"
               default-directory current-file)))))

(defun e-unit-run-directory-compilation (&optional directory)
  "Run DIRECTORY test in compilation buffer."
  (interactive "DTest directory: ")
  (let ((test-dir (or directory "test")))
    (e-unit--run-compilation-command
     (format "emacs -batch -Q -L %s -l eunit --eval '(e-unit-set-reporter (quote compilation))' --eval '(e-unit-run-directory \"%s\")'"
             default-directory test-dir))))

(defun e-unit--run-compilation-command (command)
  "Run COMMAND in compilation buffer with E-Unit error parsing."
  (let ((compilation-buffer-name-function (lambda (_mode) "*eunit*")))
    (compilation-start command 'e-unit-compilation-mode "eunit")))

;; Define compilation mode for E-Unit
(define-compilation-mode e-unit-compilation-mode "E-Unit"
  "Compilation mode for E-Unit test results."
  (setq-local compilation-error-regexp-alist
              '((e-unit-fail "^\\([^:]+\\):\\([0-9]+\\):\\([0-9]+\\): \\(FAIL\\|ERROR\\)" 1 2 3)))
  (setq-local compilation-error-regexp-alist-alist
              '((e-unit-fail "^\\([^:]+\\):\\([0-9]+\\):\\([0-9]+\\): \\(FAIL\\|ERROR\\)" 1 2 3))))

;; Batch mode runners for compilation output
(defun e-unit-run-batch-and-exit ()
  "Run tests in batch mode and exit with appropriate code."
  (interactive)
  (setq e-unit--compilation-reporter t)
  (let ((results (e-unit-run-directory "test")))
    (let ((failed (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'fail)) results)))
          (errors (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'error)) results))))
      (kill-emacs (if (> (+ failed errors) 0) 1 0)))))

;;; Short Syntax Initialization

(defun e-unit-initialize ()
  "Initialize e-unit with short syntax aliases.
Call this function in your test files to enable unprefixed
assertion and macro names like `deftest', `assert-equal', etc.

This function is idempotent - calling it multiple times is safe.

Example usage:
  (require \\='e-unit)
  (e-unit-initialize)

  (deftest my-test ()
    \"Test something.\"
    (assert-equal 42 (my-function)))

Returns t on first initialization, nil if already initialized."
  (if e-unit--initialized
      nil
    ;; Test definition
    (defalias 'deftest #'e-unit-deftest)
    (defalias 'deftest-parameterized #'e-unit-deftest-parameterized)
    (defalias 'deftest-autoload #'e-unit-deftest-autoload)

    ;; Hook macros
    (defalias 'setup-each #'e-unit-setup-each)
    (defalias 'teardown-each #'e-unit-teardown-each)
    (defalias 'setup-file #'e-unit-setup-file)
    (defalias 'teardown-file #'e-unit-teardown-file)
    (defalias 'setup-suite #'e-unit-setup-suite)
    (defalias 'teardown-suite #'e-unit-teardown-suite)
    (defalias 'around-each #'e-unit-around-each)
    (defalias 'around-file #'e-unit-around-file)
    (defalias 'around-suite #'e-unit-around-suite)

    ;; Basic assertions
    (defalias 'assert-equal #'e-unit-assert-equal)
    (defalias 'assert-true #'e-unit-assert-true)
    (defalias 'assert-nil #'e-unit-assert-nil)
    (defalias 'assert-not-equal #'e-unit-assert-not-equal)
    (defalias 'assert-same #'e-unit-assert-same)
    (defalias 'assert-not-same #'e-unit-assert-not-same)
    (defalias 'refute-nil #'e-unit-refute-nil)
    (defalias 'assert-false #'e-unit-assert-false)

    ;; Numeric assertions
    (defalias 'assert-in-delta #'e-unit-assert-in-delta)
    (defalias 'assert-in-epsilon #'e-unit-assert-in-epsilon)
    (defalias 'refute-in-delta #'e-unit-refute-in-delta)
    (defalias 'refute-in-epsilon #'e-unit-refute-in-epsilon)

    ;; Collection assertions
    (defalias 'assert-includes #'e-unit-assert-includes)
    (defalias 'refute-includes #'e-unit-refute-includes)
    (defalias 'assert-empty #'e-unit-assert-empty)
    (defalias 'refute-empty #'e-unit-refute-empty)
    (defalias 'assert-length #'e-unit-assert-length)

    ;; Type assertions
    (defalias 'assert-instance-of #'e-unit-assert-instance-of)
    (defalias 'assert-kind-of #'e-unit-assert-kind-of)
    (defalias 'assert-responds-to #'e-unit-assert-responds-to)
    (defalias 'assert-predicate #'e-unit-assert-predicate)
    (defalias 'assert-operator #'e-unit-assert-operator)

    ;; String/pattern assertions
    (defalias 'assert-match #'e-unit-assert-match)
    (defalias 'refute-match #'e-unit-refute-match)

    ;; Property-aware assertions
    (defalias 'assert-match-with-properties #'e-unit-assert-match-with-properties)
    (defalias 'refute-match-with-properties #'e-unit-refute-match-with-properties)
    (defalias 'assert-includes-with-properties #'e-unit-assert-includes-with-properties)
    (defalias 'refute-includes-with-properties #'e-unit-refute-includes-with-properties)

    ;; Exception assertions
    (defalias 'assert-raises #'e-unit-assert-raises)

    ;; Assertion DSL
    (defalias 'define-assertion #'e-unit-define-assertion)

    ;; Parameterized test runner
    (defalias 'run-parameterized #'e-unit-run-parameterized)

    ;; Load and initialize extensions
    (require 'e-unit-mock)
    (e-unit-mock-initialize)
    (require 'e-unit-describe)

    (setq e-unit--initialized t)
    t))

(provide 'e-unit)

;;; Reporter System

;;; Reporter Interface

(cl-defgeneric e-unit-reporter-start (reporter suite-info)
  "Called when test suite start with REPORTER and SUITE-INFO.
SUITE-INFO contains metadata about the suite.")

(cl-defgeneric e-unit-reporter-test-result (reporter result)
  "Called for each test RESULT using REPORTER.
RESULT contains test outcome data.")

(cl-defgeneric e-unit-reporter-finish (reporter summary)
  "Called when test suite finish with REPORTER and SUMMARY.
SUMMARY contains overall results.")

;;; Reporter Registry

(defvar e-unit--active-reporters nil
  "List of active reporters for current test run.")

;;; Global Configuration

(defun e-unit-configure (&rest options)
  "Configure E-Unit global settings with OPTIONS.
Available OPTIONS:
  :shuffle-tests BOOL    - Run tests in random order (default: t)
  :shuffle-files BOOL    - Run test files in random order (default: t)
  :seed NUMBER          - Random seed for reproducibility (default: random)
  :verbose BOOL         - Show verbose output (default: nil)
  :stop-on-failure BOOL - Stop after first failure (default: nil)

Example:
  (e-unit-configure :seed 12345 :verbose t :stop-on-failure nil)"
  (while options
    (let ((key (car options))
          (value (cadr options)))
      (cond
       ((eq key :shuffle-tests)
        (setq e-unit--config-shuffle-tests value))
       ((eq key :shuffle-files)
        (setq e-unit--config-shuffle-files value))
       ((eq key :seed)
        (setq e-unit--config-seed value))
       ((eq key :verbose)
        (setq e-unit--config-verbose value))
       ((eq key :stop-on-failure)
        (setq e-unit--config-stop-on-failure value))
       (t
        (error "Unknown configuration option: %s" key)))
      (setq options (cddr options)))))

(defun e-unit--initialize-seed ()
  "Initialize random seed for test run."
  (let ((seed (or e-unit--config-seed
                  (floor (* (float-time) 1000000)))))  ; Use microseconds for good randomness
    (setq e-unit--current-seed seed)
    (random seed)  ; Seed the random number generator
    seed))

(defun e-unit--shuffle-list (list &optional context)
  "Shuffle LIST using Fisher-Yates algorithm with current random seed.
CONTEXT is a string identifier for deterministic shuffling within the same run."
  (if (not e-unit--config-shuffle-tests)
      list
    ;; For deterministic shuffling, use a predictable sequence based on context
    (let* ((context-hash (if context (sxhash context) 0))
           (shuffled (copy-sequence list))
           (n (length list)))
      ;; Generate a deterministic sequence based on seed and context
      (dotimes (i (1- n))
        (let* ((deterministic-value (logxor e-unit--current-seed context-hash i))
               (j (+ i (mod (abs deterministic-value) (- n i))))
               (temp (nth i shuffled)))
          (setcar (nthcdr i shuffled) (nth j shuffled))
          (setcar (nthcdr j shuffled) temp)))
      shuffled)))

(defun e-unit-set-reporter (type &rest options)
  "Set the primary reporter to TYPE with OPTIONS.

TYPE can be:
  - A symbol for built-in reporters: \\='console, \\='dot,
    \\='junit, \\='compilation
  - A custom reporter object (must implement e-unit-reporter-*
    methods)"
  (setq e-unit--active-reporters
        (list (if (symbolp type)
                  (e-unit--create-reporter type options)
                type))))

(defun e-unit-add-reporter (type &rest options)
  "Add an additional reporter of TYPE with OPTIONS.

TYPE can be:
  - A symbol for built-in reporters: \\='console, \\='dot,
    \\='junit, \\='compilation
  - A custom reporter object (must implement e-unit-reporter-*
    methods)"
  (push (if (symbolp type)
            (e-unit--create-reporter type options)
          type)
        e-unit--active-reporters))

(defun e-unit--create-reporter (type options)
  "Create a reporter instance of TYPE with OPTIONS."
  (cond
   ((eq type 'console) (e-unit--create-console-reporter options))
   ((eq type 'dot) (e-unit--create-dot-reporter options))
   ((eq type 'junit) (e-unit--create-junit-reporter options))
   ((eq type 'compilation) (e-unit--create-compilation-reporter options))
   ((eq type 'null) (e-unit--create-null-reporter options))
   (t (error "Unknown reporter type: %s" type))))

;;; Shared Reporter Utilities

(defun e-unit--print-failures-section (failures errors &optional prefix-failures)
  "Print FAILURES and ERRORS sections for end-of-run summary.
If PREFIX-FAILURES is non-nil, prefix failure names with \"FAIL: \"."
  (let ((failure-num 1))
    ;; Print failures
    (when failures
      (e-unit--print "\nFailures:")
      (dolist (result failures)
        (let* ((name (plist-get result :name))
               (error-msg (plist-get result :error))
               (test-info (cl-find-if (lambda (test) (eq (plist-get test :name) name))
                                      e-unit--tests))
               (file (or (plist-get result :error-file)
                         (plist-get test-info :file)
                         "unknown"))
               (line (or (plist-get result :error-line)
                         (plist-get test-info :line)
                         1))
               (column (plist-get result :error-column)))
          (if prefix-failures
              (e-unit--print "\n%d) FAIL: %s" failure-num name)
            (e-unit--print "\n%d) %s" failure-num name))
          (e-unit--print "   %s" error-msg)
          (if column
              (e-unit--print "   at %s:%d:%d" file line column)
            (e-unit--print "   at %s:%d" file line))
          (setq failure-num (1+ failure-num)))))

    ;; Print errors
    (when errors
      (e-unit--print "\nErrors:")
      (dolist (result errors)
        (let* ((name (plist-get result :name))
               (error-msg (plist-get result :error))
               (test-info (cl-find-if (lambda (test) (eq (plist-get test :name) name))
                                      e-unit--tests))
               (file (or (plist-get result :error-file)
                         (plist-get test-info :file)
                         "unknown"))
               (line (or (plist-get result :error-line)
                         (plist-get test-info :line)
                         1))
               (column (plist-get result :error-column)))
          (e-unit--print "\n%d) %s" failure-num name)
          (e-unit--print "   ERROR: %s" error-msg)
          (if column
              (e-unit--print "   at %s:%d:%d" file line column)
            (e-unit--print "   at %s:%d" file line))
          (setq failure-num (1+ failure-num)))))))

;;; Console Reporter (Default)

(defun e-unit--create-console-reporter (options)
  "Create console reporter with OPTIONS."
  (list :type 'console
        :options options
        :failures nil
        :errors nil))

(defun e-unit--console-reporter-start (reporter suite-info)
  "Start console reporting with REPORTER and SUITE-INFO."
  ;; Reset failure/error collections
  (plist-put reporter :failures nil)
  (plist-put reporter :errors nil)
  ;; Show seed information if this is a directory run with multiple files
  (when (and e-unit--current-seed
             (plist-get suite-info :files))  ; Directory run has :files
    (e-unit--print "Using seed: %s (to reproduce: (e-unit-configure :seed %s))"
                   e-unit--current-seed e-unit--current-seed)))

(defun e-unit--console-reporter-test-result (reporter result)
  "Report test RESULT to console, collecting failures for end."
  (let* ((status (plist-get result :status))
         (name (plist-get result :name))
         (duration (plist-get result :duration)))
    (cond
     ((eq status 'pass)
      (e-unit--print "✓ %s [%.3fs]" name duration))
     ((eq status 'fail)
      (e-unit--print "✗ %s [%.3fs]" name duration)
      ;; Collect failure for later display
      (plist-put reporter :failures
                 (append (plist-get reporter :failures) (list result))))
     ((eq status 'error)
      (e-unit--print "E %s [%.3fs]" name duration)
      ;; Collect error for later display
      (plist-put reporter :errors
                 (append (plist-get reporter :errors) (list result)))))))

(defun e-unit--console-reporter-finish (reporter summary)
  "Finish console reporting with REPORTER and SUMMARY."
  (e-unit--print-failures-section (plist-get reporter :failures)
                                  (plist-get reporter :errors))
  (e-unit--print-console-summary summary))

;;; Dot Reporter (Minitest/RSpec style)

(defun e-unit--create-dot-reporter (options)
  "Create dot reporter with OPTIONS."
  (list :type 'dot
        :options options
        :failures nil
        :errors nil))

(defun e-unit--dot-reporter-start (reporter suite-info)
  "Start dot reporting with REPORTER and SUITE-INFO."
  ;; Show seed information if this is a directory run with multiple files
  (when (and e-unit--current-seed
             (plist-get suite-info :files))  ; Directory run has :files
    (e-unit--print "Using seed: %s (to reproduce: (e-unit-configure :seed %s))"
                   e-unit--current-seed e-unit--current-seed))
  ;; Reset failure/error collections
  (plist-put reporter :failures nil)
  (plist-put reporter :errors nil))

(defun e-unit--dot-reporter-test-result (reporter result)
  "Report test RESULT with dot notation using REPORTER."
  (let ((status (plist-get result :status)))
    (cond
     ((eq status 'pass)
      (princ "."))
     ((eq status 'fail)
      (princ "F")
      ;; Collect failure for later display
      (plist-put reporter :failures
                 (append (plist-get reporter :failures) (list result))))
     ((eq status 'error)
      (princ "E")
      ;; Collect error for later display
      (plist-put reporter :errors
                 (append (plist-get reporter :errors) (list result)))))))

(defun e-unit--dot-reporter-finish (reporter summary)
  "Finish dot reporting with REPORTER and SUMMARY and print failures."
  (e-unit--print "")
  (e-unit--print-failures-section (plist-get reporter :failures)
                                  (plist-get reporter :errors)
                                  t)  ; prefix failures with "FAIL:"
  (e-unit--print-console-summary summary))

;;; Compilation Reporter

(defun e-unit--create-compilation-reporter (options)
  "Create compilation reporter with OPTIONS."
  (list :type 'compilation :options options))

(defun e-unit--compilation-reporter-start (_reporter suite-info)
  "Start compilation reporting with SUITE-INFO."
  ;; Show seed information in compilation buffer
  (when (and e-unit--current-seed
             (plist-get suite-info :files))  ; Directory run has :files
    (e-unit--print "# Using seed: %s (to reproduce: (e-unit-configure :seed %s))"
                   e-unit--current-seed e-unit--current-seed)))

(defun e-unit--compilation-reporter-test-result (_reporter result)
  "Report test RESULT to compilation buffer."
  (e-unit--print-compilation-result result))

(defun e-unit--compilation-reporter-finish (_reporter summary)
  "Finish compilation reporting with SUMMARY."
  (e-unit--print-console-summary summary))

;;; JUnit XML Reporter

(defun e-unit--create-junit-reporter (options)
  "Create JUnit XML reporter with OPTIONS."
  (let ((output-file (plist-get options :file)))
    (list :type 'junit
          :options options
          :file (or output-file "test-results.xml")
          :test-suites nil
          :current-suite nil
          :start-time (current-time))))

(defun e-unit--junit-reporter-start (reporter suite-info)
  "Start JUnit XML reporting with REPORTER and SUITE-INFO."
  (let ((suite-name (or (plist-get suite-info :name) "E-Unit Test Suite"))
        (timestamp (format-time-string "%FT%T")))
    (plist-put reporter :suite-name suite-name)
    (plist-put reporter :timestamp timestamp)
    (plist-put reporter :test-suites nil)))

(defun e-unit--junit-reporter-test-result (reporter result)
  "Report test RESULT to JUnit XML using REPORTER."
  (let* ((file (plist-get result :file))
         (current-suite (plist-get reporter :current-suite))
         (suite-name (file-name-nondirectory (or file "unknown-file"))))

    ;; Create new suite if file changed
    (unless (and current-suite (equal (plist-get current-suite :name) suite-name))
      (when current-suite
        ;; Finish previous suite
        (push current-suite (plist-get reporter :test-suites)))

      ;; Start new suite
      (plist-put reporter :current-suite
                 (list :name suite-name
                       :file file
                       :tests nil
                       :start-time (current-time))))

    ;; Add test to current suite
    (let ((current-suite (plist-get reporter :current-suite)))
      (push result (plist-get current-suite :tests)))))

(defun e-unit--junit-reporter-finish (reporter summary)
  "Finish JUnit XML reporting with REPORTER and SUMMARY and write file."
  ;; Finish last suite
  (let ((current-suite (plist-get reporter :current-suite)))
    (when current-suite
      (push current-suite (plist-get reporter :test-suites))))

  ;; Write XML file
  (e-unit--write-junit-xml reporter summary))

(defun e-unit--write-junit-xml (reporter summary)
  "Write JUnit XML file for REPORTER with SUMMARY."
  (let ((file (plist-get reporter :file))
        (test-suites (reverse (plist-get reporter :test-suites)))
        (total-tests (plist-get summary :total))
        (total-failures (plist-get summary :failed))
        (total-errors (plist-get summary :errors))
        (total-time (plist-get summary :duration))
        (timestamp (plist-get reporter :timestamp)))

    (with-temp-file file
      (insert "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
      (insert (format "<testsuites name=\"%s\" tests=\"%d\" failures=\"%d\" errors=\"%d\" time=\"%.3f\" timestamp=\"%s\">\n"
                      (or (plist-get reporter :suite-name) "E-Unit Test Suite")
                      total-tests total-failures total-errors total-time timestamp))

      ;; Add seed information as properties if available
      (when e-unit--current-seed
        (insert "  <properties>\n")
        (insert (format "    <property name=\"eunit.seed\" value=\"%s\"/>\n" e-unit--current-seed))
        (insert "  </properties>\n"))

      ;; Write each test suite
      (dolist (suite test-suites)
        (e-unit--write-junit-testsuite suite))

      (insert "</testsuites>\n"))

    (e-unit--print "JUnit XML report written to: %s" file)))

(defun e-unit--write-junit-testsuite (suite)
  "Write a single test SUITE to current buffer."
  (let* ((suite-name (plist-get suite :name))
         (tests (reverse (plist-get suite :tests)))
         (test-count (length tests))
         (failures (cl-count-if (lambda (test) (eq (plist-get test :status) 'fail)) tests))
         (errors (cl-count-if (lambda (test) (eq (plist-get test :status) 'error)) tests))
         (total-time (apply #'+ (mapcar (lambda (test) (plist-get test :duration)) tests))))

    (insert (format "  <testsuite name=\"%s\" tests=\"%d\" failures=\"%d\" errors=\"%d\" time=\"%.3f\">\n"
                    suite-name test-count failures errors total-time))

    ;; Write each test case
    (dolist (test tests)
      (e-unit--write-junit-testcase test))

    (insert "  </testsuite>\n")))

(defun e-unit--write-junit-testcase (test)
  "Write a single test case TEST to current buffer."
  (let ((name (plist-get test :name))
        (duration (plist-get test :duration))
        (status (plist-get test :status))
        (error-msg (plist-get test :error)))

    (if (eq status 'pass)
        (insert (format "    <testcase name=\"%s\" time=\"%.3f\"/>\n" name duration))
      (insert (format "    <testcase name=\"%s\" time=\"%.3f\">\n" name duration))

      ;; Add failure or error element
      (cond
       ((eq status 'fail)
        (insert (format "      <failure message=\"Assertion failed\">%s</failure>\n"
                        (e-unit--escape-xml error-msg))))
       ((eq status 'error)
        (insert (format "      <error message=\"Test error\">%s</error>\n"
                        (e-unit--escape-xml error-msg)))))

      (insert "    </testcase>\n"))))

(defun e-unit--escape-xml (string)
  "Escape STRING for use in XML using built-in xml-escape-string."
  (when string
    (xml-escape-string (format "%s" string))))

;;; Null Reporter (Silent)

(defun e-unit--create-null-reporter (options)
  "Create null reporter with OPTIONS.
The null reporter produces no output but still allows tests to run
and collect results.  Useful for tests that need isolated reporter
state without generating console output."
  (list :type 'null :options options))

(defun e-unit--null-reporter-start (_reporter _suite-info)
  "Start null reporting - does nothing.")

(defun e-unit--null-reporter-test-result (_reporter _result)
  "Report test result - does nothing.")

(defun e-unit--null-reporter-finish (_reporter _summary)
  "Finish null reporting - does nothing.")

;;; Reporter API Integration

(defun e-unit--notify-reporters (method &rest args)
  "Notify all active reporters with METHOD and ARGS.

Supports both built-in plist-based reporters and custom class-based
reporters that implement `cl-defmethod' for e-unit-reporter-* generics."
  (dolist (reporter e-unit--active-reporters)
    ;; Check if this is a plist-based built-in reporter or a custom object
    (if (and (listp reporter) (plist-get reporter :type))
        ;; Built-in plist-based reporter - use direct dispatch
        (let ((reporter-type (plist-get reporter :type)))
          (cond
           ((eq method 'e-unit-reporter-start)
            (cond
             ((eq reporter-type 'console) (e-unit--console-reporter-start reporter (car args)))
             ((eq reporter-type 'dot) (e-unit--dot-reporter-start reporter (car args)))
             ((eq reporter-type 'junit) (e-unit--junit-reporter-start reporter (car args)))
             ((eq reporter-type 'compilation) (e-unit--compilation-reporter-start reporter (car args)))
             ((eq reporter-type 'null) (e-unit--null-reporter-start reporter (car args)))))
           ((eq method 'e-unit-reporter-test-result)
            (cond
             ((eq reporter-type 'console) (e-unit--console-reporter-test-result reporter (car args)))
             ((eq reporter-type 'dot) (e-unit--dot-reporter-test-result reporter (car args)))
             ((eq reporter-type 'junit) (e-unit--junit-reporter-test-result reporter (car args)))
             ((eq reporter-type 'compilation) (e-unit--compilation-reporter-test-result reporter (car args)))
             ((eq reporter-type 'null) (e-unit--null-reporter-test-result reporter (car args)))))
           ((eq method 'e-unit-reporter-finish)
            (cond
             ((eq reporter-type 'console) (e-unit--console-reporter-finish reporter (car args)))
             ((eq reporter-type 'dot) (e-unit--dot-reporter-finish reporter (car args)))
             ((eq reporter-type 'junit) (e-unit--junit-reporter-finish reporter (car args)))
             ((eq reporter-type 'compilation) (e-unit--compilation-reporter-finish reporter (car args)))
             ((eq reporter-type 'null) (e-unit--null-reporter-finish reporter (car args)))))))
      ;; Custom class-based reporter - use generic functions
      (cond
       ((eq method 'e-unit-reporter-start)
        (e-unit-reporter-start reporter (car args)))
       ((eq method 'e-unit-reporter-test-result)
        (e-unit-reporter-test-result reporter (car args)))
       ((eq method 'e-unit-reporter-finish)
        (e-unit-reporter-finish reporter (car args)))))))

;;; Test runner helper functions

(defun e-unit--calculate-summary (results start-time)
  "Calculate test run summary from RESULTS and START-TIME."
  (let ((total-tests (length results))
        (passed (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'pass)) results)))
        (failed (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'fail)) results)))
        (errors (length (cl-remove-if-not (lambda (r) (eq (plist-get r :status) 'error)) results)))
        (duration (float-time (time-subtract (current-time) start-time))))
    (list :total total-tests
          :passed passed
          :failed failed
          :errors errors
          :duration duration)))

(defun e-unit--run-with-reporting (description test-fn)
  "Run tests with proper reporter notifications.
DESCRIPTION is shown in start notification.
TEST-FN should return a list of test results.
When in directory run, start/finish notifications are suppressed
to avoid per-file summaries."
  (let ((start-time (current-time))
        ;; Suppress output if we're in a directory run
        (suppress-output e-unit--in-directory-run))
    ;; Ensure we have at least one reporter
    (e-unit--ensure-default-reporter)

    ;; Notify reporters that test suite is starting (unless suppressed)
    (unless suppress-output
      (e-unit--notify-reporters 'e-unit-reporter-start
                               (list :name description)))

    ;; Run the tests
    (let ((results (funcall test-fn)))

      ;; Calculate and send summary (unless suppressed)
      (unless suppress-output
        (let ((summary (e-unit--calculate-summary results start-time)))
          (e-unit--notify-reporters 'e-unit-reporter-finish summary)))

      ;; Store results for e-unit-run-failed
      (setq e-unit--last-results results)

      results)))

(defun e-unit--notify-test-results (results)
  "Notify reporters of each test result in RESULTS."
  (dolist (result results)
    (e-unit--notify-reporters 'e-unit-reporter-test-result result)))

;;; Parameterized Tests

(defun e-unit-run-parameterized (test-name parameter-sets)
  "Run TEST-NAME with each set of parameters in PARAMETER-SETS.
TEST-NAME should be a symbol of a test function that accepts parameters.
PARAMETER-SETS should be a list of parameter lists.
Results are returned and individual test results are reported to active
reporters, but no start/finish notifications are sent (those are handled
by the enclosing test runner).

Example:
  (e-unit-deftest test-box-sizes (width height expected-area)
    \"Test area calculation\"
    (assert-equal expected-area (* width height)))

  (e-unit-run-parameterized \\='test-box-sizes
    \\='((10 20 200)
      (5 5 25)
      (100 1 100)))"
  (unless (functionp test-name)
    (error "Test function not found: %s" test-name))

  (unless parameter-sets
    (error "No parameter sets provided"))

  (let ((results nil)
        (case-number 0))

    ;; Run test with each parameter set
    (dolist (params parameter-sets)
      (setq case-number (1+ case-number))

      ;; Create a unique test name for this case
      (let* ((case-name (intern (format "%s-case-%d" test-name case-number)))
             (test-fn test-name)
             (result nil))

        ;; Run the test with parameters
        (setq result
              (condition-case err
                  (progn
                    (apply test-fn params)
                    (list :name case-name
                          :status 'pass
                          :duration 0.000
                          :params params))
                (error
                 (list :name case-name
                       :status 'fail
                       :duration 0.000
                       :params params
                       :error (format "%S" err)))))

        (push result results)
        (e-unit--notify-reporters 'e-unit-reporter-test-result result)))

    (reverse results)))

(defmacro e-unit-deftest-parameterized (name &rest args)
  "Define a parameterized test NAME with declarative syntax.
ARGS should contain :parameters and :test keys.

Example:
  (e-unit-deftest-parameterized test-coordinates
    :parameters \\='((node-a 100 50)
                  (node-b 200 100)
                  (node-c 300 150))
    :test (lambda (node-id x y)
            (assert-in-delta (get-x node-id) x 0.1)
            (assert-in-delta (get-y node-id) y 0.1)))"
  (let ((parameters nil)
        (test-fn nil)
        (docstring nil))

    ;; Parse arguments - handle optional docstring first
    (when (and args (stringp (car args)))
      (setq docstring (car args))
      (setq args (cdr args)))

    ;; Parse key-value pairs
    (while args
      (let ((key (car args))
            (value (cadr args)))
        (cond
         ((eq key :parameters)
          (setq parameters value))
         ((eq key :test)
          (setq test-fn value))
         (t
          (error "Unknown key in e-unit-deftest-parameterized: %s" key)))
        (setq args (cddr args))))

    (unless parameters
      (error "e-unit-deftest-parameterized requires :parameters"))
    (unless test-fn
      (error "e-unit-deftest-parameterized requires :test"))

    ;; Generate the test function and registration
    `(progn
       ;; Define a wrapper function that calls e-unit-run-parameterized
       (defun ,name ()
         ,(or docstring (format "Parameterized test: %s" name))
         (e-unit-run-parameterized
          (quote ,(intern (format "%s--test-fn" name)))
          ,parameters))

       ;; Define the actual test function that takes parameters
       (defun ,(intern (format "%s--test-fn" name)) (&rest params)
         ,(format "Test function for parameterized test %s" name)
         (apply ,test-fn params))

       ;; Register the wrapper as a test with source location
       (e-unit--register-test (quote ,name) ,(or docstring (format "Parameterized test: %s" name)) ,(line-number-at-pos)))))

;;; Test helpers for isolated execution

(defun e-unit-run-isolated-test-code (test-code &optional reporter-type reporter-options)
  "Run TEST-CODE in isolated Emacs instance and return output.
REPORTER-TYPE defaults to \='console.
REPORTER-OPTIONS are passed to the reporter.
Returns the captured output as a string."
  (let* ((temp-dir (make-temp-file "e-unit-isolated" t))
         (temp-file nil)
         (output nil))
    (unwind-protect
        (progn
          (setq temp-file (expand-file-name "isolated-test.el" temp-dir))
          ;; Write test code to temp file
          (with-temp-file temp-file
            (insert "(require 'e-unit)\n")
            (insert test-code))

          ;; Run in subprocess and capture output
          (let* ((e-unit-dir (file-name-directory (locate-library "e-unit")))
                 (reporter-setup (if reporter-type
                                   (format "(e-unit-set-reporter (quote %s)%s)"
                                          reporter-type
                                          (if reporter-options
                                              (format " %s" reporter-options)
                                            ""))
                                 ""))
                 (command (format "emacs -batch -Q -L %s -l e-unit --eval \"(progn (e-unit-initialize) %s (find-file \\\"%s\\\") (eval-buffer) (e-unit-run-buffer))\""
                                 e-unit-dir reporter-setup temp-file)))
            (setq output (shell-command-to-string command))))

      ;; Cleanup
      (when (and temp-file (file-exists-p temp-file))
        (delete-file temp-file))
      (when (file-directory-p temp-dir)
        (delete-directory temp-dir)))

    output))

;;; Default reporter setup
(defun e-unit--ensure-default-reporter ()
  "Ensure at least one reporter is active."
  (unless e-unit--active-reporters
    (e-unit-set-reporter 'console)))

;;; Autoload testing support

(defun e-unit--extract-function-calls (form)
  "Extract function call symbols from FORM.
Returns a list of symbols that appear in function call position."
  (let (result)
    (when (consp form)
      (let ((head (car form)))
        (cond
         ;; Skip quoted forms entirely
         ((eq head 'quote)
          nil)
         ;; Handle let/let* specially - extract from bindings and body
         ((memq head '(let let*))
          (let ((bindings (cadr form))
                (body (cddr form)))
            ;; Extract from binding value forms
            (dolist (binding bindings)
              (when (and (consp binding) (consp (cadr binding)))
                (setq result (append (e-unit--extract-function-calls (cadr binding)) result))))
            ;; Extract from body
            (dolist (body-form body)
              (setq result (append (e-unit--extract-function-calls body-form) result)))))
         ;; Normal function call
         (t
          (when (symbolp head)
            (push head result))
          (dolist (subform (cdr form))
            (when (consp subform)
              (setq result (append (e-unit--extract-function-calls subform) result))))))))
    result))

(defun e-unit--parse-autoloads-file (file)
  "Parse FILE and return list of autoloaded symbols."
  (let (result)
    (with-temp-buffer
      (insert-file-contents file)
      (goto-char (point-min))
      (while (re-search-forward "^(autoload '" nil t)
        (let ((symbol (read (current-buffer))))
          (push symbol result))))
    result))

(defmacro e-unit-deftest-autoload (name _params &rest body)
  "Define an autoload test named NAME.
BODY contains the test code that will run in a subprocess
with only autoloads loaded.

Functions called in BODY are automatically detected and verified
to be properly autoloaded before the test runs."
  (declare (indent 2))
  (let ((docstring (when (stringp (car body)) (pop body))))
    `(progn
       (defun ,name ()
         ,@(when docstring (list docstring))
         ,@body)
       (e-unit--register-autoload-test ',name ,docstring ',body))))

(defun e-unit--register-autoload-test (name docstring body)
  "Register autoload test NAME with DOCSTRING and BODY."
  (let* ((current-file (or load-file-name buffer-file-name "unknown-file"))
         (extracted-calls (e-unit--extract-function-calls (cons 'progn body)))
         (info (list :name name
                     :docstring docstring
                     :file current-file
                     :line 1
                     :autoload t
                     :extracted-calls extracted-calls
                     :body body
                     :context (copy-sequence e-unit--context-stack))))
    ;; Remove any existing test with same name from the same file
    (setq e-unit--tests (cl-remove-if (lambda (test)
                                        (and (eq (plist-get test :name) name)
                                             (equal (plist-get test :file) current-file)))
                                      e-unit--tests))
    ;; Add new test
    (push info e-unit--tests)))

(defun e-unit--find-function-definition (symbol source-dir)
  "Find where SYMBOL is defined in SOURCE-DIR.
Returns plist with :file and :line, or nil if not found."
  (let ((pattern (format "^(def\\(?:un\\|macro\\|var\\|const\\)\\s-+%s\\b"
                         (regexp-quote (symbol-name symbol))))
        result)
    (dolist (file (directory-files source-dir t "\\.el$"))
      (when (and (not result) (file-regular-p file))
        (with-temp-buffer
          (insert-file-contents file)
          (goto-char (point-min))
          (when (re-search-forward pattern nil t)
            (setq result (list :file file
                               :line (line-number-at-pos)))))))
    result))

(defun e-unit--diagnose-autoload-failure (symbol source-dir)
  "Generate diagnostic message for SYMBOL not being autoloaded.
Searches SOURCE-DIR for the function definition."
  (let ((location (e-unit--find-function-definition symbol source-dir)))
    (if location
        (format "%s is not autoloaded\n  Defined in: %s:%d\n  No ;;;###autoload cookie found\n  Suggestion: Add ;;;###autoload before the definition"
                symbol
                (file-name-nondirectory (plist-get location :file))
                (plist-get location :line))
      (format "%s is not autoloaded and not found in source files"
              symbol))))

(defun e-unit--verify-autoloads (extracted-calls autoloads-file source-dir)
  "Verify that EXTRACTED-CALLS are properly autoloaded.
AUTOLOADS-FILE is parsed to get the list of autoloaded symbols.
SOURCE-DIR is used for diagnostics.
Returns plist with :missing (list of missing symbols) and :diagnostics."
  (let* ((autoloaded-symbols (e-unit--parse-autoloads-file autoloads-file))
         (missing nil)
         (diagnostics nil))
    ;; Check each extracted call
    (dolist (call extracted-calls)
      ;; Only check symbols that look like they belong to the package
      ;; (symbols defined in source-dir)
      (when (e-unit--find-function-definition call source-dir)
        (unless (member call autoloaded-symbols)
          (push call missing)
          (push (e-unit--diagnose-autoload-failure call source-dir) diagnostics))))
    (list :missing (nreverse missing)
          :diagnostics (nreverse diagnostics))))

(defun e-unit--compat-generate-autoloads (source-dir output-file)
  "Generate autoloads from SOURCE-DIR into OUTPUT-FILE.
Uses `loaddefs-generate' on Emacs 29+, `make-directory-autoloads' on Emacs 28."
  (if (fboundp 'loaddefs-generate)
      (loaddefs-generate source-dir output-file)
    ;; Emacs 28 fallback
    (make-directory-autoloads source-dir output-file)))

(defun e-unit--generate-autoloads (source-dir)
  "Generate autoloads for SOURCE-DIR and return the autoloads file path."
  (let* ((pkg-name (or e-unit-autoload-package-name
                       (file-name-nondirectory (directory-file-name source-dir))))
         (autoloads-file (expand-file-name
                          (concat pkg-name "-autoloads.el")
                          source-dir)))
    (e-unit--compat-generate-autoloads source-dir autoloads-file)
    autoloads-file))

(defun e-unit-run-autoload-tests (&optional directory)
  "Run all autoload tests for DIRECTORY (default: current directory).
Generates autoloads, then runs each autoload test in a fresh subprocess."
  (interactive)
  (let* ((dir (or directory default-directory))
         (source-dirs (or e-unit-autoload-source-dirs (list dir)))
         (autoloads-file (e-unit--generate-autoloads (car source-dirs)))
         (e-unit--include-autoload-tests t)
         (autoload-tests (cl-remove-if-not
                          (lambda (test) (plist-get test :autoload))
                          e-unit--tests))
         (results nil))
    ;; Run each autoload test in subprocess
    (dolist (test autoload-tests)
      (let* ((test-name (plist-get test :name))
             (test-body (plist-get test :body))
             (result (e-unit--run-autoload-test-subprocess
                      autoloads-file
                      (car source-dirs)
                      (cons 'progn test-body))))
        (push (list :name test-name
                    :passed (plist-get result :passed)
                    :error (plist-get result :error)
                    :output (plist-get result :output))
              results)))
    (nreverse results)))

(defun e-unit--run-autoload-test-subprocess (autoloads-file source-dir test-body)
  "Run TEST-BODY in subprocess with only AUTOLOADS-FILE loaded.
SOURCE-DIR is added to load-path so autoloads can find source files.
Returns plist with :passed, :error, and :output keys."
  (let* ((e-unit-dir (file-name-directory (locate-library "e-unit")))
         (test-code (prin1-to-string
                     `(progn
                        (require 'e-unit)
                        (e-unit-initialize)
                        (condition-case err
                            (progn
                              ,@(if (and (consp test-body) (eq (car test-body) 'progn))
                                    (cdr test-body)
                                  (list test-body))
                              (princ "AUTOLOAD-TEST-PASSED"))
                          (error
                           (princ (format "AUTOLOAD-TEST-FAILED: %S" err)))))))
         (command (format "emacs -batch -Q -L %s -L %s -l %s -l e-unit --eval %s"
                          (shell-quote-argument e-unit-dir)
                          (shell-quote-argument source-dir)
                          (shell-quote-argument autoloads-file)
                          (shell-quote-argument test-code)))
         (output (shell-command-to-string command)))
    (cond
     ((string-match "AUTOLOAD-TEST-PASSED" output)
      (list :passed t :output output))
     ((string-match "AUTOLOAD-TEST-FAILED: \\(.+\\)" output)
      (list :passed nil :error (match-string 1 output) :output output))
     (t
      (list :passed nil :error "Unknown error" :output output)))))

;;; e-unit.el ends here
