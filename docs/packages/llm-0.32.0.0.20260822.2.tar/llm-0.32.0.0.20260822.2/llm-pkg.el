;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.0.0.20260822.2"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "90e67fc4dfe3fae5b00e7cf6bb68137ac8c441a1"
  :revdesc "90e67fc4dfe3"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
