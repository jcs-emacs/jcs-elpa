;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.1.0.20260920.1"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "9ac4111020babe5996c87ddb60d62b9cfcea28c1"
  :revdesc "9ac4111020ba"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
