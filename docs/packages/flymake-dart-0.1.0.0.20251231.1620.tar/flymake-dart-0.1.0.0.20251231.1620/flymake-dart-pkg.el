;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-dart" "0.1.0.0.20251231.1620"
  "Flymake support for dart analyze."
  '((emacs        "26.1")
    (flymake-easy "0.1"))
  :url "https://github.com/flymake/flymake-dart"
  :commit "fa2014864112c71f07141ad7c2143243ff16f3e2"
  :revdesc "fa2014864112"
  :keywords '("tools")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
