;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helafy" "0.1.0.0.20260101.26"
  "Minify/Uglify/Prettify contents."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/helafy"
  :commit "8c03b293e64a4d000a66322a00ee4c8a21ecce47"
  :revdesc "8c03b293e64a"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
