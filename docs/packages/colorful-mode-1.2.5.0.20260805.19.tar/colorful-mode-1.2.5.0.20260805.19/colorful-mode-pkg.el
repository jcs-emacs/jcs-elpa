;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.5.0.20260805.19"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "31")
    (cl-lib "1.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "6712e9c969bfa8fc8538a0c1bd57a8ef9f974780"
  :revdesc "6712e9c969bf"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
