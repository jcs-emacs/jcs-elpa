;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-mode" "20260219.1744"
  "Major mode for the LLVM assembler language."
  '((emacs "24.3"))
  :url "http://llvm.org/"
  :commit "680b56aa4b426253d1320e309e14534825b20774"
  :revdesc "680b56aa4b42")
