;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260501.1446"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "4ef511ad1ce11539e3848edf8a2f0ef439506c01"
  :revdesc "4ef511ad1ce1"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
