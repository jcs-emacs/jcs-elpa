;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-tags" "0.1.0.0.20260101.51"
  "Retrieve tags information through GitHub API."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/github-tags"
  :commit "11e3d032da682d29b91e1d8aad887cbfd769aac7"
  :revdesc "11e3d032da68"
  :keywords '("vc" "github" "tags")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
