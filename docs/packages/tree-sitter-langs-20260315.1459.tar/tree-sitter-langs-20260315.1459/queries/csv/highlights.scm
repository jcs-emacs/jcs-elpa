; inherits: tsv

"," @punctuation.delimiter
