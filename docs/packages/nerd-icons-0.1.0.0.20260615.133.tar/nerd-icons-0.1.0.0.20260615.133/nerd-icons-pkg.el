;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "0.1.0.0.20260615.133"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "2d45867a1083a21f0a087959df6ba97821e06186"
  :revdesc "2d45867a1083"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
