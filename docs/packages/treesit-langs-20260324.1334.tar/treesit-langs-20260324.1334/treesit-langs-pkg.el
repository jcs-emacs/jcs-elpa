;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260324.1334"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "1002731283274480beeade55bc314d8983146c8a"
  :revdesc "100273128327"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
