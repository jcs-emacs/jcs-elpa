;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260530.2"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "ac276f982afe0ee54b2a2cba75c8bee156fbd92c"
  :revdesc "ac276f982afe"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
