;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-case-style" "0.1.0.0.20260101.26"
  "Cycle through case style (PascalCase, camelCase, etc)."
  '((emacs       "28.1")
    (change-case "9"))
  :url "https://github.com/jcs-elpa/cycle-case-style"
  :commit "23d8e0cdd2831cca1296d62473518ff849c6fd4e"
  :revdesc "23d8e0cdd283"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
