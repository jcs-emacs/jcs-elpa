;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellsp" "20260503.1228"
  "Elisp Language Server."
  '((emacs    "29.1")
    (lsp-mode "6.0.1")
    (log4e    "0.1.0")
    (dash     "2.14.1")
    (s        "1.12.0")
    (company  "0.8.12")
    (msgu     "0.1.0"))
  :url "https://github.com/elisp-lsp/Ellsp"
  :commit "2a6a359cf15a09c9aafeb3781f1dfed1944d2a5f"
  :revdesc "2a6a359cf15a"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
