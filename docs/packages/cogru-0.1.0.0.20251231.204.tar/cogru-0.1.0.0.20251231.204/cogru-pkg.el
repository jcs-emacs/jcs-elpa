;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cogru" "0.1.0.0.20251231.204"
  "Cogru plugin for real-time collaborative editing."
  '((emacs       "28.1")
    (elenv       "0.1.0")
    (msgu        "0.1.0")
    (s           "1.12.0")
    (ht          "2.0")
    (log4e       "0.4.1")
    (posframe    "1.4.3")
    (named-timer "0.1")
    (show-eol    "0.0.5"))
  :url "https://github.com/Cogru/cogru.el"
  :commit "d2ea28bc35de7b17752c891c2fd8af83bae5e7dd"
  :revdesc "d2ea28bc35de"
  :keywords '("convenience" "cogru")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
