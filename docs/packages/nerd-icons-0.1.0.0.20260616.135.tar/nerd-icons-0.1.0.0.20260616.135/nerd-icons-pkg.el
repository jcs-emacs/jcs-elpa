;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "0.1.0.0.20260616.135"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "a1d33ee76d33fa5cd61b36b0de5d56b822fcd09e"
  :revdesc "a1d33ee76d33"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
