;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vsc-edit-mode" "0.1.0.0.20260202.626"
  "Implement editing experience like VSCode."
  '((emacs          "26.1")
    (indent-control "0.1.0")
    (company        "0.8.12")
    (yasnippet      "0.8.0")
    (msgu           "0.1.0")
    (mwim           "0.4"))
  :url "https://github.com/emacs-vs/vsc-edit-mode"
  :commit "68fdde8e9a829867f45d060a86e5e23f76be9789"
  :revdesc "68fdde8e9a82"
  :keywords '("convenience" "editing" "vs")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
