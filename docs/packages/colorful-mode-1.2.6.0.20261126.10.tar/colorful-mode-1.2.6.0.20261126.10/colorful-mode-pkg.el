;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.6.0.20261126.10"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "31")
    (seq    "2"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "2f42b8fdfb94f052162a7c5496089077e0e8da1e"
  :revdesc "2f42b8fdfb94"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
