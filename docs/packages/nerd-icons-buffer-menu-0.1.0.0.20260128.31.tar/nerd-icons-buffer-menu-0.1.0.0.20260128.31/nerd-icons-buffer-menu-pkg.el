;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-buffer-menu" "0.1.0.0.20260128.31"
  "Display nerd icons in `buffer-menu'."
  '((emacs      "26.1")
    (nerd-icons "0.0.1")
    (noflet     "0.0.15")
    (msgu       "0.1.0"))
  :url "https://github.com/jcs-elpa/nerd-icons-buffer-menu"
  :commit "8e6b13584e91496a208d514549cd410c8aa7ce26"
  :revdesc "8e6b13584e91"
  :keywords '("frames")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
