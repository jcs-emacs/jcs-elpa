;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260318.2345"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "1e86212784198f6d3185d712dd6b724601052118"
  :revdesc "1e8621278419"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
