;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.7.0.0.20260704.13"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "fa0b29a6a87b33924d0132c54323f7f4495fa40d"
  :revdesc "fa0b29a6a87b"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
