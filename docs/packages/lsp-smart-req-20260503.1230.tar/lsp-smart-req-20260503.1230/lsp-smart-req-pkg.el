;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-smart-req" "20260503.1230"
  "Lazy load LSP packages."
  '((emacs "29.1"))
  :url "https://github.com/jcs-elpa/lsp-smart-req"
  :commit "2316b59f186241ce6adf7d56d2817e44b8c7cc0c"
  :revdesc "2316b59f1862"
  :keywords '("internal" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
