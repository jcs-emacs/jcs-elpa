;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "breadcrumb" "1.0.1.0.20260802.16"
  "Project and imenu-based breadcrumb paths."
  '((emacs   "28.1")
    (project "0.9.8"))
  :url "https://github.com/joaotavora/breadcrumb"
  :commit "6f11e36b5e334160c6b3ac7272b701d88443a8f5"
  :revdesc "6f11e36b5e33"
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
