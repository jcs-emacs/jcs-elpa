;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.33.0.0.20261009.1"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "1e1c716d78286e8842afa0aa0a9e9cb06373457e"
  :revdesc "1e1c716d7828"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
