;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dart" "0.1.0.0.20251231.1618"
  "Flycheck for dart analyze."
  '((emacs     "27.1")
    (flycheck  "0.22")
    (dart-mode "0.11"))
  :url "https://github.com/flycheck/flycheck-dart"
  :commit "d5b8aa91358c0e9021b7a8adf7d88a1898404013"
  :revdesc "d5b8aa91358c"
  :keywords '("tools")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
