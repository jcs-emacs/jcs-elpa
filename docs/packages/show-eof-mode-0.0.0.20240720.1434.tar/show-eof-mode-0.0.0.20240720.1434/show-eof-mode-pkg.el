;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-eof-mode" "0.0.0.20240720.1434"
  "[No description available]."
  ()
  :url "https://github.com/zk-phi/show-eof-mode"
  :commit "cb1881df257ff8fb96478829ba14c0d94dc94667"
  :revdesc "cb1881df257f")
