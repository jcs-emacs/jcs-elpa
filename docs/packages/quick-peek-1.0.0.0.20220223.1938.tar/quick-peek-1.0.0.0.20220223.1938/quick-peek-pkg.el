;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-peek" "1.0.0.0.20220223.1938"
  "Inline quick-peek windows."
  '((emacs "24.3"))
  :url "https://github.com/emacs-vs/quick-peek"
  :commit "5eadb029d2e3abe92de54a995fb00ee425bf9bf8"
  :revdesc "5eadb029d2e3"
  :keywords '("tools" "help" "doc" "convenience")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
