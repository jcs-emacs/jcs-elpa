;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meta-net" "1.1.0.0.20260101.549"
  "Parse .NET assembly's XML."
  '((emacs "25.1")
    (ht    "2.3")
    (f     "0.20.0")
    (s     "1.12.0"))
  :url "https://github.com/emacs-vs/meta-net"
  :commit "d4025869ff051fce9bf480fa2777ae71d9772791"
  :revdesc "d4025869ff05"
  :keywords '("convenience" "assembly" "xml" "utility")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
