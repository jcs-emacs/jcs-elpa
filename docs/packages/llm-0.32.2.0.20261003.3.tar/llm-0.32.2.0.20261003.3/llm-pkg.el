;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.2.0.20261003.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "de02e0d32131b51b47759bcd411ce1f8f8df2450"
  :revdesc "de02e0d32131"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
