;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260429.1411"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "796e12fab8f01eaa515f14f43f3f46e2f1671fde"
  :revdesc "796e12fab8f0"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
