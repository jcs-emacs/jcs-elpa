;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260303.1459"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion"
  :commit "13255c4ad1276ebb0c92fb20d2823bd693124787"
  :revdesc "13255c4ad127"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
