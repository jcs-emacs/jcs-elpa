;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wat-mode" "1.0.0.0.20220713.251"
  "A major mode for WebAssembly."
  ()
  :url "https://github.com/devonsparks/wat-mode"
  :commit "46b4df83e92c585295d659d049560dbf190fe501"
  :revdesc "46b4df83e92c"
  :authors '(("Devon Sparks" . "devon.sparks@gmail.com"))
  :maintainers '(("Devon Sparks" . "devon.sparks@gmail.com")))
