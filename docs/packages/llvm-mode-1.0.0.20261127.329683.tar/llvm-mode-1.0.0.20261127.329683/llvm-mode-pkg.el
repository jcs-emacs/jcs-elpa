;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-mode" "1.0.0.20261127.329683"
  "Major mode for the LLVM assembler language."
  '((emacs "24.3"))
  :url "http://llvm.org/"
  :commit "6c38085b39bb1b994856783d49d3bafad59a497c"
  :revdesc "6c38085b39bb")
