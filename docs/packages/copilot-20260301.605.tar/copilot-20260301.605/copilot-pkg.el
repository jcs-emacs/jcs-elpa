;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260301.605"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "58a01a24d4330189e4ba8fa76ec5e87abfff9262"
  :revdesc "58a01a24d433"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
