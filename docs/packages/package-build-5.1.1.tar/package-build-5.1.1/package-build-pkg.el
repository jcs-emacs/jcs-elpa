;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.1.1"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "a929f89d006e0c3dbe68c21f9dae2076ce1071bc"
  :revdesc "v5.1.1-0-ga929f89d006e"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
