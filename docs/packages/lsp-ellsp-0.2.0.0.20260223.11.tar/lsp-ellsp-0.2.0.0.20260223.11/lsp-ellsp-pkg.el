;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ellsp" "0.2.0.0.20260223.11"
  "LSP Clients for Ellsp."
  '((emacs    "28.1")
    (lsp-mode "6.1"))
  :url "https://github.com/elisp-lsp/lsp-ellsp"
  :commit "172299b8d211344e3c7865d6efa0cf1a1bdf15a1"
  :revdesc "172299b8d211"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
