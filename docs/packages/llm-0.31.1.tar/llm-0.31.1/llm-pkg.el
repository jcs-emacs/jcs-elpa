;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.1"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "34ac61091994c10bda45eed54433a1a87ca26af1"
  :revdesc "34ac61091994"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
