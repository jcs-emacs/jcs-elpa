![https://img.shields.io/github/tag/${github-user-name}/${github-repo-name}.svg?style=flat-square](https://github.com/Kyure-A/el-project)
![https://img.shields.io/github/license/${github-user-name}/${github-repo-name}.svg?style=flat-square](file:LICENSE)
![https://img.shields.io/codecov/c/github/${github-user-name}/${github-repo-name}.svg?style=flat-square](https://codecov.io/gh/Kyure-A/el-project?branch=master)
![https://img.shields.io/github/actions/workflow/status/${github-user-name}/${github-repo-name}/test.yml.svg?branch=master&style=flat-square](https://github.com/Kyure-A/el-project/actions)
# ${project-name}: ${project-short-description}

## Usage
## License
This package is licensed by The GNU General Public License verson 3 or later. See [[file:LICENSE][LICENSE]].
