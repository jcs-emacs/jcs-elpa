;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-preproc" "0.1.0.0.20260101.549"
  "Unhighlight invalid preprocessor region."
  '((emacs    "24.4")
    (meta-net "1.1.0"))
  :url "https://github.com/emacs-vs/hl-preproc"
  :commit "2b196be632871a5e30de056eb7460dbdb902fdeb"
  :revdesc "2b196be63287"
  :keywords '("convenience" "preprocessor")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
