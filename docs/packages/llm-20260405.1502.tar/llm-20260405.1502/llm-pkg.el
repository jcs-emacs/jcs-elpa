;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260405.1502"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "e233d45ac37082d1dab8ef2a387cdf0c609fbad5"
  :revdesc "e233d45ac370"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
