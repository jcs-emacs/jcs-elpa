;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "0.1.0.0.20260503.1838"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "0377676efd27c1752ec811abe01a8b3b110efcce"
  :revdesc "0377676efd27"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
