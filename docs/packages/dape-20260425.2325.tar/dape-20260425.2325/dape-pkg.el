;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260425.2325"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "0b89094a99ffb219630ba1f5b7b07c67f919269c"
  :revdesc "0b89094a99ff"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
