;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-smart-req" "20260221.1346"
  "Lazy load LSP packages."
  '((emacs "27.1"))
  :url "https://github.com/jcs-elpa/lsp-smart-req"
  :commit "46a9293f1705283e77d1251ecdbf5faafc94a3da"
  :revdesc "46a9293f1705"
  :keywords '("internal" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
