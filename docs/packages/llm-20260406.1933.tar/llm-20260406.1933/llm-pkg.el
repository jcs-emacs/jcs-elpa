;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260406.1933"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "a861b8a2731867753472fbe5c4c410423e958141"
  :revdesc "a861b8a27318"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
