;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.33.0.0.20261011.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "3177fdb12136e899b26b9e7835549f920718bf4f"
  :revdesc "3177fdb12136"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
