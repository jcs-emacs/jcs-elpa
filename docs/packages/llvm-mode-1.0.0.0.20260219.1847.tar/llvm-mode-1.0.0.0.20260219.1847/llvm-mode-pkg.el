;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-mode" "1.0.0.0.20260219.1847"
  "Major mode for the LLVM assembler language."
  '((emacs "24.3"))
  :url "http://llvm.org/"
  :commit "d5b6b465ff87d8a233cfe50dc5d01a873c560b37"
  :revdesc "d5b6b465ff87")
