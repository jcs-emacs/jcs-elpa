;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "change-case" "9.0.20260123.8"
  "Case conversion between camelCase, PascalCase, snake_case and more."
  '((emacs "25.1")
    (dash  "2.16.0")
    (s     "1.12.0"))
  :url "https://github.com/TakesxiSximada/change-case.el"
  :commit "a05089d98efe1d60944de5b422c4252788d77e83"
  :revdesc "a05089d98efe"
  :authors '(("TakesxiSximada" . "8707279+TakesxiSximada@users.noreply.github.com"))
  :maintainers '(("TakesxiSximada" . "8707279+TakesxiSximada@users.noreply.github.com")))
