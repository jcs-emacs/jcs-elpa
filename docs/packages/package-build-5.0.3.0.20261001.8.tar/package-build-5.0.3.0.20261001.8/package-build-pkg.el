;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.0.3.0.20261001.8"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "f14ec4452977e6be7d5de58637a7d8df6ed87edc"
  :revdesc "v5.0.3-8-gf14ec4452977"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
