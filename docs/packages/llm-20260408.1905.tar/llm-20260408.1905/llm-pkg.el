;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260408.1905"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "03ee7c5c7ecbedfce73e87be122fd078e12fa683"
  :revdesc "03ee7c5c7ecb"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
