;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "odin-mode" "0.0.0.20260219.54"
  "A minor mode for odin."
  '((emacs "24.1"))
  :url "https://github.com/glassofethanol/odin-mode"
  :commit "21c6ff8b49f5eaa2d3b9969feeb08de921f11e92"
  :revdesc "21c6ff8b49f5"
  :keywords '("odin" "language" "languages" "mode"))
