;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "block-travel" "0.1.0.0.20260101.548"
  "Move to previous/next blank line."
  '((emacs "26.1"))
  :url "https://github.com/emacs-vs/block-travel"
  :commit "1be79b38c4b19f59fba482688a71c86e6bc85814"
  :revdesc "1be79b38c4b1"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
