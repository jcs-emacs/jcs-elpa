;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.7.0.0.20260703.7"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "31b882bd27844ef10ab2f8d55282009cfa6bfe36"
  :revdesc "31b882bd2784"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
