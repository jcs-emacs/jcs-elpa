;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-move" "0.6.2.0.20240101.38"
  "Easily swap buffers."
  '((emacs "24.1"))
  :url "https://github.com/elp-revive/buffer-move/"
  :commit "d20de0065695ee815f1c17cf2de527d6e9a7bbf1"
  :revdesc "d20de0065695"
  :keywords '("convenience")
  :authors '(("Lucas Bonnet" . "lucas@rincevent.net")
             ("Mathis Hofer" . "mathis@fsfe.org")
             ("Geyslan G. Bem" . "geyslan@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
