;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260428.132"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "e00e634be61cab619458652795d36f452a9b6741"
  :revdesc "e00e634be61c"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
