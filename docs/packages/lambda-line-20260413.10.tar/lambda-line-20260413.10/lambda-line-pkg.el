;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambda-line" "20260413.10"
  "A custom status line."
  '((emacs "27.1"))
  :url "https://github.com/Lambda-Emacs/lambda-line"
  :commit "0ca6b32b591f6201c342d6c5ef14577aea7cfb49"
  :revdesc "0ca6b32b591f"
  :keywords '("mode-line" "faces"))
