;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "0.1.0.0.20260616.136"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "72d97a68e7de4c411e5804ee944bec0b7515f1f6"
  :revdesc "72d97a68e7de"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
