;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "punch-line" "1.0.0.20261111.64"
  "A customizeable mode-line with Evil."
  '((emacs      "28.1")
    (async      "1.9")
    (nerd-icons "0.0.1"))
  :url "https://github.com/konrad1977/punch-line"
  :commit "971e90ff14a57d199d7a5dc2964fc52f03ed83db"
  :revdesc "971e90ff14a5"
  :keywords '("mode-line" "faces"))
