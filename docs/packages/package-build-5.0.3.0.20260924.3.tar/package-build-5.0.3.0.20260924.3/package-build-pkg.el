;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.0.3.0.20260924.3"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "292a18aadaf727a0ce967c3c064fb78b3986b1d7"
  :revdesc "v5.0.3-3-g292a18aadaf7"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
