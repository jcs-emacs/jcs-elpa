;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260406.517"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "b481870ef939d13d3fe895f474f433e9a0d3141e"
  :revdesc "b481870ef939"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
