;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack-mode" "1.0.0.0.20231022.6"
  "Major mode for Jack language."
  '((emacs "27.1"))
  :url "https://github.com/nverno/jack-mode"
  :commit "4db6d97017e82eeb46777eb0ae8e33a2a6cac192"
  :revdesc "4db6d97017e8"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
