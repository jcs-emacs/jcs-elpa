;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-copilot" "0.1.0.20230412.4"
  "Copilot integration with EGLOT and Company."
  '((emacs           "28.2")
    (f               "0.20.0")
    (bash-completion "3.1.0")
    (projectile      "2.6.0-snapshot")
    (s               "1.12.0")
    (company         "0.9.13")
    (eglot-copilot   "0.1")
    (dash            "2.19.1")
    (ht              "2.4"))
  :url "https://github.com/tyler-dodge/eglot-copilot"
  :commit "1fb665fcd5dd7416ef19a4ef00e419265b186ccf"
  :revdesc "1fb665fcd5dd"
  :keywords '("convenience")
  :authors '(("Tyler Dodge" . "(tyler@tdodge.consulting)"))
  :maintainers '(("Tyler Dodge" . "(tyler@tdodge.consulting)")))
