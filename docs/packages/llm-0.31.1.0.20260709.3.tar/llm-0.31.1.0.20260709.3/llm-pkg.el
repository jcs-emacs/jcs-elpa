;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.1.0.20260709.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "2fe1f99a51e66c1f50e2c0b603b949783b9320f0"
  :revdesc "2fe1f99a51e6"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
