;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-project" "1.1.1.0.20240228.3"
  "Generate project skeleton for Emacs Lisp."
  '((emacs "24.1")
    (f     "0.20.0")
    (s     "1.13.1"))
  :url "https://github.com/Kyure-A/el-project"
  :commit "83899ae63545a772cacb171533759a3823fac6da"
  :revdesc "83899ae63545"
  :keywords '("tools")
  :authors '(("Kyure_A" . "twitter.com/kyureq"))
  :maintainers '(("Kyure_A" . "twitter.com/kyureq")))
