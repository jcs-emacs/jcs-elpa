;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260302.949"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "a58ecaebec6dc1597082d7f69c03d7bfb966632a"
  :revdesc "a58ecaebec6d"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
