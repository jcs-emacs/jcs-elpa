;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260304.2011"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "9b1a2b5880b6ae574c076db5ecffe420930d9da4"
  :revdesc "9b1a2b5880b6"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
