;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.7.0.0.20260704.32"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "862a5e0900e5884302c836e5b4fd1ed515456c7e"
  :revdesc "862a5e0900e5"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
