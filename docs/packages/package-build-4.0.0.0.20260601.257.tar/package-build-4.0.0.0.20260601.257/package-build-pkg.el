;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "4.0.0.0.20260601.257"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/melpa/package-build"
  :commit "910d0a813183c9a7cda1026cf39900a441cf856c"
  :revdesc "4.0.0-257-g910d0a813183"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
