;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "msgu" "0.1.0.0.20260101.601"
  "Utility functions help output the messages."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/msgu"
  :commit "68abe654c82e16b7f90e05cc8be7c087a1707712"
  :revdesc "68abe654c82e"
  :keywords '("lisp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
