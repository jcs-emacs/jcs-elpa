;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260407.1757"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "a5d5c82be40a9adb6377bddebb0004348e292853"
  :revdesc "a5d5c82be40a"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
