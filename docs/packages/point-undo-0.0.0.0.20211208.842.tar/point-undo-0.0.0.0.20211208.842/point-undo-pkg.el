;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "point-undo" "0.0.0.0.20211208.842"
  "Undo/redo position."
  ()
  :url "https://github.com/ncaq/point-undo"
  :commit "971efe20e3ef5764587168c5510c4b65406aca02"
  :revdesc "971efe20e3ef")
