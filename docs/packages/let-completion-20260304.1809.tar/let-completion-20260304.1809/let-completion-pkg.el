;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260304.1809"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion"
  :commit "319887ef3b99b94d11de7abf16acf5fd8934c621"
  :revdesc "319887ef3b99"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
