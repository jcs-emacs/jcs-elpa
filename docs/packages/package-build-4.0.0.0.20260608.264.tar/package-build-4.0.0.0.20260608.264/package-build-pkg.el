;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "4.0.0.0.20260608.264"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/melpa/package-build"
  :commit "c072cbce615501bfeffdfcf7d05eecf5f11534a4"
  :revdesc "4.0.0-264-gc072cbce6155"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
