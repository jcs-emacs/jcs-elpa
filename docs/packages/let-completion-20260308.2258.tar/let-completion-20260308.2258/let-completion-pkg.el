;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "let-completion" "20260308.2258"
  "Show let-binding values in Elisp completion."
  '((emacs "28.1"))
  :url "https://github.com/gggion/let-completion.el"
  :commit "491edec864d9120ccdaaa20a903d0cf5da67f9be"
  :revdesc "491edec864d9"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
