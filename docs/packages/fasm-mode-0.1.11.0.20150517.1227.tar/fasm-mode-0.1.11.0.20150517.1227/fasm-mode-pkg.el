;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fasm-mode" "0.1.11.0.20150517.1227"
  "Fasm major mode."
  ()
  :url "https://github.com/Fanael/fasm-mode"
  :commit "cb4b9bf48c7f05530e140456eb1f4a54716470f9"
  :revdesc "cb4b9bf48c7f"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
