;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260425.1733"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "4e4321370f462c4170815b881a39776cd0c66cdc"
  :revdesc "4e4321370f46"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
