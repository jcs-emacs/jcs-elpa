;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260425.1655"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "d77a5b4e6b0fb80ace81e15149ad7ccb965b174f"
  :revdesc "d77a5b4e6b0f"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
