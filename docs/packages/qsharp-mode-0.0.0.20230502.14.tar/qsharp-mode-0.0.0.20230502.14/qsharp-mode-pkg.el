;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qsharp-mode" "0.0.0.20230502.14"
  "Programming mode for the Q# language."
  '((emacs "24.1"))
  :url "https://github.com/forked-from-1kasper/emacs-qsharp-mode"
  :commit "402bf231c823776480323c00a3dba85f9467e0cf"
  :revdesc "402bf231c823"
  :keywords '("languages" "q#" "quantum")
  :authors '(("Siegmentation Fault" . "siegmentationfault@yandex.ru"))
  :maintainers '(("Siegmentation Fault" . "siegmentationfault@yandex.ru")))
