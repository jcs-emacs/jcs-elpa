;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.5.0.20260508.15"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "31")
    (cl-lib "1.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "97a1dc0b3ac6b2706ec3e2f428ea66aea2d91fb6"
  :revdesc "97a1dc0b3ac6"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
