;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-fold" "0.0.3"
  "Fold comint-input."
  '((emacs  "27.1")
    (compat "29.1.4.3"))
  :url "https://github.com/jdtsmith/comint-fold"
  :commit "0dd06663d4e666c20650c3556fe4985731dd600f"
  :revdesc "0dd06663d4e6"
  :keywords '("convenience"))
