;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "on" "0.1.0"
  "Hooks for faster startup."
  '((emacs "27.1"))
  :url "https://github.com/elp-revive/on.el"
  :commit "4ff6b2582b1c4c103a580bb681821b247686fc05"
  :revdesc "4ff6b2582b1c"
  :keywords '("convenience")
  :authors '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
