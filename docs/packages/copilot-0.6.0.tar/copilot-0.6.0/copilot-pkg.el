;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.6.0"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "2882a50182a6e2ca3b1ccfded22645831a85a59a"
  :revdesc "2882a50182a6"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
