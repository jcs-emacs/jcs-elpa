;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bars" "0.1.0.20211105.11"
  "Add bars to virtual indentation."
  '((emacs "27.1")
    (dash  "2.17.0")
    (s     "1.12.0"))
  :url "https://github.com/tonyaldon/org-bars"
  :commit "94c37f63fcfec9cdde6b99457b4dac5275589d95"
  :revdesc "94c37f63fcfe"
  :keywords '("outlines")
  :authors '(("Tony Aldon" . "tony.aldon.adm@gmail.com"))
  :maintainers '(("Tony Aldon" . "tony.aldon.adm@gmail.com")))
