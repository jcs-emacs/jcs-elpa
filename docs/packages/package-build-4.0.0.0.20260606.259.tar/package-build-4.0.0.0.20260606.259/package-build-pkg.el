;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "4.0.0.0.20260606.259"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/melpa/package-build"
  :commit "a94ca66f8fe3e8ba5b93451d5a4bf7c91ed8190a"
  :revdesc "4.0.0-259-ga94ca66f8fe3"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
