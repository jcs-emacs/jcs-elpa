;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.6.0.0.20260624.1"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "b8779fdfc9a4b828555a5b480480127db4c85da2"
  :revdesc "b8779fdfc9a4"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
