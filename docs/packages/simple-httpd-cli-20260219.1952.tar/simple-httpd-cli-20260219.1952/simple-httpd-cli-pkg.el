;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd-cli" "20260219.1952"
  "A command-line interface for simple-httpd."
  '((emacs        "26.1")
    (simple-httpd "1.5.1")
    (commander    "0.7.0")
    (msgu         "0.1.0"))
  :url "https://github.com/emacs-eine/simple-httpd-cli"
  :commit "4634537af929728600b82cffe5360c82b8f8b85f"
  :revdesc "4634537af929"
  :keywords '("convenience")
  :authors '(("JenChieh" . "jcs090218@gmail.com"))
  :maintainers '(("JenChieh" . "jcs090218@gmail.com")))
