;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-shader" "0.1.0.0.20251231.1653"
  "Eglot Clients for Shader."
  '((emacs "26.1")
    (eglot "1.4"))
  :url "https://github.com/shader-ls/eglot-shader"
  :commit "23b9f844410aa7451a6692cb00c86ffb06eabd4e"
  :revdesc "23b9f844410a"
  :keywords '("convenience" "shader")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
