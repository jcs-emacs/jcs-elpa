;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-company" "1.1.1"
  "Magik backend for company-mode."
  '((emacs      "29.1")
    (magik-mode "0.5.1")
    (company    "1.0.2")
    (yasnippet  "0.14.0"))
  :url "https://github.com/reinierkof/magik-company"
  :commit "f11e7054fc9038ab34eae1702bbc0fb30fa34246"
  :revdesc "f11e7054fc90"
  :keywords '("convenience")
  :authors '(("Reinier Koffijberg" . "reinierkof@gmail.com"))
  :maintainers '(("Reinier Koffijberg" . "reinierkof@gmail.com")))
