;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elenv" "0.2.0.0.20260203.1"
  "Environment variable management."
  '((emacs      "26.1")
    (msgu       "0.1.0")
    (s          "1.12.0")
    (list-utils "0.4.6"))
  :url "https://github.com/jcs-elpa/elenv"
  :commit "174898b931ef8f04c248effdfdb8cd7101386bb9"
  :revdesc "174898b931ef"
  :keywords '("maint")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
