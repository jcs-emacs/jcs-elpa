;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maple-line" "0.0.0.0.20200519.1557"
  "Maple line configuration."
  ()
  :url "https://github.com/honmaple/emacs-maple-line"
  :commit "266dae95df1d9e9394cc61e57f3b88327a79d6f5"
  :revdesc "266dae95df1d"
  :authors '(("lin.jiang" . "mail@honmaple.com"))
  :maintainers '(("lin.jiang" . "mail@honmaple.com")))
