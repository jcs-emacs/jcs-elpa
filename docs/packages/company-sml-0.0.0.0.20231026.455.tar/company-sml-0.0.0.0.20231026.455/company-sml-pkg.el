;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-sml" "0.0.0.0.20231026.455"
  "[No description available]."
  ()
  :url "https://github.com/nverno/company-sml"
  :commit "b586459c4d3b6b54081c6acc14d376ae3a854f2d"
  :revdesc "b586459c4d3b"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
