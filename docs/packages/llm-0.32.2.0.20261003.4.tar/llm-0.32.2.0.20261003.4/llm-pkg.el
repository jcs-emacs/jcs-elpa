;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.2.0.20261003.4"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "91b5632951e4a859bed1ecd7c9ed5abb47a71ad9"
  :revdesc "91b5632951e4"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
