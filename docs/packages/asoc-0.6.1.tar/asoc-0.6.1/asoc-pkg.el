;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asoc" "0.6.1"
  "Alist functions and macros."
  ()
  :url "https://github.com/troyp/asoc.el"
  :commit "4a3309a9f250656da6f4a9d34feedf4f5666b17a"
  :revdesc "4a3309a9f250"
  :keywords '("alist" "data-types")
  :authors '(("Troy Pracy" . "troyp7@gmail.com"))
  :maintainers '(("Troy Pracy" . "troyp7@gmail.com")))
