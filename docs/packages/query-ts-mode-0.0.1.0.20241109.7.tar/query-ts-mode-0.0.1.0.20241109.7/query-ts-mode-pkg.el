;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "query-ts-mode" "0.0.1.0.20241109.7"
  "Tree-sitter support for tree-sitter queries."
  '((emacs "29.1")
    (dash  "2.18.0"))
  :url "https://github.com/nverno/query-ts-mode"
  :commit "109b1c35c8f384809e3525c011a4bc664ff8884a"
  :revdesc "109b1c35c8f3"
  :keywords '("languages" "tree-sitter" "query")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
