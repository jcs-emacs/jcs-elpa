;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "point-undo" "0.0.0.20260513.523"
  "Undo/redo position."
  '((emacs "24.3"))
  :url "https://github.com/ncaq/point-undo"
  :commit "dd580a9f68ecab5718aba7c9132e3c9140f761f0"
  :revdesc "dd580a9f68ec")
