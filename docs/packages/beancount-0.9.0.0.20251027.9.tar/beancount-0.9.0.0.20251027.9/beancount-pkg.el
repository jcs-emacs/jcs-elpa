;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beancount" "0.9.0.0.20251027.9"
  "A major mode to edit Beancount input files."
  ()
  :url "https://github.com/beancount/beancount-mode"
  :commit "8a564f5a26e6245860188ebf71db0262dd78e068"
  :revdesc "8a564f5a26e6"
  :authors '(("Martin Blais" . "blais@furius.ca"))
  :maintainers '(("Martin Blais" . "blais@furius.ca")))
