;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.6.0.0.20260625.11"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "1eab7e7c466f6dbe269130b466f8b30d33f140b4"
  :revdesc "1eab7e7c466f"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
