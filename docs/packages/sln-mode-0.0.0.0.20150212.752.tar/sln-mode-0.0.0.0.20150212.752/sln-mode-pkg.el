;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sln-mode" "0.0.0.0.20150212.752"
  "A major-mode for msvc's *.sln files."
  ()
  :url "https://github.com/sensorflo/sln-mode"
  :commit "0f91d1b957c7d2a7bab9278ec57b54d57f1dbd9c"
  :revdesc "0f91d1b957c7"
  :keywords '("languages")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Florian Kaufmann" . "sensorflo@gmail.com")))
