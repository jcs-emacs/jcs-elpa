;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-langs" "0.13.59"
  "Grammar bundle for tree-sitter."
  '((emacs       "26.1")
    (tree-sitter "0.15.0"))
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs"
  :commit "5815f3b5db338d67c7e74c032bd2567bfd9ab4b0"
  :revdesc "5815f3b5db33"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
