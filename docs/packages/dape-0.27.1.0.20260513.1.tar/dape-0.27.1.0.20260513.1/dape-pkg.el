;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260513.1"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "9df3ea8db0206e58c245ed3a3cbabc37b01e7b55"
  :revdesc "9df3ea8db020"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
