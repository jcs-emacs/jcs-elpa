;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ellsp" "20260220.928"
  "LSP Clients for Ellsp."
  '((emacs    "28.1")
    (lsp-mode "6.1"))
  :url "https://github.com/elisp-lsp/lsp-ellsp"
  :commit "88ba379590d9b0829652c8def6024209e0ebe121"
  :revdesc "88ba379590d9"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
