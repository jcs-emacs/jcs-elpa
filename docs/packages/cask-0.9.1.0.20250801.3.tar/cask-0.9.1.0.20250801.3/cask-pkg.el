;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cask" "0.9.1.0.20250801.3"
  "Cask: Project management for package development."
  '((emacs   "25.3")
    (s       "1.8.0")
    (f       "0.16.0")
    (epl     "0.5")
    (shut-up "0.1.0")
    (cl-lib  "0.3")
    (ansi    "0.4.1"))
  :url "https://github.com/cask/cask"
  :commit "e04462801736fc1d76d979aedd7514663786892c"
  :revdesc "e04462801736"
  :keywords '("speed" "convenience")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
