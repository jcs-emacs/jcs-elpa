;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfmt" "0.0.0.0.20261108.67"
  "Code formatter for Elisp."
  '((emacs "24.3"))
  :url "https://github.com/riscy/elfmt"
  :commit "a7c344b9aa3b2b2852a2fcf014474f95765ac05b"
  :revdesc "a7c344b9aa3b"
  :keywords '("lisp")
  :authors '((nil . "https://github.com/riscy/elfmt/graphs/contributors"))
  :maintainers '(("Chris Rayner" . "dchrisrayner@gmail.com")))
