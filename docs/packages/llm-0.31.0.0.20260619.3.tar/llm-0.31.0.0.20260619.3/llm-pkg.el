;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.0.0.20260619.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "f7977825b6d91b525c4374480496421e667eeb37"
  :revdesc "f7977825b6d9"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
