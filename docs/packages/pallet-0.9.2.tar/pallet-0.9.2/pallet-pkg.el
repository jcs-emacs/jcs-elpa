;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pallet" "0.9.2"
  "Manage your packages with Cask."
  ()
  :url "https://github.com/rdallasgray/pallet"
  :commit "0e1ae11e1ebfe644cbf832df62ac2dbf6ecd0501"
  :revdesc "0.9.2-0-g0e1ae11e1ebf"
  :keywords '("elpa" "package"))
