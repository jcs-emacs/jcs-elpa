;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.3"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "3245b15889d4b536daae5cfa566b5c082796a0a0"
  :revdesc "3245b15889d4"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
