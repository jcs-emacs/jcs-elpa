;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-hl" "1.0.0.20220523.10"
  "Highlight undo/redo."
  '((emacs "26.0"))
  :url "https://github.com/casouri/undo-hl"
  :commit "89fdcc62e3d938854433bc14d95e1c8e505eee20"
  :revdesc "89fdcc62e3d9"
  :keywords '("undo")
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
