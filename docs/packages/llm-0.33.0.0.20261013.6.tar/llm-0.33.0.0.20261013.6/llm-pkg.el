;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.33.0.0.20261013.6"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "1684164176266964cd1388c4c6defdcf434be9b1"
  :revdesc "168416417626"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
