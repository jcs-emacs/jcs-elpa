;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260402.358"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "0e5d4dee6e48a86a700ccc8cb202a4fc0703ff93"
  :revdesc "0e5d4dee6e48"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
