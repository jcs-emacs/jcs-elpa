;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260410.357"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "d73f3d3e0c5a17d2336b4a42b1a0ff609bdf75db"
  :revdesc "d73f3d3e0c5a"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
