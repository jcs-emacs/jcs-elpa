;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-scroll-bar" "0.2.0.0.20260404.2"
  "Automatically show/hide scroll-bars as needed."
  '((emacs "29.1")
    (elenv "0.1.0"))
  :url "https://github.com/emacs-vs/auto-scroll-bar"
  :commit "96debece42d901d9d3fa799bdebe1e7960dc6886"
  :revdesc "96debece42d9"
  :keywords '("convenience" "scrollbar")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
