;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260316.1437"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "2a8eb09cec2b12392207930bc38670c1c78ea603"
  :revdesc "2a8eb09cec2b"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
