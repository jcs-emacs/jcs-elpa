;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-box" "0.2.0.0.20260115.2224"
  "Company front-end with icons."
  '((emacs       "27.1")
    (dash        "2.18")
    (company     "0.9.6")
    (frame-local "0.0.1")
    (msgu        "0.1.0"))
  :url "https://github.com/elp-revive/company-box"
  :commit "9af9772b13b68ad6b5d2dae2aa559dc66d74a6d4"
  :revdesc "9af9772b13b6"
  :keywords '("company" "completion" "front-end" "convenience")
  :authors '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
