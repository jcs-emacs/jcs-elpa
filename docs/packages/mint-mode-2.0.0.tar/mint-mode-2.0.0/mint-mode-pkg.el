;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mint-mode" "2.0.0"
  "Major mode for the Mint programming language."
  '((emacs "25.1"))
  :url "https://github.com/creatorrr/emacs-mint-mode"
  :commit "7bb0f9946f5833eada199e880fdc4efa6df09e0b"
  :revdesc "7bb0f9946f58"
  :keywords '("mint" "languages" "processes" "convenience" "tools" "files")
  :authors '(("Diwank Tomer" . "singh@diwank.name"))
  :maintainers '(("jgart" . "jgart@dismail.de")))
