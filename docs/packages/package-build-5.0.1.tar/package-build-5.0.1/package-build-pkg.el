;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.0.1"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/melpa/package-build"
  :commit "ffba7c0c3d8e8bb5d905024f9def82a7bd82489e"
  :revdesc "v5.0.1-0-gffba7c0c3d8e"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
