;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hlsl-mode" "1.0"
  "Major mode for Open HLSL shader files."
  ()
  :url "https://github.com/darfink/hlsl-mode"
  :commit "c9c80ce43a274a78ffdaa662e23ef81408d25549"
  :revdesc "c9c80ce43a27"
  :keywords '("languages" "hlsl" "shader"))
