;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.0.0.20260611.2"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "5f852b6bb303e3bb3e34af10646f54fdb854e348"
  :revdesc "5f852b6bb303"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
