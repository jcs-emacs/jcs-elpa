;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "on" "0.2.0"
  "Hooks for faster startup."
  '((emacs "27.1"))
  :url "https://github.com/elp-revive/on.el"
  :commit "b7b8b05a940385f2bda7552f5e2a424752ff68c9"
  :revdesc "b7b8b05a9403"
  :keywords '("convenience")
  :authors '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
