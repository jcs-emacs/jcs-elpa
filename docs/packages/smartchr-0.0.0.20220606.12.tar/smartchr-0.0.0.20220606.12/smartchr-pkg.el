;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartchr" "0.0.0.20220606.12"
  "Emacs version of smartchr.vim."
  '((emacs "24.3"))
  :url "https://github.com/imakado/emacs-smartchr"
  :commit "b2410de732484030758f72b07e619cc594e6d287"
  :revdesc "b2410de73248"
  :authors '(("IMAKADO" . "ken.imakado@gmail.com"))
  :maintainers '(("IMAKADO" . "ken.imakado@gmail.com")))
