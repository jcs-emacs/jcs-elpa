;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260304.1911"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "1422f01fa3f9d2a802358d3a46e25cde24057199"
  :revdesc "1422f01fa3f9"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
