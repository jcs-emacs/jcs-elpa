;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260413.1342"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "6ffcd71921a96b8152a826d38971c76fcb2b72ac"
  :revdesc "6ffcd71921a9"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
