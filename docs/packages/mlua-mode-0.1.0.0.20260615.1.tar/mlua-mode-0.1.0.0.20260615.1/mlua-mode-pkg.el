;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mlua-mode" "0.1.0.0.20260615.1"
  "Major mode for mLua."
  '((emacs    "26.1")
    (lua-mode "0.1.0"))
  :url "https://github.com/MSW-cmty/mlua-mode"
  :commit "f102d367f5ecb3599c51a6f754bd339acba4b6a1"
  :revdesc "f102d367f5ec"
  :keywords '("languages")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
