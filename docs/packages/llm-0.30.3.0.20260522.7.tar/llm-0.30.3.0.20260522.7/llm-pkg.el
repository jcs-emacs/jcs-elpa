;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.30.3.0.20260522.7"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "c34ae6afa242dec0d6cf12a94faef67780e7355e"
  :revdesc "c34ae6afa242"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
