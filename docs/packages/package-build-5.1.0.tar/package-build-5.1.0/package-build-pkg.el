;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.1.0"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "fe9592c844d7a8834e7cc74dc01c4747e2b90c5e"
  :revdesc "v5.1.0-0-gfe9592c844d7"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
