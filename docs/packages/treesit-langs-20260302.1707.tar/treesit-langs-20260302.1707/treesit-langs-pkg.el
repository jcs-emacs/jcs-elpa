;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260302.1707"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "38236d7f096e487e84fc7ef89d4f853c6ab2a481"
  :revdesc "38236d7f096e"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
