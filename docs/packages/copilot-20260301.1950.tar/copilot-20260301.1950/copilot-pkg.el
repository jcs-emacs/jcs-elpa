;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260301.1950"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "a11462a47ec619fbc9ec1af55f9bbea4c81fa966"
  :revdesc "a11462a47ec6"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
