;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lemmington" "0.0.1.0.20230902.13"
  "RPC Emacs server."
  '((emacs      "27.1")
    (porthole   "0.3.0")
    (elisp-refs "1.6"))
  :url "https://github.com/lem-project/lemmington.git"
  :commit "e3fe31a903501f003109816abe0474bfa94fe917"
  :revdesc "e3fe31a90350"
  :keywords '("tools" "languages")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
