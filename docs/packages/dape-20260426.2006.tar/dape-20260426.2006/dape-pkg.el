;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260426.2006"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "48b3db3c6220399f71ea1c9cb13cd93833523723"
  :revdesc "48b3db3c6220"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
