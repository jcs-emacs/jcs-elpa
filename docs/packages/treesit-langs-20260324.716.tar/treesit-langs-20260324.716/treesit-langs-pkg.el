;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-langs" "20260324.716"
  "Language bundle for Emacs's treesit.el."
  '((emacs "29.1"))
  :url "https://github.com/emacs-tree-sitter/treesit-langs"
  :commit "9cdb52ff1ea77326c1a9b2aefbd5ee13e4cb0f03"
  :revdesc "9cdb52ff1ea7"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
