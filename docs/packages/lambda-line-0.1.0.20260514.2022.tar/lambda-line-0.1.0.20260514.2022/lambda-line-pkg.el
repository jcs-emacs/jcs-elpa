;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambda-line" "0.1.0.20260514.2022"
  "A custom status line."
  '((emacs "27.1"))
  :url "https://github.com/Lambda-Emacs/lambda-line"
  :commit "a0d5b1e215cdef6d5d1125dd6af2c54df9ae341d"
  :revdesc "a0d5b1e215cd"
  :keywords '("mode-line" "faces"))
