;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-shell" "0.1.1.0.20260101.601"
  "Managing multiple shell buffers."
  '((emacs "25.1"))
  :url "https://github.com/jcs-elpa/multi-shell"
  :commit "c532904abb0f01f35161198015e4e2ec42f8bec7"
  :revdesc "c532904abb0f"
  :keywords '("convenience" "multiple" "shell" "terminal")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
