;;; e-unit-describe.el --- BDD-style describe/it blocks for E-Unit -*- lexical-binding: t; -*-

;; Copyright (C) 2025
;; SPDX-License-Identifier: GPL-3.0-only

;; Author: Aldric Giacomoni <trevoke@gmail.com>
;; URL: https://codeberg.org/Trevoke/eunit.el

;;; Commentary:

;; BDD-style nested test blocks (describe/it) for E-Unit.
;; Provides RSpec/Mocha-style test organization.
;;
;; Usage:
;;
;;   (require 'e-unit)
;;   (require 'e-unit-describe)
;;
;;   (describe "User Management"
;;     (describe "Creating Users"
;;       (it "creates a valid user"
;;         (let ((user (create-user "alice")))
;;           (assert-equal "alice" (user-name user))))
;;
;;       (it "rejects invalid usernames"
;;         (assert-raises 'validation-error
;;           (create-user ""))))
;;
;;     (describe "Deleting Users"
;;       (it "removes user from database"
;;         (create-user "bob")
;;         (delete-user "bob")
;;         (assert-equal 0 (count-users test-db)))))
;;
;; For setup/teardown, use E-Unit's native hooks within contexts:
;;
;;   (describe "Database Tests"
;;     (setup-each ()
;;       (setq test-db (create-test-database)))
;;
;;     (teardown-each ()
;;       (cleanup-test-database test-db))
;;
;;     (it "creates records" ...))

;;; Code:

(require 'e-unit)

;;; State Management

(defvar eunit-describe--current-description nil
  "Stack of description strings for nested describe blocks.
Each element is a description string. The full description
is formed by joining with ' > '.")

;;; Core Macros

(defmacro describe (description &rest body)
  "Define a describe block with DESCRIPTION containing BODY.

Describe blocks create nested test contexts. E-Unit hooks
registered within a describe block only affect tests in that
block due to context scoping.

Example:
  (describe \"Math Operations\"
    (setup-each ()
      (setq calculator (make-calculator)))

    (it \"adds numbers\"
      (assert-equal 4 (calculate 2 '+ 2))))"
  (declare (indent 1))
  `(progn
     ;; Push description onto stack
     (push ,description eunit-describe--current-description)

     ;; Create context string for E-Unit's context stack
     (let ((context-string (format "describe:%s"
                                   (mapconcat 'identity
                                              (reverse eunit-describe--current-description)
                                              " > "))))
       (e-unit-push-context context-string))

     ;; Evaluate body (may contain nested describes and its)
     (unwind-protect
         (progn ,@body)
       ;; Clean up: pop description and context
       (e-unit-pop-context)
       (pop eunit-describe--current-description))))

(defmacro it (description &rest body)
  "Define a test with DESCRIPTION containing BODY.

Must be used inside a describe block. The full test name is
formed by joining all parent describe blocks with the it description.

The describe context path is automatically prepended to the docstring
via the registration hook, and the context is captured for context-based
test discovery.

Example:
  (it \"calculates correctly\"
    (assert-equal 4 (+ 2 2)))"
  (declare (indent 1))
  ;; Generate unique test name from description stack + it description
  (let ((test-name (intern (format "test-%s"
                                   (replace-regexp-in-string
                                    "[^a-z0-9-]" "-"
                                    (downcase
                                     (mapconcat #'identity
                                                (append (reverse eunit-describe--current-description)
                                                        (list description))
                                                " "))
                                    nil t)))))
    ;; Just define the test - the registration hook handles:
    ;; - Capturing context stack
    ;; - Enhancing docstring with describe path
    `(deftest ,test-name ()
       ,description
       ,@body)))

;;; Registration Hook

(defun eunit-describe--enhance-docstring (info)
  "Enhance test docstring with describe context path.
This hook runs during test registration to prepend the describe
path to any test defined inside a describe block."
  (when-let* ((context-stack (plist-get info :context))
              (describe-ctx (cl-find-if
                             (lambda (c) (string-prefix-p "describe:" c))
                             context-stack)))
    (let ((path (substring describe-ctx 9))) ; remove "describe:" prefix
      (plist-put info :docstring
                 (if (plist-get info :docstring)
                     (format "%s > %s" path (plist-get info :docstring))
                   path)))))

;; Register the hook
(add-hook 'e-unit-register-test-hook #'eunit-describe--enhance-docstring)

;;; Helper Functions

(defun eunit-describe--extract-context-path (context-stack)
  "Extract describe path from CONTEXT-STACK.
Returns the path string without the \"describe:\" prefix, or nil."
  (when-let ((describe-ctx (cl-find-if
                            (lambda (c) (string-prefix-p "describe:" c))
                            context-stack)))
    (substring describe-ctx 9)))

(defun eunit-describe-list-tests-in-context (context)
  "List all tests in the describe CONTEXT.

Returns a list of test names that belong to the given describe context.
Uses the captured :context from test-info (set at registration time)."
  (let ((prefix (format "describe:%s" context)))
    (cl-loop for test in e-unit--tests
             for test-context = (plist-get test :context)
             when (and test-context
                       (cl-some (lambda (c) (string-prefix-p prefix c))
                                test-context))
             collect (plist-get test :name))))

(defun eunit-describe-run-context (context)
  "Run all tests in the describe CONTEXT.

Useful for running a specific describe block without running
unrelated tests."
  (interactive
   (list (completing-read "Describe context: "
                          (eunit-describe--all-contexts)
                          nil t)))
  (let ((tests (eunit-describe-list-tests-in-context context)))
    (if (null tests)
        (message "No tests found in context: %s" context)
      (message "Running %d tests from: %s" (length tests) context)
      (dolist (test tests)
        (eunit--run-test test)))))

(defun eunit-describe--all-contexts ()
  "Get list of all describe contexts that have tests.
Uses the captured :context from test-info (set at registration time)."
  (let ((contexts nil))
    (dolist (test e-unit--tests)
      (when-let* ((context-stack (plist-get test :context))
                  (path (eunit-describe--extract-context-path context-stack)))
        (unless (member path contexts)
          (push path contexts))))
    (sort contexts #'string<)))

(provide 'e-unit-describe)

;;; e-unit-describe.el ends here
