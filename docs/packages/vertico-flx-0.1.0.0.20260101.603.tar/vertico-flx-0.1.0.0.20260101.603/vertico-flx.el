;;; vertico-flx.el --- Flx integration for vertico  -*- lexical-binding: t; -*-

;; Copyright (C) 2022-2026  Shen, Jen-Chieh
;; Created date 2022-04-19 17:15:39

;; Author: Shen, Jen-Chieh <jcs090218@gmail.com>
;; URL: https://github.com/jcs-elpa/vertico-flx
;; Package-Version: 0.1.0.0.20260101.603
;; Package-Revision: bbfdbbb24937
;; Package-Requires: ((emacs "28.1") (vertico "0.22") (flx "0.5") (flx-style "0.1.1") (ht "2.0") (f "0.20.0") (mbs "0.1.0") (s "1.12.0"))
;; Keywords: convenience vertico flx

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Flx integration for vertico.
;;

;;; Code:

(require 'f)
(require 'ht)
(require 'mbs)
(require 's)

(require 'vertico)
(require 'flx)
(require 'flx-style)

(defgroup vertico-flx nil
  "Flx integration for vertico."
  :prefix "vertico-flx-"
  :group 'convenience
  :link '(url-link :tag "Repository" "https://github.com/jcs-elpa/vertico-flx"))

(defconst vertico-flx-completion-styles '(flx)
  "Completion styles to set when completing.")

(defvar vertico-flx--old-completion-styles nil
  "Different completion style when completing using minbuffer.")

(defvar vertico-flx--sorting nil
  "Return non-nil if currently sorting.")

;;
;; (@* "Util" )
;;

(defun vertico-flx--directory-p (path)
  "Return non-nil if PATH is a directory path."
  (and (file-exists-p path) (file-directory-p path)))

;;
;; (@* "Fuzzy Sorting" )
;;

(defun vertico-flx--sort-candidates-by-function (candidates prefix fnc &optional flip)
  "Sort CANDIDATES with PREFIX and FNC.

If optional argument FLIP is non-nil, reverse query and pattern order."
  (let ((scoring-table (ht-create)) scoring-keys)
    (dolist (cand candidates)
      (when-let*
          ((scoring (ignore-errors
                      (if flip (funcall fnc prefix cand)
                        (funcall fnc cand prefix))))
           (score (cond ((listp scoring) (nth 0 scoring))
                        ((vectorp scoring) (aref scoring 0))
                        ((numberp scoring) scoring)
                        (t 0))))
        ;; XXX ht causes unknown error on start, use regular hash table functions
        ;; for now
        (unless (gethash score scoring-table) (setf (gethash score scoring-table) nil))
        (push cand (gethash score scoring-table))))
    ;; Get all keys, and turn into a list.
    (ht-map (lambda (score-key _) (push score-key scoring-keys)) scoring-table)
    (setq scoring-keys (sort scoring-keys #'>)  ; Sort keys in order
          candidates nil)  ; Clean up, and ready for final output
    (dolist (key scoring-keys)
      (let ((cands (ht-get scoring-table key)))
        (setq candidates (append candidates cands)))))
  candidates)

;;
;; (@* "Multiform" )
;;

;;;###autoload
(defun vertico-flx-sort-default (all)
  "Sort candidates ALL."
  (mbs-with-minibuffer-env
    (setq vertico-flx--sorting nil)
    (let ((base #'vertico-sort-history-length-alpha))
      ;; Final output
      (if (string-empty-p contents)  ; Empty, return raw
          (if (null base) all
            (cond ((functionp base) (funcall base all))
                  ((listp base) base)))
        (setq vertico-flx--sorting t)
        ;; Return fuzzy order
        (vertico-flx--sort-candidates-by-function all contents #'flx-score)))))

;;;###autoload
(defun vertico-flx-sort-files (all)
  "Sort candidates ALL for files."
  (mbs-with-minibuffer-env
    (setq vertico-flx--sorting nil)
    (let ((input (if (and (string-suffix-p "/" contents)
                          (vertico-flx--directory-p contents))
                     ""
                   (f-filename contents))))
      (if (string-empty-p input)
          (sort (sort all #'string-lessp)
                (lambda (var1 var2)
                  (and (string-suffix-p "/" var1)
                       (not (string-suffix-p "/" var2)))))
        (setq vertico-flx--sorting t)
        (vertico-flx--sort-candidates-by-function all input #'flx-score)))))

;;
;; (@* "Entry" )
;;

(defvar vertico-flx--minibuffer-setup-p nil
  "Flag to make sure `minibuffer-setup' is executed once.")

(defun vertico-flx--minibuffer-setup (&rest _)
  "Hook for minibuffer setup."
  (unless vertico-flx--minibuffer-setup-p
    (setq vertico-flx--old-completion-styles completion-styles
          completion-styles vertico-flx-completion-styles
          vertico-flx--minibuffer-setup-p t)
    (add-hook 'post-command-hook #'vertico-flx--post-command 5 t)))

(defun vertico-flx--minibuffer-exit (&rest _)
  "Hook for minibuffer exit."
  (setq completion-styles vertico-flx--old-completion-styles
        vertico-flx--minibuffer-setup-p nil))

(defun vertico-flx--post-command (&rest _)
  "Hook for minibuffer post command."
  (when (mbs-finding-file-p)
    (setq completion-styles (if (mbs-tramp-p)
                                '(basic flx)
                              vertico-flx-completion-styles))))

(defun vertico-flx--enable ()
  "Enable `vertico-flx-mode'."
  (add-hook 'minibuffer-setup-hook #'vertico-flx--minibuffer-setup 95)
  (add-hook 'minibuffer-exit-hook #'vertico-flx--minibuffer-exit 95))

(defun vertico-flx--disable ()
  "Disable `vertico-flx-mode'."
  (remove-hook 'minibuffer-setup-hook #'vertico-flx--minibuffer-setup)
  (remove-hook 'minibuffer-exit-hook #'vertico-flx--minibuffer-exit))

;;;###autoload
(define-minor-mode vertico-flx-mode
  "Minor mode `vertico-flx-mode'."
  :global t
  :require 'vertico-flx-mode
  :group 'vertico-flx
  (if vertico-flx-mode (vertico-flx--enable) (vertico-flx--disable)))

(provide 'vertico-flx)
;;; vertico-flx.el ends here
