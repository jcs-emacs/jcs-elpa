;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "use-ttf" "0.1.3.0.20260101.73"
  "Keep font consistency across different OSs."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/use-ttf"
  :commit "af34fb0d5cc46851b7b567fe171759724b3cdfd4"
  :revdesc "af34fb0d5cc4"
  :keywords '("convenience" "customize" "font" "install" "ttf")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
