;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard" "20260228.613"
  "A startup screen extracted from Spacemacs."
  '((emacs "27.1"))
  :url "https://github.com/emacs-dashboard/emacs-dashboard"
  :commit "89662baf42965ce9061d10c5df93b02a6e50e48c"
  :revdesc "89662baf4296"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Ricardo Arredondo" . "ricardo.richo@gmail.com")))
