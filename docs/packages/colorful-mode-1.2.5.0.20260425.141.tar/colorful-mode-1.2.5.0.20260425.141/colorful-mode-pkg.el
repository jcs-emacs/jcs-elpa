;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorful-mode" "1.2.5.0.20260425.141"
  "Preview any color in your buffer in real time."
  '((emacs  "28.1")
    (compat "30.1.0.0"))
  :url "https://github.com/DevelopmentCool2449/colorful-mode"
  :commit "13622ae3deeb911aecf827f51aa30679de15e773"
  :revdesc "13622ae3deeb"
  :keywords '("faces" "tools" "matching" "convenience")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Elias G. Perez" . "eg642616@gmail.com")))
