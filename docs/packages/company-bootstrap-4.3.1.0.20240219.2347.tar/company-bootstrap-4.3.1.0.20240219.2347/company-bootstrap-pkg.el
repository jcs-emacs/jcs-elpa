;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-bootstrap" "4.3.1.0.20240219.2347"
  "A company backend for bootstrap."
  '((emacs   "24.3")
    (company "0.9.10"))
  :url "https://github.com/typefo/company-bootstrap"
  :commit "3df09598c50c824b1dfe2b9d2f2aa95b1e55995e"
  :revdesc "3df09598c50c"
  :authors '(("typefo" . "typefo@hotmail.com"))
  :maintainers '(("typefo" . "typefo@hotmail.com")))
