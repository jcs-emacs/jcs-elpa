;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-hl" "1.0.0.20261126.13"
  "Highlight undo/redo."
  '((emacs "26.0"))
  :url "https://github.com/casouri/undo-hl"
  :commit "084493681dead95d3b5710d75612a61c38a411e2"
  :revdesc "084493681dea"
  :keywords '("undo")
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
