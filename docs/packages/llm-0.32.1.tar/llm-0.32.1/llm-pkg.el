;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.32.1"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "f4c8b2f5ebf25e4957e7f9804f0f8f426755be8d"
  :revdesc "f4c8b2f5ebf2"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
