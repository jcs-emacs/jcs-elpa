;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-completion" "0.0.1.0.20260921.41"
  "Add icons to completion candidates."
  '((emacs      "25.1")
    (nerd-icons "0.0.1")
    (compat     "30"))
  :url "https://github.com/rainstormstudio/nerd-icons-completion"
  :commit "f924dd490c8c4c1066fd97a76e0dc31e303fca30"
  :revdesc "f924dd490c8c"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")))
