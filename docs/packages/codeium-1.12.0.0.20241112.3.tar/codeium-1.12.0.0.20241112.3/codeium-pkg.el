;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codeium" "1.12.0.0.20241112.3"
  "Codeium client for emacs."
  ()
  :url "https://github.com/Exafunction/codeium.el"
  :commit "3c3e7de8810e46f4c9a934fceeb79d8b6777a711"
  :revdesc "3c3e7de8810e")
