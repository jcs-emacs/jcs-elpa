;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jai-mode" "0.1.0"
  "Major mode for JAI."
  '((emacs "26.1"))
  :url "https://github.com/elp-revive/jai-mode"
  :commit "fa7ef41ca03c2475496742a11a23e6d95f05eeaf"
  :revdesc "fa7ef41ca03c"
  :keywords '("languages")
  :authors '(("Kristoffer Grönlund" . "k@ziran.se"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
