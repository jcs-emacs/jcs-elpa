;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-bars" "20260418.1303"
  "Highlight indentation with bars."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/jdtsmith/indent-bars"
  :commit "f95fee11d9932cba71d686807025239be0319e91"
  :revdesc "f95fee11d993"
  :keywords '("convenience")
  :authors '(("J.D. Smith" . "jdtsmith+elpa@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
