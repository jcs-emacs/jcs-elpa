;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "20260405.331"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "8000945ee9c7bd675d043ca49519de406c3acfb7"
  :revdesc "8000945ee9c7"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
