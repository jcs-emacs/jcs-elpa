;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repos-window" "0.1.0.0.20260101.602"
  "Reposition window if when needed."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/repos-window"
  :commit "786dddace1d22fb572f5627513fcb71307545e8a"
  :revdesc "786dddace1d2"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
