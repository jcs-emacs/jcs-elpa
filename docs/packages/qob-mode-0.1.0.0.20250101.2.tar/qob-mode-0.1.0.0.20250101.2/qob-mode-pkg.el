;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qob-mode" "0.1.0.0.20250101.2"
  "Major mode for editing Qob files."
  '((emacs "26.1"))
  :url "https://github.com/cl-qob/qob-mode"
  :commit "3585d637a24450d06bc16b5399809ff250d8f241"
  :revdesc "3585d637a244"
  :keywords '("lisp" "qob")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
