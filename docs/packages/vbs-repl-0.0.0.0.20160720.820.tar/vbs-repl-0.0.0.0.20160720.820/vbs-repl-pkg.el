;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vbs-repl" "0.0.0.0.20160720.820"
  "Run visual basic repl as inferior process."
  ()
  :url "http://www.emacswiki.org/emacs/VbsReplMode"
  :commit "483dd5a2c8c4675ddb3c32fdd93146c6d248285d"
  :revdesc "483dd5a2c8c4"
  :keywords '("vbscript" "repl" "programming" "mode")
  :authors '(("Charles Sebold" . "cseboldatgmail.com"))
  :maintainers '(("Charles Sebold" . "cseboldatgmail.com")))
