;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "20260502.1104"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "753cf92ce4fc32e82d3816c525d4da09222c2a8a"
  :revdesc "753cf92ce4fc"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
