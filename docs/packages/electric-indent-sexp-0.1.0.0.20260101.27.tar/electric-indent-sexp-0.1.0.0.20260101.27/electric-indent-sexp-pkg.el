;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-indent-sexp" "0.1.0.0.20260101.27"
  "Automatically indent entire balanced expression block."
  '((emacs "26.1")
    (msgu  "0.1.0"))
  :url "https://github.com/jcs-elpa/electric-indent-sexp"
  :commit "39e8b88d15da2f6097a3229cd0d06100d336e5b3"
  :revdesc "39e8b88d15da"
  :keywords '("convenience" "indent" "sexp" "electric")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
