;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codegpt" "0.1.0.0.20260101.538"
  "Use GPT-3 tp help you write code."
  '((emacs         "28.1")
    (openai        "0.1.0")
    (markdown-mode "2.1")
    (spinner       "1.7.4"))
  :url "https://github.com/emacs-openai/codegpt"
  :commit "01602348999ec22ef93600e4f676b2cd63066dc9"
  :revdesc "01602348999e"
  :keywords '("convenience" "codegpt")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
