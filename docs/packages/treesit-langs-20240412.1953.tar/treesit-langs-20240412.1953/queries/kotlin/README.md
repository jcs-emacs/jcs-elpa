# License
The file queries/kotlin is originally copied from
https://github.com/nvim-treesitter/nvim-treesitter/blob/master/queries/kotlin/highlights.scm,
then slightly modified. The original file was licnensed under Apache License
Version 2.0. Se ./LICENCE file for details
