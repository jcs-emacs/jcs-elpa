;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.7.0.0.20260626.1"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "d897f374c039e99c6cafafb07008fc7c461b7d78"
  :revdesc "d897f374c039"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
